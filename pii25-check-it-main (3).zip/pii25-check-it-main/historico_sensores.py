# -*- coding: utf-8 -*-
"""
Gestión de histórico de sensores.
Proporciona funciones para consultar el histórico de cambios.
"""

from Sensor import (
    obtener_historico_sensor, 
    obtener_historico_por_zona,
    abrir_historico_sensores
)
from datetime import datetime


def obtener_cambios_sensor(sensor_id: str, ultimos=10):
    """Obtiene los últimos cambios de un sensor"""
    cambios = obtener_historico_sensor(sensor_id, limite=ultimos)
    return cambios


def obtener_cambios_zona(zona: str, ultimos=20):
    """Obtiene los últimos cambios en una zona"""
    cambios = obtener_historico_por_zona(zona, limite=ultimos)
    return cambios


def resumen_historico():
    """Obtiene resumen del histórico completo"""
    historico = abrir_historico_sensores()
    
    if not historico:
        return {"total": 0, "sensores": [], "zonas": []}
    
    sensores_unicos = set(r["sensor_id"] for r in historico)
    zonas_unicas = set(r["zona"] for r in historico)
    
    primer_registro = historico[0]["timestamp"]
    ultimo_registro = historico[-1]["timestamp"]
    
    return {
        "total": len(historico),
        "sensores": list(sensores_unicos),
        "zonas": list(zonas_unicas),
        "primer_registro": primer_registro,
        "ultimo_registro": ultimo_registro
    }


def mostrar_cambios_sensor(sensor_id: str, ultimos=5):
    """Muestra los cambios de un sensor en formato legible"""
    cambios = obtener_historico_sensor(sensor_id, limite=ultimos)
    
    print(f"\n=== Histórico de {sensor_id} ===")
    
    if not cambios:
        print("No hay histórico disponible")
        return
    
    for cambio in cambios:
        timestamp = cambio["timestamp"]
        print(f"\n[{timestamp}]")
        print(f"  Cambio: {cambio['cambio']}")


def mostrar_cambios_zona(zona: str, ultimos=10):
    """Muestra los cambios en una zona en formato legible"""
    cambios = obtener_historico_por_zona(zona, limite=ultimos)
    
    print(f"\n=== Histórico de zona {zona} ===")
    
    if not cambios:
        print("No hay histórico disponible")
        return
    
    for cambio in cambios:
        timestamp = cambio["timestamp"]
        sensor_id = cambio["sensor_id"]
        print(f"\n[{timestamp}] {sensor_id}")
        print(f"  {cambio['cambio']}")
