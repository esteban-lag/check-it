import sys
import json
import os
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QVBoxLayout, QGridLayout, QMessageBox,
    QPushButton
)
from PySide6.QtCore import Qt
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

# Importar la UI
from vistas.Worker.ui_UserWORKER import Ui_WorkerWindow
from typing import List, Dict, Any


# Importar los componentes personalizados
from componentes import TermostatoWidget, SensorLuzWidget, SensorRuidoWidget, CalidadAireWidget

# Importar el módulo de modelos que ahora usa BD
try:
    import models
except ImportError:
    print("Advertencia: No se encontró el módulo 'models'.")
    models = None

class WorkerWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_WorkerWindow()
        self.ui.setupUi(self)

        # --- CORRECCIÓN DE LAYOUT ---
        layout_principal = QVBoxLayout(self.ui.centralwidget)
        layout_principal.setContentsMargins(0, 0, 0, 0)
        layout_principal.addWidget(self.ui.frame)
        layout_fondo = QGridLayout(self.ui.frame)

        # --- CARGAR DATOS DE SENSORES DESDE BD ---
        self.datos_sensores = self.cargar_datos_bd()

        # --- CONFIGURACIÓN INICIAL ---
        self.ui.stackedWidget.setCurrentIndex(0)  # Empezar en Home

        # --- NAVEGACIÓN PRINCIPAL ---
        self.setup_navegacion()

        # --- LÓGICA DE SECTORES (SENSORES) ---
        self.setup_sectores()

        # Cargar Sector 1 por defecto al iniciar
        self.mostrar_datos_sector(1)
        self.cargar_promedios_home()
        self.ui.pushButton_10.clicked.connect(self.al_enviar_mensaje)
        self.cargar_datos_parking()
        self.cargar_grafica_historico()

        self.timer_chat = QTimer(self)
        self.timer_chat.timeout.connect(self.actualizar_chat_periodico)
        self.timer_chat.start(3000)

    # ==========================================
    # LÓGICA DE SENSORES (BD)
    # ==========================================

    def cargar_datos_bd(self):
        """Lee los sensores desde la BD."""
        try:
            # Cargar sensores desde la BD usando models
            sensores_bd = models.cargar_sensores_bd()
            
            # Convertir formato de BD a formato esperado por la UI
            datos_sensores = []
            for sensor in sensores_bd:
                datos_sensores.append({
                    'id': sensor.get('id'),
                    'sector': sensor.get('zone'),  # zone en BD = sector
                    'valor': sensor.get('value'),
                    'tipo': self.mapear_tipo_sensor(sensor.get('type')),
                    'max_val': sensor.get('max'),
                    'min_val': sensor.get('minimum'),
                    'working': sensor.get('working')
                })
            
            print(f"Cargados {len(datos_sensores)} sensores desde BD")
            return datos_sensores
        except Exception as e:
            print(f"Error leyendo sensores de BD: {e}")
            return []

    def mapear_tipo_sensor(self, tipo_id):
        """Mapea el ID del tipo de sensor en BD a su nombre legible."""
        tipo_map = {
            1: 'temperatura',
            2: 'humedad',
            3: 'distancia',
            4: 'aire',
            5: 'luz',
            7: 'ruido'
        }
        return tipo_map.get(tipo_id, 'desconocido')

    def cargar_promedios_home(self):
        """
        Calcula la media de todos los sensores y actualiza
        los widgets de la página HOME.
        """
        if not self.datos_sensores:
            return

        # Diccionarios para guardar sumas y contadores
        sumas = {'temperatura': 0, 'luz': 0, 'aire': 0, 'ruido': 0}
        contadores = {'temperatura': 0, 'luz': 0, 'aire': 0, 'ruido': 0}

        # 1. Recorrer todos los datos y sumar
        for sensor in self.datos_sensores:
            tipo = sensor.get('tipo')
            valor = sensor.get('valor', 0)

            if tipo in sumas:
                sumas[tipo] += valor
                contadores[tipo] += 1

        # 2. Calcular promedios
        promedios = {}
        for key in sumas:
            if contadores[key] > 0:
                promedios[key] = sumas[key] / contadores[key]
            else:
                promedios[key] = 0

        print(f"Promedios generales: {promedios}")

        # 3. Actualizar los Widgets de la HOME

        # Temperatura
        self.ui.widget_13.setTemperature(promedios['temperatura'])

        # Luz
        self.ui.widget_15.setLevel(promedios['luz'])

        # Aire
        self.ui.widget_16.setCalidad(promedios['aire'])

        # Ruido
        self.ui.widget_12.nivel_ruido = promedios['ruido']
        self.ui.widget_12.update()

    def setup_sectores(self):
        """Conecta los botones de la página 'Sectors' a la función de carga."""
        try:
            self.ui.Sector1_2.clicked.connect(lambda: self.mostrar_datos_sector(1))
            self.ui.Sector2_2.clicked.connect(lambda: self.mostrar_datos_sector(2))
            self.ui.Sector3_2.clicked.connect(lambda: self.mostrar_datos_sector(3))
            self.ui.Sector4_2.clicked.connect(lambda: self.mostrar_datos_sector(4))
            self.ui.Sector5_2.clicked.connect(lambda: self.mostrar_datos_sector(5))
            self.ui.Sector6_2.clicked.connect(lambda: self.mostrar_datos_sector(6))
            
            if hasattr(self.ui, 'Sector7_7'):
                self.ui.Sector7_7.clicked.connect(lambda: self.mostrar_datos_sector(7))
            elif hasattr(self.ui, 'Sector7_2'):
                self.ui.Sector7_2.clicked.connect(lambda: self.mostrar_datos_sector(7))

            self.ui.Sector8_2.clicked.connect(lambda: self.mostrar_datos_sector(8))
        except AttributeError as e:
            print(f"Error conectando botones de sectores: {e}")

    def mostrar_datos_sector(self, sector_id):
        """
        Filters data by sector and updates the widgets.
        """
        print(f"Loading data for Sector {sector_id}...")

        # 1. Filtrar datos del sector seleccionado
        datos_sector = [d for d in self.datos_sensores if d['sector'] == sector_id]

        if not datos_sector:
            print("No data for this sector.")
            return

        # 2. Iterar y actualizar cada widget según el nuevo mapeo de tipos
        for sensor in datos_sector:
            tipo = sensor['tipo']
            valor = sensor['valor']
            min_v = sensor.get('min_val', 0)
            max_v = sensor.get('max_val', 100)

            if tipo == "temperatura":
                self.ui.widget_11.min_temp = min_v
                self.ui.widget_11.max_temp = max_v
                self.ui.widget_11.setTemperature(valor)

            #elif tipo == "humedad":
                # 🛠️ ¡AÑADIDO! Aquí manejas la humedad (Tipo 2)
                # Revisa en Qt Designer si el widget de humedad es widget_12, widget_7... y cambia el número si hace falta
                # self.ui.widget_12.setHumidity(valor)

            elif tipo == "aire":
                self.ui.widget_9.setCalidad(valor)

            elif tipo == "luz":
                # Ahora la luz (Tipo 5) actualiza de forma correcta el widget_8
                self.ui.widget_8.setLevel(valor)

            #elif tipo == "distancia":
                # Aquí puedes añadir la lógica del parking/distancia si el sensor mide eso
            #    pass

    # ==========================================
    # LÓGICA DE PERFIL Y NAVEGACIÓN
    # ==========================================
    def setup_navegacion(self):
        """Configura los botones del menú lateral."""
        self.ui.pushButton.clicked.connect(lambda: self.cambiar_pagina(0))    # Home
        self.ui.pushButton_2.clicked.connect(lambda: self.cambiar_pagina(2))  # News
        self.ui.pushButton_4.clicked.connect(lambda: self.cambiar_pagina(5))  # Sectors
        self.ui.pushButton_3.clicked.connect(lambda: self.cambiar_pagina(3))  # Status
        self.ui.pushButton_9.clicked.connect(lambda: self.cambiar_pagina(1))

        if hasattr(self.ui, 'pushButton_5'):
            self.ui.pushButton_5.clicked.connect(lambda: self.cambiar_pagina(4))

        if hasattr(self.ui, 'pushButton_8'):
            self.ui.pushButton_8.clicked.connect(lambda: self.cambiar_pagina(6))  # Profile

    def cambiar_pagina(self, indice):
        """Cambia de página en el StackedWidget."""
        self.ui.stackedWidget.setCurrentIndex(indice)

        # Si vamos a la página de perfil, cargamos los datos
        if indice == 6:
            self.cargar_datos_perfil()
        if indice == 1:
            self.UI_lista_contactos()

    def cargar_datos_perfil(self):
        """Lee los datos del usuario actual (desde sesión en memoria) y rellena los campos."""
        if not models:
            return

        # Ahora leer_usuario_actual() lee de la sesión en memoria, no de JSON
        datos = models.leer_usuario_actual()

        if not datos:
            QMessageBox.warning(self, "Error", "No se encontraron datos del usuario actual.")
            return

        try:
            self.ui.lineEdit_nombre.setText(datos.getNombre())
            self.ui.lineEdit_apellido.setText(datos.getApellido())
            self.ui.lineEdit_correo.setText(datos.getCorreo())
            # Verifica los nombres exactos de tus campos en QtDesigner
            if hasattr(self.ui, 'lineEdit_dni'):
                self.ui.lineEdit_dni.setText(datos.getDni())
            if hasattr(self.ui, 'lineEdit_id'):
                self.ui.lineEdit_id.setText(str(datos.getId()))
        except AttributeError as e:
            QMessageBox.critical(self, "Error de UI", f"No se encontró un campo en la interfaz: {e}")

    # ============================================================================
    # LOGICA DE CHAT
    # ============================================================================

    def obtener_lista_contactos(self):
        """
        Uso: Para llenar la lista de la izquierda (CHATS) con otros trabajadores.
        Retorna: Lista de objetos Trabajador o diccionarios.
        """
        database = models.obtener_db()
        if not database: return []
        return database.get_trabajadores()

    def UI_lista_contactos(self):
        """Carga los trabajadores y crea los botones en la barra lateral."""
        # 1. Obtener datos de la BD
        trabajadores = self.obtener_lista_contactos()

        # 2. Configurar el layout correcto
        # Obtenemos el layout actual del contenedor
        layout = self.ui.scrollAreaWidgetContents_12.layout()

        # Si no hay layout o es de tipo Grid (el del error), lo reemplazamos por uno Vertical
        if layout is None or layout.objectName() != "layout_vertical_chats":
            # Limpiamos cualquier layout previo
            if layout is not None:
                import shlex  # Solo para asegurar que no hay conflictos de punteros en algunos sistemas
                from PySide6.QtWidgets import QWidget
                # Truco para eliminar el layout viejo: asignarlo a un widget temporal
                QWidget().setLayout(layout)

                # Creamos el nuevo layout vertical
            layout = QVBoxLayout(self.ui.scrollAreaWidgetContents)
            layout.setObjectName("layout_vertical_chats")
            self.ui.scrollAreaWidgetContents_12.setLayout(layout)
        else:
            # Si ya es el vertical, solo limpiamos los botones viejos
            while layout.count():
                item = layout.takeAt(0)
                widget = item.widget()
                if widget:
                    widget.deleteLater()

        # 3. Crear botones para cada trabajador
        for t in trabajadores:
            nombre_completo = f"{t['name']} {t['last_name']}"
            btn = QPushButton(nombre_completo)
            btn.setMinimumHeight(50)

            # Estilo opcional para que parezcan botones de chat
            btn.setStyleSheet("text-align: left; padding-left: 10px;")

            # Conectar al chat
            btn.clicked.connect(lambda _, data=t: self.seleccionar_chat(data))

            layout.addWidget(btn)

        # 4. AHORA SÍ: Empujamos todo hacia arriba
        # Al ser un QVBoxLayout, esta función ya no dará error
        layout.addStretch()

    def seleccionar_chat(self, trabajador):
        """Activa el chat a la derecha con el trabajador seleccionado."""
        # 1. Cambiamos el nombre en el Label (según image_56f4e2.png es el objeto 'User')
        self.ui.User.setText(f"{trabajador['name']} {trabajador['last_name']}")

        # 2. Guardamos el ID del receptor actual en una variable de la clase
        # para saber a quién enviarle el mensaje cuando pulsemos "Send"
        self.id_receptor_actual = trabajador['id']

        # 3. (Opcional) Cambiar el StackedWidget de la derecha para mostrar el chat
        # Si tienes el 'NOCHAT' y el 'CHAT', aquí harías el switch
        self.ui.stackedWidget_2.setCurrentIndex(1)  # 0 suele ser la página de mensajes

        # 4. Cargar los mensajes de la BD
        self.mostrar_historial_chat()

    def mostrar_historial_chat(self):
        """Pinta los mensajes en el área de texto."""
        if hasattr(self, 'id_receptor_actual'):
            mensajes = self.cargar_conversacion_con(self.id_receptor_actual)

            # CONTROL: Verifica en tu terminal si este número sube cuando envías un mensaje externo
            print(f"[CHAT] Mensajes recuperados de la BD: {len(mensajes)}")

            texto_acumulado = ""
            for m in mensajes:
                emisor = "Yo" if m['soy_yo'] else self.ui.User.text()
                linea = f"{emisor}: {m['content']}\n"
                texto_acumulado += linea

            self.ui.Mensajes.setText(texto_acumulado)
            self.ui.Mensajes.setWordWrap(True)

    def enviar_mensaje_a_db(self,id_receptor: int, texto: str):
        """Guarda el mensaje y lo vincula. No sabe nada de la UI."""
        user_actual = models.leer_usuario_actual()
        if not user_actual or not user_actual.getId():
            return False

        database = models.obtener_db()
        try:
            id_mensaje = database.insertar_mensaje_contenido(texto)
            database.vincular_mensaje_a_chat(user_actual.getId(), id_receptor, id_mensaje)
            return True
        except Exception as e:
            print(f"Error al enviar mensaje: {e}")
            return False

    def al_enviar_mensaje(self):
        """Gestiona el clic en el botón enviar."""
        texto = self.ui.plainTextEdit.toPlainText().strip()
        if texto and hasattr(self, 'id_receptor_actual'):
            # Llamamos a la lógica de envío interna
            if self.enviar_mensaje_a_db(self.id_receptor_actual, texto):
                self.ui.plainTextEdit.clear()
                self.mostrar_historial_chat()

    def cargar_conversacion_con(self, id_otro_usuario: int):
        user_actual = models.leer_usuario_actual()
        database = models.obtener_db()
        if not user_actual or not database: return []

        mi_id = user_actual.id if hasattr(user_actual, 'id') else user_actual.getId()

        # 1. Obtenemos los mensajes (vienen desordenados de la BD)
        mensajes_brutos = database.get_mensajes_entre_usuarios(mi_id, id_otro_usuario)

        # 2. Aplicamos nuestro algoritmo Quicksort
        mensajes_ordenados = self.quicksort_mensajes(mensajes_brutos)

        # 3. Marcamos quién es el emisor para la UI
        for m in mensajes_ordenados:
            m['soy_yo'] = (m['emisor_id'] == mi_id)

        return mensajes_ordenados

    def actualizar_chat_periodico(self):
        """Refresca el chat automáticamente si hay una conversación activa."""
        # 1. Comprobamos si el usuario ya ha seleccionado un chat con alguien
        if hasattr(self, 'id_receptor_actual'):
            # Forzamos la actualización sin importar el index para descartar errores de UI
            print(f"[TIMER] Actualizando chat de forma automática para el receptor ID: {self.id_receptor_actual}")
            self.mostrar_historial_chat()
    def quicksort_mensajes(self, lista_mensajes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Ordena los mensajes por el campo 'date' usando el algoritmo Quicksort.
        """
        if len(lista_mensajes) <= 1:
            return lista_mensajes

        # Elegimos el pivote (el elemento central)
        pivote = lista_mensajes[len(lista_mensajes) // 2]
        fecha_pivote = pivote['date']

        # Particionamos la lista
        izq = [x for x in lista_mensajes if x['date'] < fecha_pivote]
        centro = [x for x in lista_mensajes if x['date'] == fecha_pivote]
        der = [x for x in lista_mensajes if x['date'] > fecha_pivote]

        # Recursividad
        return self.quicksort_mensajes(izq) + centro + self.quicksort_mensajes(der)

    def cargar_datos_parking(self):
        """Lee el archivo parking.txt y muestra las plazas en la Home"""
        ruta_archivo = "parking.txt"

        try:
            # Abrimos y leemos el contenido del .txt
            with open(ruta_archivo, "r", encoding="utf-8") as file:
                datos_parking = file.read().strip()  # Leerá "34/50"

            texto_mostrar = f"<b>Available Parking Spots:</b> {datos_parking}"

            self.ui.label_parking.setText(texto_mostrar)
            print(f"Datos de parking cargados: {datos_parking}")

        except FileNotFoundError:
            print("Aviso: No se encontró el archivo parking.txt")
            self.ui.label_parking.setText("Parking: Error de lectura")

        except Exception as e:
            print(f"Error leyendo el parking: {e}")



    def cargar_grafica_historico(self):
        """Generates a 2x2 grid of historical graphs for each sensor type using visualizacion_sensores"""
        contenedor = self.ui.frame_grafica
        if not contenedor.layout():
            layout = QVBoxLayout(contenedor)
            layout.setContentsMargins(5, 5, 5, 5)
        else:
            layout = contenedor.layout()

        # 1. Crear la figura principal con fondo transparente
        # Aumentamos un pelín el figsize para que quepan bien las 4 gráficas
        fig = Figure(figsize=(10, 6), dpi=100)
        fig.patch.set_alpha(0.0)

        # Añadimos espacio vertical y horizontal entre las gráficas para que no se solapen los textos
        fig.subplots_adjust(hspace=0.5, wspace=0.3)

        # 2. Obtener los datos de la vista a través del modelo
        try:
            datos_vista = models.obtener_historico_vista()  # <--- AHORA LLAMA A LA FUNCIÓN NUEVA
        except Exception as e:
            print(f"❌ Error reading from visualizacion_sensores: {e}")
            datos_vista = []

        # 3. Agrupar y ordenar cronológicamente las lecturas por cada id_sensor
        from collections import defaultdict
        grup_sensores = defaultdict(list)

        for fila in datos_vista:
            id_s = int(fila['id_sensor'])
            # Guardamos la tupla (fecha, valor)
            grup_sensores[id_s].append((fila['date'], float(fila['dato'])))

        # 4. Configurar el mapeo de los 4 sensores en la cuadrícula 2x2
        # ⚠️ REVISA ESTOS NÚMEROS: Cambia el 1, 5, 4, 6 por los ID reales que tengan tus sensores en la BD
        sensor_mapping = {
            0: {"title": "Temperature History (°C)", "color": "#D81B60", "pos": 1},  # Top-Left
            4: {"title": "Light History (Brightness)", "color": "#FFA000", "pos": 2},  # Top-Right
            3: {"title": "Air Quality History", "color": "#2E7D32", "pos": 3},  # Bottom-Left
            6: {"title": "Sound Level History", "color": "#1565C0", "pos": 4}  # Bottom-Right (Ajusta si es otro ID)
        }

        # 5. Dibujar cada uno de los 4 subplots
        import matplotlib.dates as mdates

        for s_id, info in sensor_mapping.items():
            # add_subplot(filas, columnas, posición) -> malla 2x2
            ax = fig.add_subplot(2, 2, info["pos"])
            ax.set_facecolor('none')  # Fondo del subplot transparente

            # Si el sensor tiene datos en la BD, los dibujamos
            if s_id in grup_sensores and grup_sensores[s_id]:

                # ---------------------------------------------------------
                # 🛠️ CAMBIO 1: Coger solo las últimas 15 lecturas (las más recientes)
                # ---------------------------------------------------------
                fechas = [x[0] for x in grup_sensores[s_id]][-15:]
                valores = [x[1] for x in grup_sensores[s_id]][-15:]

                ax.plot(fechas, valores, color=info["color"], marker='o', linestyle='-', linewidth=1.5, markersize=3)

                # ---------------------------------------------------------
                # 🛠️ CAMBIO 2: Añadir los segundos (%S) para ver cambios en tiempo real
                # ---------------------------------------------------------
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
            else:
                # Si este sensor específico no tiene datos, ponemos un aviso visual sutil
                ax.text(0.5, 0.5, "No Data Available", color='#777777', ha='center', va='center',
                        transform=ax.transAxes, fontsize=9)

            # Estilo estético e inglés nativo para cada sub-gráfica
            ax.set_title(info["title"], color='#333333', fontweight='bold', fontsize=10)
            ax.tick_params(axis='x', colors='#333333', labelsize=8, rotation=15)
            ax.tick_params(axis='y', colors='#333333', labelsize=8)
            ax.grid(True, linestyle='--', alpha=0.3, color='#666666')

            # Ocultar bordes innecesarios para diseño limpio
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.spines['bottom'].set_color('#333333')
            ax.spines['left'].set_color('#333333')

        # 6. Integrar el lienzo (Canvas) en tu interfaz de PySide6
        canvas = FigureCanvas(fig)

        # Limpiar cualquier contenido antiguo del layout antes de meter la nueva malla
        for i in reversed(range(layout.count())):
            widget = layout.itemAt(i).widget()
            if widget is not None:
                widget.setParent(None)

        layout.addWidget(canvas)

# ==========================================
# EJECUCIÓN PRINCIPAL
# ==========================================
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = WorkerWindow()
    window.show()
    sys.exit(app.exec())
