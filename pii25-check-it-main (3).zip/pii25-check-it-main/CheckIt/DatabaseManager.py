import pymysql
from typing import List, Dict, Any, Optional

class DatabaseManager:

    def __init__(self, host: str = 'localhost', user: str = 'root', password: str = '', database: str = 'pii26-check-it'):
        """
        Inicializa la conexión a la base de datos MySQL/MariaDB.
        :param host: Host del servidor MySQL (ej. 'localhost').
        :param user: Usuario de la base de datos.
        :param password: Contraseña del usuario.
        :param database: Nombre de la base de datos.
        """
        self.host = host
        self.user = user
        self.password = password
        self.database = database
        self.connection = None
        self.cursor = None

    def connect(self):
        """Establece la conexión a la base de datos."""
        try:
            self.connection = pymysql.connect(
                host=self.host,
                user=self.user,
                password=self.password,
                database=self.database,
                charset='utf8mb4',
                cursorclass=pymysql.cursors.DictCursor,  # Para devolver resultados como diccionarios
                autocommit = True
            )
            self.cursor = self.connection.cursor()
            print("Conexión a la base de datos MySQL/MariaDB establecida.")
        except pymysql.Error as e:
            print(f"Error al conectar a la base de datos: {e}")
            raise

    def disconnect(self):
        """Cierra la conexión a la base de datos."""
        if self.connection:
            self.connection.close()
            print("Conexión cerrada.")

    def execute_query(self, query: str, params: tuple = ()) -> List[Dict[str, Any]]:
        """
        Ejecuta una consulta SELECT y devuelve los resultados.
        :param query: La consulta SQL.
        :param params: Parámetros para la consulta.
        :return: Lista de diccionarios con los resultados.
        """
        if not self.connection:
            raise Exception("No hay conexión a la base de datos. Llama a connect() primero.")
        try:
            self.cursor.execute(query, params)
            results = self.cursor.fetchall()
            return results
        except pymysql.Error as e:
            print(f"Error al ejecutar la consulta: {e}")
            raise

    def execute_insert(self, table: str, data: Dict[str, Any]) -> int:
        """
        Inserta datos en una tabla.
        :param table: Nombre de la tabla.
        :param data: Diccionario con los datos a insertar (clave: columna, valor: dato).
        :return: ID del registro insertado.
        """
        if not self.connection:
            raise Exception("No hay conexión a la base de datos. Llama a connect() primero.")
        try:
            columns = ', '.join(data.keys())
            placeholders = ', '.join(['%s'] * len(data))
            values = tuple(data.values())
            query = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
            self.cursor.execute(query, values)
            self.connection.commit()
            return self.cursor.lastrowid
        except pymysql.Error as e:
            print(f"Error al insertar datos: {e}")
            self.connection.rollback()
            raise

    def execute_update(self, table: str, data: Dict[str, Any], where: str, params: tuple = ()):
        """
        Actualiza datos en una tabla.
        :param table: Nombre de la tabla.
        :param data: Diccionario con los datos a actualizar.
        :param where: Cláusula WHERE.
        :param params: Parámetros para la cláusula WHERE.
        """
        if not self.connection:
            raise Exception("No hay conexión a la base de datos. Llama a connect() primero.")
        try:
            set_clause = ', '.join([f"{k} = %s" for k in data.keys()])
            values = tuple(data.values()) + params
            query = f"UPDATE {table} SET {set_clause} WHERE {where}"
            self.cursor.execute(query, values)
            self.connection.commit()
        except pymysql.Error as e:
            print(f"Error al actualizar datos: {e}")
            self.connection.rollback()
            raise

    def execute_delete(self, table: str, where: str, params: tuple = ()):
        """
        Elimina datos de una tabla.
        :param table: Nombre de la tabla.
        :param where: Cláusula WHERE.
        :param params: Parámetros para la cláusula WHERE.
        """
        if not self.connection:
            raise Exception("No hay conexión a la base de datos. Llama a connect() primero.")
        try:
            query = f"DELETE FROM {table} WHERE {where}"
            self.cursor.execute(query, params)
            self.connection.commit()
        except pymysql.Error as e:
            print(f"Error al eliminar datos: {e}")
            self.connection.rollback()
            raise

    def get_all(self, table: str) -> List[Dict[str, Any]]:
        """
        Obtiene todos los registros de una tabla.
        :param table: Nombre de la tabla.
        :return: Lista de diccionarios con los registros.
        """
        query = f"SELECT * FROM {table}"
        return self.execute_query(query)

    def get_by_id(self, table: str, id_value: Any) -> Optional[Dict[str, Any]]:
        """
        Obtiene un registro por ID.
        :param table: Nombre de la tabla.
        :param id_value: Valor del ID.
        :return: Diccionario con el registro o None si no existe.
        """
        query = f"SELECT * FROM {table} WHERE id = %s"
        results = self.execute_query(query, (id_value,))
        return results[0] if results else None

    # ============================================================================
    # MÉTODOS ESPECÍFICOS PARA USUARIOS
    # ============================================================================

    def get_usuario_by_correo(self, correo: str) -> Optional[Dict[str, Any]]:
        """Obtiene un usuario por su correo"""
        query = "SELECT * FROM usuario WHERE mail = %s"
        results = self.execute_query(query, (correo,))
        return results[0] if results else None

    def get_usuario_auth(self, correo: str) -> Optional[Dict[str, Any]]:

        query = "SELECT id, mail, password_hash, type FROM usuario WHERE mail = %s LIMIT 1"
        results = self.execute_query(query, (correo,))
        return results[0] if results else None

    def get_all_usuarios(self) -> List[Dict[str, Any]]:
        """Obtiene todos los usuarios """
        query = "SELECT id, mail, password_hash, type, name, last_name, DNI FROM usuario ORDER BY id ASC"
        return self.execute_query(query)

    def insertar_usuario(self, email: str, contrasena: str, tipo: str, nombre: str = None,
                        last_name: str = None, dni: str = None) -> int:
        """
        Inserta un nuevo usuario en la tabla usuario.
        email: Correo del usuario
        contrasena: Contraseña encriptada
        tipo: Tipo de usuario (Usuario Promedio, Trabajador, Administrador)
        nombre: Nombre del usuario
        last_name: Apellido del usuario
        dni: DNI del usuario
        return: ID del usuario insertado
        """
        data = {
            'mail': email,
            'password_hash': contrasena,  # Nota: en la BD es 'password_hash'
            'type': tipo,  # Nota: en la BD es 'type'
            'name': nombre,
            'last_name': last_name,
            'DNI': dni
        }
        return self.execute_insert('usuario', data)

    def actualizar_usuario(self, usuario_id: int, data: Dict[str, Any]):
        """Actualiza los datos de un usuario por ID."""
        self.execute_update('usuario', data, 'id = %s', (usuario_id,))

    def eliminar_usuario(self, usuario_id: int):
        """Elimina un usuario por ID."""
        self.execute_delete('usuario', 'id = %s', (usuario_id,))

    def eliminar_usuario_por_correo(self, correo: str):
        """Elimina un usuario por su correo."""
        self.execute_delete('usuario', 'mail = %s', (correo,))

    # ============================================================================
    # MÉTODOS ESPECÍFICOS PARA SENSORES
    # ============================================================================

    def get_all_sensores(self) -> List[Dict[str, Any]]:
        """Obtiener los datos de todos los sensores """
        query = "SELECT * FROM sensor ORDER BY id ASC"
        return self.execute_query(query)

    def get_sensores_by_zone(self, zone: int) -> List[Dict[str, Any]]:
        """Obtiene todos los sensores de una zona específica."""
        query = "SELECT * FROM sensor WHERE zone = %s"
        return self.execute_query(query, (zone,))

    def get_sensores_by_type(self, sensor_type: int) -> List[Dict[str, Any]]:
        """
        Obtiene todos los sensores de un tipo específico.
        sensor_type: Tipo de sensor
        """
        query = "SELECT * FROM sensor WHERE type = %s"
        return self.execute_query(query, (sensor_type,))

    def insertar_sensor(self, zone: int, value: float, max_val: float, min_val: float,
                       working: float, sensor_type: int) -> int:
        """
        Inserta un nuevo sensor.
        zone: Zona del sensor
        value: Valor actual del sensor
        max_val: Valor máximo
        min_val: Valor mínimo
        working: Estado de funcionamiento
        sensor_type: Tipo de sensor
        return: ID del sensor insertado
        """
        data = {
            'zone': zone,
            'value': value,
            'max': max_val,
            'minimum': min_val,
            'working': working,
            'type': sensor_type
        }
        return self.execute_insert('sensor', data)

    def actualizar_sensor(self, sensor_id: int, data: Dict[str, Any]):
        """Actualiza los datos de un sensor por ID."""
        self.execute_update('sensor', data, 'id = %s', (sensor_id,))

    def actualizar_valor_sensor(self, sensor_id: int, nuevo_valor: float):
        """Actualiza solo el valor de un sensor."""
        self.execute_update('sensor', {'value': nuevo_valor}, 'id = %s', (sensor_id,))

    def eliminar_sensor(self, sensor_id: int):
        """Elimina un sensor por ID."""
        self.execute_delete('sensor', 'id = %s', (sensor_id,))
# ============================================================================
    # MÉTODOS ESPECÍFICOS PARA CHAT Y MENSAJES
    # ============================================================================

    def get_trabajadores(self) -> List[Dict[str, Any]]:
        """Obtiene solo los usuarios que son trabajadores para la lista de contactos."""
        query = "SELECT id, name, last_name, mail FROM usuario WHERE type = '2' ORDER BY name ASC"
        return self.execute_query(query)

    def insertar_mensaje_contenido(self, contenido: str) -> int:
        """Inserta el texto en la tabla mensaje y devuelve su ID."""
        # Nota: 'date' suele ser CURRENT_TIMESTAMP en la BD, si no, lo añadimos aquí.
        data = {'content': contenido}
        return self.execute_insert('mensaje', data)

    def vincular_mensaje_a_chat(self, id_emisor: int, id_receptor: int, id_mensaje: int):
        """Crea la relación en la tabla chat entre emisor, receptor y el mensaje."""
        data = {
            'id_usuario1': id_emisor,
            'id_usuario2': id_receptor,
            'id_mensaje': id_mensaje
        }
        return self.execute_insert('chat', data)

    def get_mensajes_entre_usuarios(self, id_actual: int, id_otro: int) -> List[Dict[str, Any]]:
        query = """
            SELECT m.content, m.date, c.id_usuario1 AS emisor_id
            FROM mensaje m
            JOIN chat c ON m.id = c.id_mensaje
            WHERE (c.id_usuario1 = %s AND c.id_usuario2 = %s)
               OR (c.id_usuario1 = %s AND c.id_usuario2 = %s)
        """
        # La base de datos devolverá los mensajes en el orden en que los encuentre
        return self.execute_query(query, (id_actual, id_otro, id_otro, id_actual))

