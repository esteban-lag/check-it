# -*- coding: utf-8 -*-
import sys
from PySide6.QtCore import Qt, QRect, QRectF, QSize
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QLabel,
    QSizePolicy, QMessageBox, QGridLayout, QFrame, QHBoxLayout)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from ui_form import Ui_MainWindow
from register_window import RegisterWindow
from UserController import UserWindow
from WorkerController import WorkerWindow
from AdministratorController import AdministratorWindow
import models


# --- Ventana principal (login) ---
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        # INICIALIZAR LA CONEXIÓN A LA BD
        try:
            models.inicializar_bd()
            print("Conexión a BD inicializada correctamente")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo conectar a la BD: {e}")
            print(f"Error al conectar a la BD: {e}")
        
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        layout_principal = QVBoxLayout(self.ui.centralwidget)
        layout_principal.setContentsMargins(0, 0, 0, 0)
        layout_principal.addWidget(self.ui.frame)
        layout_fondo = QGridLayout(self.ui.frame)
        layout_fondo.addWidget(self.ui.frame_4, 0, 0, Qt.AlignmentFlag.AlignCenter)

        # Conectar el link del QLabel
        self.ui.label_3.linkActivated.connect(self.abrir_registro)

        # Crear instancias de las ventanas secundarias
        self.user_window = UserWindow()
        self.worker_window = WorkerWindow()
        self.admin_window = AdministratorWindow()

        # 🔹 Cargar usuarios desde BD (a través de models)
        try:
            self.usuarios = models.cargar_usuarios()
        except Exception as e:
            QMessageBox.warning(self, "Advertencia", f"No se pudieron cargar los usuarios: {e}")
            self.usuarios = []

        # Conectar botón de login
        self.ui.pushButton.clicked.connect(self.iniciar_sesion)

    # -------------------------
    # 🔹 ABRIR REGISTRO
    # -------------------------
    def abrir_registro(self):
        self.registro_window = RegisterWindow(self)
        self.registro_window.show()
        self.hide()

    # -------------------------
    # 🔹 VOLVER AL LOGIN
    # -------------------------
    def volver_login(self):
        self.show()
        if hasattr(self, 'registro_window'):
            self.registro_window.close()

    # -------------------------
    # 🔹 INICIAR SESIÓN
    # -------------------------


    def iniciar_sesion(self):
        correo = self.ui.lineEdit.text().strip()
        contrasena = self.ui.lineEdit_2.text().strip()

        if not correo or not contrasena:
            QMessageBox.warning(self, "Campos vacíos", "Por favor ingresa correo y contraseña.")
            return

        # Buscar el usuario en la lista cargada
        usuario = models.login(correo, contrasena)
        models.guardar_usuario_actual(usuario)
        print(models.leer_usuario_actual())

        if usuario != False:
            QMessageBox.information(self, "Acceso concedido", f"Bienvenido {usuario.nombre}")

            if usuario.tipo == 1:
                self.user_window.show()
            elif usuario.tipo == 2:
                self.worker_window.show()
            elif usuario.tipo == 3:
                self.admin_window.show()

            self.hide()
            # Limpiar campos
            self.ui.lineEdit.clear()
            self.ui.lineEdit_2.clear()
            return

        # Si no se encontró el usuario
        QMessageBox.warning(self, "Error", "Correo o contraseña incorrectos.")


# --- Inicio del programa ---
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
