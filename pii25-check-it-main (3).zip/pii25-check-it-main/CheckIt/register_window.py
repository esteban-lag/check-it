# -*- coding: utf-8 -*-
from PySide6.QtWidgets import QMainWindow, QMessageBox
from PySide6.QtCore import Qt
from ui_Register import Ui_Register
import models


class RegisterWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = Ui_Register()
        self.ui.setupUi(self)

        # Conexión de botones
        self.ui.Confirm_PushButton.clicked.connect(self.registrar_usuario)
        self.ui.btnVolver.clicked.connect(self.volver_login)

    def registrar_usuario(self):
        correo = self.ui.Mail_Line_Edit.text().strip()
        nombre = self.ui.Name_Line_Edit.text().strip()
        apellido = self.ui.Surname_Line_Edit.text().strip()
        contrasena = self.ui.PassWord_Line_Edit.text()
        confirmar = self.ui.PassWordVerifier_Line_Edit.text()
        es_trabajador = self.ui.radioButton.isChecked()

        # --- Validaciones ---
        if not correo or not contrasena or not confirmar:
            QMessageBox.warning(self, "Campos vacíos", "Por favor completa todos los campos obligatorios.")
            return

        if contrasena != confirmar:
            QMessageBox.warning(self, "Error", "Las contraseñas no coinciden.")
            return

        tipo = "Trabajador" if es_trabajador else "Usuario Promedio"

        # --- Creación del usuario ---
        try:
            usuario = models.crear_usuario(
                correo=correo,
                contrasena=contrasena,
                tipo=tipo,
                nombre=nombre,
                apellido=apellido
            )
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Ocurrió un error al registrar: {e}")
            return

        # --- Confirmación ---
        QMessageBox.information(
            self,
            "Registro exitoso",
            f"El usuario '{correo}' se registró correctamente como {tipo}."
        )

        # Limpiar campos después del registro
        self.ui.Mail_Line_Edit.clear()
        self.ui.Name_Line_Edit.clear()
        self.ui.Surname_Line_Edit.clear()
        self.ui.PassWord_Line_Edit.clear()
        self.ui.PassWordVerifier_Line_Edit.clear()
        self.ui.radioButton.setChecked(False)

        # Volver al login
        self.volver_login()

    def volver_login(self):
        """Cierra el registro y vuelve a la ventana de login (padre)."""
        if self.parent():
            self.parent().show()
        self.close()
