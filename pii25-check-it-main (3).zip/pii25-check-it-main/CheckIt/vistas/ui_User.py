# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'User.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QLabel, QMainWindow,
    QMenuBar, QPushButton, QSizePolicy, QStatusBar,
    QWidget)
import rc_Recursos

class Ui_UserWindow(object):
    def setupUi(self, UserWindow):
        if not UserWindow.objectName():
            UserWindow.setObjectName(u"UserWindow")
        UserWindow.resize(800, 600)
        self.centralwidget = QWidget(UserWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(0, 0, 800, 581))
        self.frame.setStyleSheet(u"")
        self.frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame.setFrameShadow(QFrame.Shadow.Raised)
        self.pushButton = QPushButton(self.frame)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(220, 20, 75, 24))
        self.pushButton.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"    font: bold 16px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton.setCheckable(False)
        self.pushButton.setChecked(False)
        self.pushButton_2 = QPushButton(self.frame)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(300, 20, 75, 24))
        self.pushButton_2.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"    font: bold 16px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_3 = QPushButton(self.frame)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setGeometry(QRect(380, 20, 75, 24))
        self.pushButton_3.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"    font: bold 16px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_4 = QPushButton(self.frame)
        self.pushButton_4.setObjectName(u"pushButton_4")
        self.pushButton_4.setGeometry(QRect(460, 20, 75, 24))
        self.pushButton_4.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"    font: bold 16px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_5 = QPushButton(self.frame)
        self.pushButton_5.setObjectName(u"pushButton_5")
        self.pushButton_5.setGeometry(QRect(540, 20, 75, 24))
        self.pushButton_5.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"    font: bold 16px \"Segoe UI\";\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(0, 0, 800, 70))
        self.label.setPixmap(QPixmap(u":/Login/Topcornerusers.png"))
        self.label.setScaledContents(True)
        self.label_2 = QLabel(self.frame)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(20, 20, 100, 100))
        self.label_2.setPixmap(QPixmap(u":/Login/Check-it 1.png"))
        self.label_2.setScaledContents(True)
        self.label.raise_()
        self.pushButton.raise_()
        self.pushButton_2.raise_()
        self.pushButton_3.raise_()
        self.pushButton_4.raise_()
        self.pushButton_5.raise_()
        self.label_2.raise_()
        UserWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(UserWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 800, 22))
        UserWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(UserWindow)
        self.statusbar.setObjectName(u"statusbar")
        UserWindow.setStatusBar(self.statusbar)

        self.retranslateUi(UserWindow)

        QMetaObject.connectSlotsByName(UserWindow)
    # setupUi

    def retranslateUi(self, UserWindow):
        UserWindow.setWindowTitle(QCoreApplication.translate("UserWindow", u"MainWindow", None))
        self.pushButton.setText(QCoreApplication.translate("UserWindow", u"Home", None))
        self.pushButton_2.setText(QCoreApplication.translate("UserWindow", u"News", None))
        self.pushButton_3.setText(QCoreApplication.translate("UserWindow", u"Status", None))
        self.pushButton_4.setText(QCoreApplication.translate("UserWindow", u"Sectors", None))
        self.pushButton_5.setText(QCoreApplication.translate("UserWindow", u"Profile", None))
        self.label.setText("")
        self.label_2.setText("")
    # retranslateUi

