# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'UserWORKER.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QHBoxLayout,
    QLabel, QLayout, QLineEdit, QMainWindow,
    QPlainTextEdit, QPushButton, QScrollArea, QSizePolicy,
    QSpacerItem, QStackedWidget, QVBoxLayout, QWidget)

from componentes import (CalidadAireWidget, SensorLuzWidget, SensorRuidoWidget, TermostatoWidget)
import Recursos_rc

class Ui_WorkerWindow(object):
    def setupUi(self, WorkerWindow):
        if not WorkerWindow.objectName():
            WorkerWindow.setObjectName(u"WorkerWindow")
        WorkerWindow.resize(842, 609)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(WorkerWindow.sizePolicy().hasHeightForWidth())
        WorkerWindow.setSizePolicy(sizePolicy)
        self.centralwidget = QWidget(WorkerWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(0, 0, 842, 609))
        self.frame.setStyleSheet(u"background-color: white")
        self.frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame.setFrameShadow(QFrame.Shadow.Plain)
        self.gridLayout = QGridLayout(self.frame)
        self.gridLayout.setSpacing(0)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.frame_2 = QFrame(self.frame)
        self.frame_2.setObjectName(u"frame_2")
        sizePolicy.setHeightForWidth(self.frame_2.sizePolicy().hasHeightForWidth())
        self.frame_2.setSizePolicy(sizePolicy)
        self.frame_2.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_5 = QGridLayout(self.frame_2)
        self.gridLayout_5.setSpacing(0)
        self.gridLayout_5.setObjectName(u"gridLayout_5")
        self.gridLayout_5.setContentsMargins(0, 0, 0, 0)
        self.frame_3 = QFrame(self.frame_2)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setAutoFillBackground(False)
        self.frame_3.setStyleSheet(u".QFrame {\n"
"    border-image: url(:/login/Topcornerusers.png);\n"
"}")
        self.frame_3.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.frame_3)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(2, 2, 2, 2)
        self.label = QLabel(self.frame_3)
        self.label.setObjectName(u"label")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy1)
        self.label.setMinimumSize(QSize(80, 80))
        self.label.setMaximumSize(QSize(150, 150))
        self.label.setSizeIncrement(QSize(1, 1))
        self.label.setAutoFillBackground(False)
        self.label.setStyleSheet(u"QLabel{\n"
"	\n"
"	background-color: rgb(251, 251, 251);\n"
"    border: none; /* A veces el borde a\u00f1ade color */\n"
"}")
        self.label.setPixmap(QPixmap(u":/login/Check-it 1.png"))
        self.label.setScaledContents(True)

        self.horizontalLayout_2.addWidget(self.label)

        self.horizontalSpacer_3 = QSpacerItem(185, 20, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_3)

        self.pushButton = QPushButton(self.frame_3)
        self.pushButton.setObjectName(u"pushButton")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.pushButton.sizePolicy().hasHeightForWidth())
        self.pushButton.setSizePolicy(sizePolicy2)
        font = QFont()
        font.setPointSize(12)
        font.setBold(True)
        self.pushButton.setFont(font)
        self.pushButton.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton.setCheckable(False)
        self.pushButton.setChecked(False)

        self.horizontalLayout_2.addWidget(self.pushButton)

        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_5)

        self.pushButton_2 = QPushButton(self.frame_3)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setFont(font)
        self.pushButton_2.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_2.setCheckable(False)

        self.horizontalLayout_2.addWidget(self.pushButton_2)

        self.horizontalSpacer_6 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_6)

        self.pushButton_3 = QPushButton(self.frame_3)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setFont(font)
        self.pushButton_3.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_3.setCheckable(False)

        self.horizontalLayout_2.addWidget(self.pushButton_3)

        self.horizontalSpacer_29 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_29)

        self.pushButton_4 = QPushButton(self.frame_3)
        self.pushButton_4.setObjectName(u"pushButton_4")
        self.pushButton_4.setFont(font)
        self.pushButton_4.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_4.setCheckable(False)

        self.horizontalLayout_2.addWidget(self.pushButton_4)

        self.horizontalSpacer_7 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_7)

        self.pushButton_5 = QPushButton(self.frame_3)
        self.pushButton_5.setObjectName(u"pushButton_5")
        self.pushButton_5.setFont(font)
        self.pushButton_5.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_5.setCheckable(False)

        self.horizontalLayout_2.addWidget(self.pushButton_5)

        self.horizontalSpacer_8 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_8)

        self.pushButton_9 = QPushButton(self.frame_3)
        self.pushButton_9.setObjectName(u"pushButton_9")
        sizePolicy2.setHeightForWidth(self.pushButton_9.sizePolicy().hasHeightForWidth())
        self.pushButton_9.setSizePolicy(sizePolicy2)
        self.pushButton_9.setFont(font)
        self.pushButton_9.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_9.setCheckable(False)
        self.pushButton_9.setChecked(False)

        self.horizontalLayout_2.addWidget(self.pushButton_9)

        self.horizontalSpacer_25 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_25)

        self.pushButton_8 = QPushButton(self.frame_3)
        self.pushButton_8.setObjectName(u"pushButton_8")
        self.pushButton_8.setFont(font)
        self.pushButton_8.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_8.setCheckable(False)

        self.horizontalLayout_2.addWidget(self.pushButton_8)

        self.horizontalSpacer_4 = QSpacerItem(185, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_4)

        self.horizontalLayout_2.setStretch(0, 1)
        self.horizontalLayout_2.setStretch(3, 1)
        self.horizontalLayout_2.setStretch(5, 1)
        self.horizontalLayout_2.setStretch(7, 1)
        self.horizontalLayout_2.setStretch(9, 1)
        self.horizontalLayout_2.setStretch(11, 1)
        self.horizontalLayout_2.setStretch(13, 1)
        self.horizontalLayout_2.setStretch(15, 1)

        self.gridLayout_5.addWidget(self.frame_3, 0, 0, 2, 1)

        self.gridLayout_5.setRowStretch(0, 2)

        self.verticalLayout_3.addWidget(self.frame_2)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.stackedWidget = QStackedWidget(self.frame)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.Home = QWidget()
        self.Home.setObjectName(u"Home")
        self.gridLayout_2 = QGridLayout(self.Home)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.LastNewsPanel = QFrame(self.Home)
        self.LastNewsPanel.setObjectName(u"LastNewsPanel")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.LastNewsPanel.sizePolicy().hasHeightForWidth())
        self.LastNewsPanel.setSizePolicy(sizePolicy3)
        self.LastNewsPanel.setFrameShape(QFrame.Shape.NoFrame)
        self.LastNewsPanel.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_5 = QVBoxLayout(self.LastNewsPanel)
        self.verticalLayout_5.setSpacing(5)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.horizontalSpacer_23 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_6.addItem(self.horizontalSpacer_23)

        self.Title_7 = QLabel(self.LastNewsPanel)
        self.Title_7.setObjectName(u"Title_7")
        self.Title_7.setStyleSheet(u"color: red;\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid red;")
        self.Title_7.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_6.addWidget(self.Title_7)

        self.horizontalSpacer_24 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_6.addItem(self.horizontalSpacer_24)


        self.verticalLayout_5.addLayout(self.horizontalLayout_6)

        self.horizontalLayout_15 = QHBoxLayout()
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.horizontalLayout_15.setContentsMargins(25, -1, 25, -1)
        self.line_8 = QFrame(self.LastNewsPanel)
        self.line_8.setObjectName(u"line_8")
        self.line_8.setAutoFillBackground(False)
        self.line_8.setStyleSheet(u"color: red")
        self.line_8.setFrameShadow(QFrame.Shadow.Plain)
        self.line_8.setLineWidth(2)
        self.line_8.setMidLineWidth(2)
        self.line_8.setFrameShape(QFrame.Shape.HLine)

        self.horizontalLayout_15.addWidget(self.line_8)


        self.verticalLayout_5.addLayout(self.horizontalLayout_15)

        self.New_3 = QLabel(self.LastNewsPanel)
        self.New_3.setObjectName(u"New_3")
        font1 = QFont()
        font1.setPointSize(7)
        self.New_3.setFont(font1)
        self.New_3.setStyleSheet(u"COLOR: BLACK;")
        self.New_3.setFrameShadow(QFrame.Shadow.Plain)
        self.New_3.setTextFormat(Qt.TextFormat.PlainText)
        self.New_3.setScaledContents(False)
        self.New_3.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.New_3.setWordWrap(True)

        self.verticalLayout_5.addWidget(self.New_3)

        self.horizontalLayout_31 = QHBoxLayout()
        self.horizontalLayout_31.setObjectName(u"horizontalLayout_31")
        self.horizontalLayout_31.setContentsMargins(-1, 25, -1, 40)
        self.pushButton_7 = QPushButton(self.LastNewsPanel)
        self.pushButton_7.setObjectName(u"pushButton_7")
        sizePolicy2.setHeightForWidth(self.pushButton_7.sizePolicy().hasHeightForWidth())
        self.pushButton_7.setSizePolicy(sizePolicy2)
        font2 = QFont()
        font2.setPointSize(10)
        font2.setBold(True)
        self.pushButton_7.setFont(font2)
        self.pushButton_7.setStyleSheet(u"QPushButton {\n"
"background-color: #56E765; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_7.setCheckable(False)
        self.pushButton_7.setChecked(False)

        self.horizontalLayout_31.addWidget(self.pushButton_7)

        self.pushButton_6 = QPushButton(self.LastNewsPanel)
        self.pushButton_6.setObjectName(u"pushButton_6")
        sizePolicy2.setHeightForWidth(self.pushButton_6.sizePolicy().hasHeightForWidth())
        self.pushButton_6.setSizePolicy(sizePolicy2)
        self.pushButton_6.setFont(font2)
        self.pushButton_6.setStyleSheet(u"QPushButton {\n"
"background-color: #DC3434; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_6.setCheckable(False)
        self.pushButton_6.setChecked(False)

        self.horizontalLayout_31.addWidget(self.pushButton_6)


        self.verticalLayout_5.addLayout(self.horizontalLayout_31)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer_2)

        self.Title = QLabel(self.LastNewsPanel)
        self.Title.setObjectName(u"Title")
        self.Title.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_3.addWidget(self.Title)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer)


        self.verticalLayout_5.addLayout(self.horizontalLayout_3)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(25, -1, 25, -1)
        self.line = QFrame(self.LastNewsPanel)
        self.line.setObjectName(u"line")
        self.line.setAutoFillBackground(False)
        self.line.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line.setFrameShadow(QFrame.Shadow.Plain)
        self.line.setLineWidth(2)
        self.line.setMidLineWidth(2)
        self.line.setFrameShape(QFrame.Shape.HLine)

        self.horizontalLayout_4.addWidget(self.line)


        self.verticalLayout_5.addLayout(self.horizontalLayout_4)

        self.label_3 = QLabel(self.LastNewsPanel)
        self.label_3.setObjectName(u"label_3")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Ignored)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.label_3.sizePolicy().hasHeightForWidth())
        self.label_3.setSizePolicy(sizePolicy4)
        self.label_3.setPixmap(QPixmap(u":/login/NewsImage.png"))
        self.label_3.setScaledContents(True)

        self.verticalLayout_5.addWidget(self.label_3)

        self.New = QLabel(self.LastNewsPanel)
        self.New.setObjectName(u"New")
        self.New.setFont(font1)
        self.New.setStyleSheet(u"COLOR: BLACK;")
        self.New.setFrameShadow(QFrame.Shadow.Plain)
        self.New.setTextFormat(Qt.TextFormat.PlainText)
        self.New.setScaledContents(False)
        self.New.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.New.setWordWrap(True)

        self.verticalLayout_5.addWidget(self.New)

        self.verticalLayout_5.setStretch(6, 1)
        self.verticalLayout_5.setStretch(7, 1)

        self.horizontalLayout_5.addWidget(self.LastNewsPanel)

        self.Data = QFrame(self.Home)
        self.Data.setObjectName(u"Data")
        sizePolicy3.setHeightForWidth(self.Data.sizePolicy().hasHeightForWidth())
        self.Data.setSizePolicy(sizePolicy3)
        self.Data.setFrameShape(QFrame.Shape.NoFrame)
        self.Data.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_11 = QGridLayout(self.Data)
        self.gridLayout_11.setObjectName(u"gridLayout_11")
        self.frame_grafica = QFrame(self.Data)
        self.frame_grafica.setObjectName(u"frame_grafica")
        self.frame_grafica.setStyleSheet(u"QFrame{\n"
"	border-radius: 30px;\n"
"	background-color: rgb(181, 231, 240);\n"
"}")
        self.frame_grafica.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_grafica.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_10 = QGridLayout(self.frame_grafica)
        self.gridLayout_10.setObjectName(u"gridLayout_10")

        self.gridLayout_11.addWidget(self.frame_grafica, 1, 0, 2, 4)

        self.widget_16 = CalidadAireWidget(self.Data)
        self.widget_16.setObjectName(u"widget_16")

        self.gridLayout_11.addWidget(self.widget_16, 0, 2, 1, 1)

        self.widget_12 = SensorRuidoWidget(self.Data)
        self.widget_12.setObjectName(u"widget_12")

        self.gridLayout_11.addWidget(self.widget_12, 0, 3, 1, 1)

        self.widget_15 = SensorLuzWidget(self.Data)
        self.widget_15.setObjectName(u"widget_15")

        self.gridLayout_11.addWidget(self.widget_15, 0, 1, 1, 1)

        self.widget_13 = TermostatoWidget(self.Data)
        self.widget_13.setObjectName(u"widget_13")

        self.gridLayout_11.addWidget(self.widget_13, 0, 0, 1, 1)

        self.label_parking = QLabel(self.Data)
        self.label_parking.setObjectName(u"label_parking")

        self.gridLayout_11.addWidget(self.label_parking, 3, 0, 1, 2)

        self.gridLayout_11.setRowStretch(0, 1)
        self.gridLayout_11.setRowStretch(1, 1)
        self.gridLayout_11.setRowStretch(2, 1)
        self.gridLayout_11.setColumnStretch(0, 1)
        self.gridLayout_11.setColumnStretch(1, 1)
        self.gridLayout_11.setColumnStretch(2, 1)
        self.gridLayout_11.setColumnStretch(3, 1)

        self.horizontalLayout_5.addWidget(self.Data)

        self.horizontalLayout_5.setStretch(0, 1)
        self.horizontalLayout_5.setStretch(1, 3)

        self.gridLayout_2.addLayout(self.horizontalLayout_5, 0, 1, 1, 1)

        self.stackedWidget.addWidget(self.Home)
        self.Chat = QWidget()
        self.Chat.setObjectName(u"Chat")
        self.gridLayout_14 = QGridLayout(self.Chat)
        self.gridLayout_14.setObjectName(u"gridLayout_14")
        self.scrollArea_12 = QScrollArea(self.Chat)
        self.scrollArea_12.setObjectName(u"scrollArea_12")
        self.scrollArea_12.setStyleSheet(u"")
        self.scrollArea_12.setFrameShape(QFrame.Shape.NoFrame)
        self.scrollArea_12.setFrameShadow(QFrame.Shadow.Plain)
        self.scrollArea_12.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scrollArea_12.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scrollArea_12.setWidgetResizable(True)
        self.scrollAreaWidgetContents_12 = QWidget()
        self.scrollAreaWidgetContents_12.setObjectName(u"scrollAreaWidgetContents_12")
        self.scrollAreaWidgetContents_12.setGeometry(QRect(0, 0, 117, 500))
        self.scrollAreaWidgetContents_12.setMinimumSize(QSize(100, 500))
        self.scrollAreaWidgetContents_12.setStyleSheet(u"")
        self.verticalLayout_32 = QVBoxLayout(self.scrollAreaWidgetContents_12)
        self.verticalLayout_32.setObjectName(u"verticalLayout_32")
        self.Title_13 = QLabel(self.scrollAreaWidgetContents_12)
        self.Title_13.setObjectName(u"Title_13")
        self.Title_13.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_13.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_32.addWidget(self.Title_13)

        self.Sector7_16 = QPushButton(self.scrollAreaWidgetContents_12)
        self.Sector7_16.setObjectName(u"Sector7_16")
        self.Sector7_16.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_16.setCheckable(False)
        self.Sector7_16.setChecked(False)

        self.verticalLayout_32.addWidget(self.Sector7_16)

        self.verticalLayout_32.setStretch(0, 1)
        self.verticalLayout_32.setStretch(1, 1)
        self.scrollArea_12.setWidget(self.scrollAreaWidgetContents_12)

        self.gridLayout_14.addWidget(self.scrollArea_12, 0, 0, 1, 1)

        self.stackedWidget_2 = QStackedWidget(self.Chat)
        self.stackedWidget_2.setObjectName(u"stackedWidget_2")
        self.NOCHAT = QWidget()
        self.NOCHAT.setObjectName(u"NOCHAT")
        self.verticalLayout_33 = QVBoxLayout(self.NOCHAT)
        self.verticalLayout_33.setObjectName(u"verticalLayout_33")
        self.verticalLayout_33.setContentsMargins(0, 0, 0, 0)
        self.verticalSpacer_63 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_33.addItem(self.verticalSpacer_63)

        self.horizontalLayout_34 = QHBoxLayout()
        self.horizontalLayout_34.setObjectName(u"horizontalLayout_34")
        self.label_19 = QLabel(self.NOCHAT)
        self.label_19.setObjectName(u"label_19")
        sizePolicy1.setHeightForWidth(self.label_19.sizePolicy().hasHeightForWidth())
        self.label_19.setSizePolicy(sizePolicy1)
        self.label_19.setMinimumSize(QSize(80, 80))
        self.label_19.setMaximumSize(QSize(150, 150))
        self.label_19.setSizeIncrement(QSize(1, 1))
        self.label_19.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.label_19.setAutoFillBackground(False)
        self.label_19.setStyleSheet(u"QLabel{\n"
"background-color: transparent; \n"
"    border: none; /* A veces el borde a\u00f1ade color */\n"
"}")
        self.label_19.setPixmap(QPixmap(u":/login/Check-it 1.png"))
        self.label_19.setScaledContents(True)
        self.label_19.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_19.setIndent(0)

        self.horizontalLayout_34.addWidget(self.label_19)


        self.verticalLayout_33.addLayout(self.horizontalLayout_34)

        self.label_20 = QLabel(self.NOCHAT)
        self.label_20.setObjectName(u"label_20")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.label_20.sizePolicy().hasHeightForWidth())
        self.label_20.setSizePolicy(sizePolicy5)
        self.label_20.setFont(font)
        self.label_20.setStyleSheet(u"    color: rgb(0, 191, 255);")
        self.label_20.setTextFormat(Qt.TextFormat.AutoText)
        self.label_20.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_33.addWidget(self.label_20)

        self.verticalSpacer_64 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_33.addItem(self.verticalSpacer_64)

        self.stackedWidget_2.addWidget(self.NOCHAT)
        self.CHAT = QWidget()
        self.CHAT.setObjectName(u"CHAT")
        self.verticalLayout_34 = QVBoxLayout(self.CHAT)
        self.verticalLayout_34.setObjectName(u"verticalLayout_34")
        self.verticalLayout_34.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_35 = QHBoxLayout()
        self.horizontalLayout_35.setObjectName(u"horizontalLayout_35")
        self.Image = QLabel(self.CHAT)
        self.Image.setObjectName(u"Image")
        sizePolicy1.setHeightForWidth(self.Image.sizePolicy().hasHeightForWidth())
        self.Image.setSizePolicy(sizePolicy1)
        self.Image.setMaximumSize(QSize(50, 50))
        self.Image.setPixmap(QPixmap(u":/login/Check-it 1.png"))
        self.Image.setScaledContents(True)

        self.horizontalLayout_35.addWidget(self.Image)

        self.User = QLabel(self.CHAT)
        self.User.setObjectName(u"User")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy6.setHorizontalStretch(0)
        sizePolicy6.setVerticalStretch(0)
        sizePolicy6.setHeightForWidth(self.User.sizePolicy().hasHeightForWidth())
        self.User.setSizePolicy(sizePolicy6)
        self.User.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.User.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_35.addWidget(self.User)

        self.horizontalSpacer_28 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_35.addItem(self.horizontalSpacer_28)

        self.horizontalLayout_35.setStretch(0, 1)
        self.horizontalLayout_35.setStretch(1, 5)
        self.horizontalLayout_35.setStretch(2, 100)

        self.verticalLayout_34.addLayout(self.horizontalLayout_35)

        self.Mensajes = QLabel(self.CHAT)
        self.Mensajes.setObjectName(u"Mensajes")
        self.Mensajes.setAlignment(Qt.AlignmentFlag.AlignBottom|Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft)

        self.verticalLayout_34.addWidget(self.Mensajes)

        self.horizontalLayout_36 = QHBoxLayout()
        self.horizontalLayout_36.setSpacing(0)
        self.horizontalLayout_36.setObjectName(u"horizontalLayout_36")
        self.plainTextEdit = QPlainTextEdit(self.CHAT)
        self.plainTextEdit.setObjectName(u"plainTextEdit")
        sizePolicy7 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Ignored)
        sizePolicy7.setHorizontalStretch(0)
        sizePolicy7.setVerticalStretch(0)
        sizePolicy7.setHeightForWidth(self.plainTextEdit.sizePolicy().hasHeightForWidth())
        self.plainTextEdit.setSizePolicy(sizePolicy7)

        self.horizontalLayout_36.addWidget(self.plainTextEdit)

        self.pushButton_10 = QPushButton(self.CHAT)
        self.pushButton_10.setObjectName(u"pushButton_10")

        self.horizontalLayout_36.addWidget(self.pushButton_10)

        self.horizontalLayout_36.setStretch(0, 10)

        self.verticalLayout_34.addLayout(self.horizontalLayout_36)

        self.verticalLayout_34.setStretch(0, 1)
        self.verticalLayout_34.setStretch(1, 10)
        self.verticalLayout_34.setStretch(2, 1)
        self.stackedWidget_2.addWidget(self.CHAT)

        self.gridLayout_14.addWidget(self.stackedWidget_2, 0, 1, 1, 1)

        self.gridLayout_14.setColumnStretch(0, 1)
        self.gridLayout_14.setColumnStretch(1, 5)
        self.stackedWidget.addWidget(self.Chat)
        self.News = QWidget()
        self.News.setObjectName(u"News")
        self.gridLayout_4 = QGridLayout(self.News)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.horizontalLayout_7 = QHBoxLayout()
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.LastNewsPanel_3 = QFrame(self.News)
        self.LastNewsPanel_3.setObjectName(u"LastNewsPanel_3")
        sizePolicy3.setHeightForWidth(self.LastNewsPanel_3.sizePolicy().hasHeightForWidth())
        self.LastNewsPanel_3.setSizePolicy(sizePolicy3)
        self.LastNewsPanel_3.setFrameShape(QFrame.Shape.NoFrame)
        self.LastNewsPanel_3.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_9 = QVBoxLayout(self.LastNewsPanel_3)
        self.verticalLayout_9.setSpacing(5)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(-1, -1, -1, 0)
        self.Title_2 = QLabel(self.LastNewsPanel_3)
        self.Title_2.setObjectName(u"Title_2")
        self.Title_2.setStyleSheet(u"color: #0094C9;\n"
"font: bold 16px \"Segoe UI\";\n"
"")
        self.Title_2.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_2.addWidget(self.Title_2)

        self.horizontalLayout_8 = QHBoxLayout()
        self.horizontalLayout_8.setSpacing(7)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.Sector7_9 = QPushButton(self.LastNewsPanel_3)
        self.Sector7_9.setObjectName(u"Sector7_9")
        sizePolicy8 = QSizePolicy(QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Expanding)
        sizePolicy8.setHorizontalStretch(0)
        sizePolicy8.setVerticalStretch(0)
        sizePolicy8.setHeightForWidth(self.Sector7_9.sizePolicy().hasHeightForWidth())
        self.Sector7_9.setSizePolicy(sizePolicy8)
        self.Sector7_9.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_9.setCheckable(False)
        self.Sector7_9.setChecked(False)

        self.horizontalLayout_8.addWidget(self.Sector7_9)

        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.label_9 = QLabel(self.LastNewsPanel_3)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setStyleSheet(u"color: #47B8E0;\n"
"font-size: 9pt;\n"
"font-weight: bold; \n"
"background-color: transparent;")

        self.verticalLayout_4.addWidget(self.label_9)

        self.Name_Line_Edit_2 = QLineEdit(self.LastNewsPanel_3)
        self.Name_Line_Edit_2.setObjectName(u"Name_Line_Edit_2")
        self.Name_Line_Edit_2.setMaximumSize(QSize(150, 16777215))
        self.Name_Line_Edit_2.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.Name_Line_Edit_2.setStyleSheet(u"    background-color: transparent; \n"
"    border: 2px solid #47B8E0; \n"
"    border-radius: 10px; \n"
"    color: black; \n"
"    padding: 5px; ")
        self.Name_Line_Edit_2.setMaxLength(32772)
        self.Name_Line_Edit_2.setFrame(False)
        self.Name_Line_Edit_2.setCursorPosition(0)

        self.verticalLayout_4.addWidget(self.Name_Line_Edit_2)


        self.horizontalLayout_8.addLayout(self.verticalLayout_4)


        self.verticalLayout_2.addLayout(self.horizontalLayout_8)

        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(-1, -1, -1, 0)
        self.label_10 = QLabel(self.LastNewsPanel_3)
        self.label_10.setObjectName(u"label_10")
        sizePolicy.setHeightForWidth(self.label_10.sizePolicy().hasHeightForWidth())
        self.label_10.setSizePolicy(sizePolicy)
        self.label_10.setStyleSheet(u"color: #47B8E0;\n"
"font-size: 9pt;\n"
"font-weight: bold; \n"
"background-color: transparent;")

        self.verticalLayout_6.addWidget(self.label_10)

        self.Name_Line_Edit = QLineEdit(self.LastNewsPanel_3)
        self.Name_Line_Edit.setObjectName(u"Name_Line_Edit")
        sizePolicy.setHeightForWidth(self.Name_Line_Edit.sizePolicy().hasHeightForWidth())
        self.Name_Line_Edit.setSizePolicy(sizePolicy)
        self.Name_Line_Edit.setMaximumSize(QSize(16777215, 16777215))
        self.Name_Line_Edit.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.Name_Line_Edit.setStyleSheet(u"    background-color: transparent; \n"
"    border: 2px solid #47B8E0; \n"
"    border-radius: 10px; \n"
"    color: black; \n"
"    padding: 5px; ")
        self.Name_Line_Edit.setMaxLength(32772)
        self.Name_Line_Edit.setFrame(False)
        self.Name_Line_Edit.setCursorPosition(0)

        self.verticalLayout_6.addWidget(self.Name_Line_Edit)

        self.verticalLayout_6.setStretch(0, 1)
        self.verticalLayout_6.setStretch(1, 4)

        self.verticalLayout_2.addLayout(self.verticalLayout_6)

        self.verticalLayout_18 = QVBoxLayout()
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.verticalLayout_18.setContentsMargins(-1, -1, -1, 0)
        self.label_21 = QLabel(self.LastNewsPanel_3)
        self.label_21.setObjectName(u"label_21")
        sizePolicy.setHeightForWidth(self.label_21.sizePolicy().hasHeightForWidth())
        self.label_21.setSizePolicy(sizePolicy)
        self.label_21.setStyleSheet(u"color: #47B8E0;\n"
"font-size: 9pt;\n"
"font-weight: bold; \n"
"background-color: transparent;")

        self.verticalLayout_18.addWidget(self.label_21)

        self.Name_Line_Edit_5 = QLineEdit(self.LastNewsPanel_3)
        self.Name_Line_Edit_5.setObjectName(u"Name_Line_Edit_5")
        sizePolicy.setHeightForWidth(self.Name_Line_Edit_5.sizePolicy().hasHeightForWidth())
        self.Name_Line_Edit_5.setSizePolicy(sizePolicy)
        self.Name_Line_Edit_5.setMaximumSize(QSize(16777215, 16777215))
        self.Name_Line_Edit_5.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.Name_Line_Edit_5.setStyleSheet(u"    background-color: transparent; \n"
"    border: 2px solid #47B8E0; \n"
"    border-radius: 10px; \n"
"    color: black; \n"
"    padding: 5px; ")
        self.Name_Line_Edit_5.setMaxLength(32772)
        self.Name_Line_Edit_5.setFrame(False)
        self.Name_Line_Edit_5.setCursorPosition(0)

        self.verticalLayout_18.addWidget(self.Name_Line_Edit_5)

        self.verticalLayout_18.setStretch(0, 1)
        self.verticalLayout_18.setStretch(1, 4)

        self.verticalLayout_2.addLayout(self.verticalLayout_18)

        self.verticalLayout_2.setStretch(0, 1)
        self.verticalLayout_2.setStretch(1, 1)
        self.verticalLayout_2.setStretch(2, 2)
        self.verticalLayout_2.setStretch(3, 4)

        self.verticalLayout_9.addLayout(self.verticalLayout_2)


        self.horizontalLayout_7.addWidget(self.LastNewsPanel_3)

        self.verticalLayout_10 = QVBoxLayout()
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalSpacer_2 = QSpacerItem(1, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_10.addItem(self.verticalSpacer_2)

        self.line_3 = QFrame(self.News)
        self.line_3.setObjectName(u"line_3")
        sizePolicy9 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        sizePolicy9.setHorizontalStretch(0)
        sizePolicy9.setVerticalStretch(0)
        sizePolicy9.setHeightForWidth(self.line_3.sizePolicy().hasHeightForWidth())
        self.line_3.setSizePolicy(sizePolicy9)
        self.line_3.setAutoFillBackground(False)
        self.line_3.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_3.setFrameShadow(QFrame.Shadow.Plain)
        self.line_3.setLineWidth(2)
        self.line_3.setMidLineWidth(2)
        self.line_3.setFrameShape(QFrame.Shape.VLine)

        self.verticalLayout_10.addWidget(self.line_3)

        self.verticalSpacer = QSpacerItem(1, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_10.addItem(self.verticalSpacer)

        self.verticalLayout_10.setStretch(1, 1)

        self.horizontalLayout_7.addLayout(self.verticalLayout_10)

        self.verticalLayout_11 = QVBoxLayout()
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalSpacer_3 = QSpacerItem(1, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_11.addItem(self.verticalSpacer_3)

        self.line_4 = QFrame(self.News)
        self.line_4.setObjectName(u"line_4")
        sizePolicy9.setHeightForWidth(self.line_4.sizePolicy().hasHeightForWidth())
        self.line_4.setSizePolicy(sizePolicy9)
        self.line_4.setAutoFillBackground(False)
        self.line_4.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_4.setFrameShadow(QFrame.Shadow.Plain)
        self.line_4.setLineWidth(2)
        self.line_4.setMidLineWidth(2)
        self.line_4.setFrameShape(QFrame.Shape.VLine)

        self.verticalLayout_11.addWidget(self.line_4)

        self.verticalSpacer_4 = QSpacerItem(1, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_11.addItem(self.verticalSpacer_4)

        self.verticalLayout_11.setStretch(0, 2)
        self.verticalLayout_11.setStretch(1, 5)
        self.verticalLayout_11.setStretch(2, 2)

        self.horizontalLayout_7.addLayout(self.verticalLayout_11)

        self.verticalLayout_12 = QVBoxLayout()
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.horizontalLayout_21 = QHBoxLayout()
        self.horizontalLayout_21.setObjectName(u"horizontalLayout_21")
        self.horizontalSpacer_17 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_21.addItem(self.horizontalSpacer_17)

        self.Title_3 = QLabel(self.News)
        self.Title_3.setObjectName(u"Title_3")
        self.Title_3.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_3.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_21.addWidget(self.Title_3)

        self.horizontalSpacer_18 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_21.addItem(self.horizontalSpacer_18)


        self.verticalLayout_12.addLayout(self.horizontalLayout_21)

        self.horizontalLayout_22 = QHBoxLayout()
        self.horizontalLayout_22.setObjectName(u"horizontalLayout_22")
        self.horizontalLayout_22.setContentsMargins(200, -1, 200, -1)
        self.line_5 = QFrame(self.News)
        self.line_5.setObjectName(u"line_5")
        self.line_5.setAutoFillBackground(False)
        self.line_5.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_5.setFrameShadow(QFrame.Shadow.Plain)
        self.line_5.setLineWidth(2)
        self.line_5.setMidLineWidth(2)
        self.line_5.setFrameShape(QFrame.Shape.HLine)

        self.horizontalLayout_22.addWidget(self.line_5)


        self.verticalLayout_12.addLayout(self.horizontalLayout_22)

        self.horizontalLayout_23 = QHBoxLayout()
        self.horizontalLayout_23.setObjectName(u"horizontalLayout_23")
        self.horizontalLayout_23.setContentsMargins(100, -1, 100, -1)
        self.line_6 = QFrame(self.News)
        self.line_6.setObjectName(u"line_6")
        self.line_6.setAutoFillBackground(False)
        self.line_6.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_6.setFrameShadow(QFrame.Shadow.Plain)
        self.line_6.setLineWidth(2)
        self.line_6.setMidLineWidth(2)
        self.line_6.setFrameShape(QFrame.Shape.HLine)

        self.horizontalLayout_23.addWidget(self.line_6)


        self.verticalLayout_12.addLayout(self.horizontalLayout_23)

        self.scrollArea = QScrollArea(self.News)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 500, 1713))
        self.scrollAreaWidgetContents.setMinimumSize(QSize(500, 1000))
        self.scrollAreaWidgetContents.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.gridLayout_3 = QGridLayout(self.scrollAreaWidgetContents)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.verticalLayout_13 = QVBoxLayout()
        self.verticalLayout_13.setSpacing(12)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.horizontalLayout_12 = QHBoxLayout()
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.label_5 = QLabel(self.scrollAreaWidgetContents)
        self.label_5.setObjectName(u"label_5")
        sizePolicy4.setHeightForWidth(self.label_5.sizePolicy().hasHeightForWidth())
        self.label_5.setSizePolicy(sizePolicy4)
        self.label_5.setPixmap(QPixmap(u":/login/NewsImage.png"))
        self.label_5.setScaledContents(True)

        self.horizontalLayout_12.addWidget(self.label_5)

        self.verticalLayout_14 = QVBoxLayout()
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.label_7 = QLabel(self.scrollAreaWidgetContents)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setStyleSheet(u"color: black;")

        self.verticalLayout_14.addWidget(self.label_7)

        self.label_6 = QLabel(self.scrollAreaWidgetContents)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setStyleSheet(u"color: black;")
        self.label_6.setScaledContents(False)
        self.label_6.setWordWrap(True)

        self.verticalLayout_14.addWidget(self.label_6)


        self.horizontalLayout_12.addLayout(self.verticalLayout_14)

        self.horizontalLayout_12.setStretch(0, 1)
        self.horizontalLayout_12.setStretch(1, 2)

        self.verticalLayout_13.addLayout(self.horizontalLayout_12)

        self.horizontalLayout_18 = QHBoxLayout()
        self.horizontalLayout_18.setObjectName(u"horizontalLayout_18")
        self.label_14 = QLabel(self.scrollAreaWidgetContents)
        self.label_14.setObjectName(u"label_14")
        sizePolicy4.setHeightForWidth(self.label_14.sizePolicy().hasHeightForWidth())
        self.label_14.setSizePolicy(sizePolicy4)
        self.label_14.setPixmap(QPixmap(u":/login/NewsImage.png"))
        self.label_14.setScaledContents(True)

        self.horizontalLayout_18.addWidget(self.label_14)

        self.verticalLayout_17 = QVBoxLayout()
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.label_15 = QLabel(self.scrollAreaWidgetContents)
        self.label_15.setObjectName(u"label_15")
        self.label_15.setStyleSheet(u"color: black;")

        self.verticalLayout_17.addWidget(self.label_15)

        self.label_16 = QLabel(self.scrollAreaWidgetContents)
        self.label_16.setObjectName(u"label_16")
        self.label_16.setStyleSheet(u"color: black;")
        self.label_16.setWordWrap(True)

        self.verticalLayout_17.addWidget(self.label_16)


        self.horizontalLayout_18.addLayout(self.verticalLayout_17)

        self.horizontalLayout_18.setStretch(0, 1)
        self.horizontalLayout_18.setStretch(1, 2)

        self.verticalLayout_13.addLayout(self.horizontalLayout_18)

        self.horizontalLayout_24 = QHBoxLayout()
        self.horizontalLayout_24.setObjectName(u"horizontalLayout_24")
        self.label_23 = QLabel(self.scrollAreaWidgetContents)
        self.label_23.setObjectName(u"label_23")
        sizePolicy4.setHeightForWidth(self.label_23.sizePolicy().hasHeightForWidth())
        self.label_23.setSizePolicy(sizePolicy4)
        self.label_23.setPixmap(QPixmap(u":/login/NewsImage.png"))
        self.label_23.setScaledContents(True)

        self.horizontalLayout_24.addWidget(self.label_23)

        self.verticalLayout_20 = QVBoxLayout()
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.label_24 = QLabel(self.scrollAreaWidgetContents)
        self.label_24.setObjectName(u"label_24")
        self.label_24.setStyleSheet(u"color: black;")

        self.verticalLayout_20.addWidget(self.label_24)

        self.label_25 = QLabel(self.scrollAreaWidgetContents)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setStyleSheet(u"color: black;")
        self.label_25.setWordWrap(True)

        self.verticalLayout_20.addWidget(self.label_25)


        self.horizontalLayout_24.addLayout(self.verticalLayout_20)

        self.horizontalLayout_24.setStretch(0, 1)
        self.horizontalLayout_24.setStretch(1, 2)

        self.verticalLayout_13.addLayout(self.horizontalLayout_24)

        self.horizontalLayout_25 = QHBoxLayout()
        self.horizontalLayout_25.setObjectName(u"horizontalLayout_25")
        self.label_26 = QLabel(self.scrollAreaWidgetContents)
        self.label_26.setObjectName(u"label_26")
        sizePolicy4.setHeightForWidth(self.label_26.sizePolicy().hasHeightForWidth())
        self.label_26.setSizePolicy(sizePolicy4)
        self.label_26.setPixmap(QPixmap(u":/login/NewsImage.png"))
        self.label_26.setScaledContents(True)

        self.horizontalLayout_25.addWidget(self.label_26)

        self.verticalLayout_21 = QVBoxLayout()
        self.verticalLayout_21.setObjectName(u"verticalLayout_21")
        self.label_27 = QLabel(self.scrollAreaWidgetContents)
        self.label_27.setObjectName(u"label_27")
        self.label_27.setStyleSheet(u"color: black;")

        self.verticalLayout_21.addWidget(self.label_27)

        self.label_28 = QLabel(self.scrollAreaWidgetContents)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setStyleSheet(u"color: black;")
        self.label_28.setWordWrap(True)

        self.verticalLayout_21.addWidget(self.label_28)


        self.horizontalLayout_25.addLayout(self.verticalLayout_21)

        self.horizontalLayout_25.setStretch(0, 1)
        self.horizontalLayout_25.setStretch(1, 2)

        self.verticalLayout_13.addLayout(self.horizontalLayout_25)

        self.horizontalLayout_26 = QHBoxLayout()
        self.horizontalLayout_26.setObjectName(u"horizontalLayout_26")
        self.label_29 = QLabel(self.scrollAreaWidgetContents)
        self.label_29.setObjectName(u"label_29")
        sizePolicy4.setHeightForWidth(self.label_29.sizePolicy().hasHeightForWidth())
        self.label_29.setSizePolicy(sizePolicy4)
        self.label_29.setPixmap(QPixmap(u":/login/NewsImage.png"))
        self.label_29.setScaledContents(True)

        self.horizontalLayout_26.addWidget(self.label_29)

        self.verticalLayout_22 = QVBoxLayout()
        self.verticalLayout_22.setObjectName(u"verticalLayout_22")
        self.label_30 = QLabel(self.scrollAreaWidgetContents)
        self.label_30.setObjectName(u"label_30")
        self.label_30.setStyleSheet(u"color: black;")

        self.verticalLayout_22.addWidget(self.label_30)

        self.label_31 = QLabel(self.scrollAreaWidgetContents)
        self.label_31.setObjectName(u"label_31")
        self.label_31.setStyleSheet(u"color: black;")
        self.label_31.setWordWrap(True)

        self.verticalLayout_22.addWidget(self.label_31)


        self.horizontalLayout_26.addLayout(self.verticalLayout_22)

        self.horizontalLayout_26.setStretch(0, 1)
        self.horizontalLayout_26.setStretch(1, 2)

        self.verticalLayout_13.addLayout(self.horizontalLayout_26)

        self.horizontalLayout_27 = QHBoxLayout()
        self.horizontalLayout_27.setObjectName(u"horizontalLayout_27")
        self.label_32 = QLabel(self.scrollAreaWidgetContents)
        self.label_32.setObjectName(u"label_32")
        sizePolicy4.setHeightForWidth(self.label_32.sizePolicy().hasHeightForWidth())
        self.label_32.setSizePolicy(sizePolicy4)
        self.label_32.setPixmap(QPixmap(u":/login/NewsImage.png"))
        self.label_32.setScaledContents(True)

        self.horizontalLayout_27.addWidget(self.label_32)

        self.verticalLayout_23 = QVBoxLayout()
        self.verticalLayout_23.setObjectName(u"verticalLayout_23")
        self.label_33 = QLabel(self.scrollAreaWidgetContents)
        self.label_33.setObjectName(u"label_33")
        self.label_33.setStyleSheet(u"color: black;")

        self.verticalLayout_23.addWidget(self.label_33)

        self.label_34 = QLabel(self.scrollAreaWidgetContents)
        self.label_34.setObjectName(u"label_34")
        self.label_34.setStyleSheet(u"color: black;")
        self.label_34.setWordWrap(True)

        self.verticalLayout_23.addWidget(self.label_34)


        self.horizontalLayout_27.addLayout(self.verticalLayout_23)

        self.horizontalLayout_27.setStretch(0, 1)
        self.horizontalLayout_27.setStretch(1, 2)

        self.verticalLayout_13.addLayout(self.horizontalLayout_27)

        self.horizontalLayout_17 = QHBoxLayout()
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.label_11 = QLabel(self.scrollAreaWidgetContents)
        self.label_11.setObjectName(u"label_11")
        sizePolicy4.setHeightForWidth(self.label_11.sizePolicy().hasHeightForWidth())
        self.label_11.setSizePolicy(sizePolicy4)
        self.label_11.setPixmap(QPixmap(u":/login/NewsImage.png"))
        self.label_11.setScaledContents(True)

        self.horizontalLayout_17.addWidget(self.label_11)

        self.verticalLayout_16 = QVBoxLayout()
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.label_12 = QLabel(self.scrollAreaWidgetContents)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setStyleSheet(u"color: black;")

        self.verticalLayout_16.addWidget(self.label_12)

        self.label_13 = QLabel(self.scrollAreaWidgetContents)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setStyleSheet(u"color: black;")
        self.label_13.setWordWrap(True)

        self.verticalLayout_16.addWidget(self.label_13)


        self.horizontalLayout_17.addLayout(self.verticalLayout_16)

        self.horizontalLayout_17.setStretch(0, 1)
        self.horizontalLayout_17.setStretch(1, 2)

        self.verticalLayout_13.addLayout(self.horizontalLayout_17)


        self.gridLayout_3.addLayout(self.verticalLayout_13, 0, 0, 1, 1)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)

        self.verticalLayout_12.addWidget(self.scrollArea)


        self.horizontalLayout_7.addLayout(self.verticalLayout_12)

        self.horizontalLayout_7.setStretch(0, 1)
        self.horizontalLayout_7.setStretch(3, 5)

        self.gridLayout_4.addLayout(self.horizontalLayout_7, 0, 0, 1, 1)

        self.stackedWidget.addWidget(self.News)
        self.Status = QWidget()
        self.Status.setObjectName(u"Status")
        sizePolicy3.setHeightForWidth(self.Status.sizePolicy().hasHeightForWidth())
        self.Status.setSizePolicy(sizePolicy3)
        self.horizontalLayout_10 = QHBoxLayout(self.Status)
        self.horizontalLayout_10.setSpacing(10)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.horizontalLayout_10.setContentsMargins(10, 10, 10, 10)
        self.horizontalLayout_33 = QHBoxLayout()
        self.horizontalLayout_33.setObjectName(u"horizontalLayout_33")
        self.horizontalLayout_33.setContentsMargins(-1, -1, 0, -1)
        self.horizontalLayout_9 = QHBoxLayout()
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.horizontalLayout_9.setContentsMargins(-1, -1, 0, -1)
        self.LastNewsPanel_4 = QFrame(self.Status)
        self.LastNewsPanel_4.setObjectName(u"LastNewsPanel_4")
        sizePolicy10 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Maximum)
        sizePolicy10.setHorizontalStretch(0)
        sizePolicy10.setVerticalStretch(0)
        sizePolicy10.setHeightForWidth(self.LastNewsPanel_4.sizePolicy().hasHeightForWidth())
        self.LastNewsPanel_4.setSizePolicy(sizePolicy10)
        self.LastNewsPanel_4.setMinimumSize(QSize(0, 88))
        self.LastNewsPanel_4.setMaximumSize(QSize(10000, 10000))
        self.LastNewsPanel_4.setAutoFillBackground(False)
        self.LastNewsPanel_4.setStyleSheet(u"QFrame#LastNewsPanel_4{\n"
"	border-image: url(:/login/vista-aerea-gran-centro-comercial.png);\n"
"}")
        self.LastNewsPanel_4.setFrameShape(QFrame.Shape.NoFrame)
        self.LastNewsPanel_4.setFrameShadow(QFrame.Shadow.Plain)
        self.gridLayout_6 = QGridLayout(self.LastNewsPanel_4)
        self.gridLayout_6.setSpacing(6)
        self.gridLayout_6.setObjectName(u"gridLayout_6")
        self.gridLayout_6.setContentsMargins(6, 6, 6, 6)
        self.horizontalSpacer_20 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_20, 8, 2, 1, 1)

        self.verticalSpacer_26 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_26, 5, 5, 1, 1)

        self.verticalSpacer_25 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_25, 9, 3, 1, 1)

        self.verticalSpacer_15 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_15, 2, 3, 1, 1)

        self.verticalSpacer_20 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_20, 6, 1, 1, 1)

        self.verticalSpacer_27 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_27, 1, 5, 1, 1)

        self.horizontalSpacer_22 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_22, 6, 6, 1, 1)

        self.verticalSpacer_24 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_24, 11, 7, 1, 1)

        self.horizontalSpacer_21 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_21, 13, 4, 1, 1)

        self.verticalSpacer_13 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_13, 4, 1, 1, 1)

        self.horizontalLayout_19 = QHBoxLayout()
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.Sector3 = QPushButton(self.LastNewsPanel_4)
        self.Sector3.setObjectName(u"Sector3")
        self.Sector3.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector3.setCheckable(False)
        self.Sector3.setChecked(False)

        self.horizontalLayout_19.addWidget(self.Sector3)

        self.check3 = QLabel(self.LastNewsPanel_4)
        self.check3.setObjectName(u"check3")
        sizePolicy4.setHeightForWidth(self.check3.sizePolicy().hasHeightForWidth())
        self.check3.setSizePolicy(sizePolicy4)
        self.check3.setMinimumSize(QSize(40, 10))
        self.check3.setStyleSheet(u"background-color: transparent;")
        self.check3.setPixmap(QPixmap(u":/login/Alert.png"))
        self.check3.setScaledContents(True)

        self.horizontalLayout_19.addWidget(self.check3)


        self.gridLayout_6.addLayout(self.horizontalLayout_19, 15, 1, 1, 1)

        self.horizontalLayout_16 = QHBoxLayout()
        self.horizontalLayout_16.setObjectName(u"horizontalLayout_16")
        self.Sector8 = QPushButton(self.LastNewsPanel_4)
        self.Sector8.setObjectName(u"Sector8")
        self.Sector8.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector8.setCheckable(False)
        self.Sector8.setChecked(False)

        self.horizontalLayout_16.addWidget(self.Sector8)

        self.check8 = QLabel(self.LastNewsPanel_4)
        self.check8.setObjectName(u"check8")
        sizePolicy4.setHeightForWidth(self.check8.sizePolicy().hasHeightForWidth())
        self.check8.setSizePolicy(sizePolicy4)
        self.check8.setMinimumSize(QSize(40, 0))
        self.check8.setStyleSheet(u"background-color: transparent;")
        self.check8.setPixmap(QPixmap(u":/login/Alert.png"))
        self.check8.setScaledContents(True)

        self.horizontalLayout_16.addWidget(self.check8)


        self.gridLayout_6.addLayout(self.horizontalLayout_16, 10, 7, 1, 1)

        self.verticalSpacer_16 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_16, 10, 1, 1, 1)

        self.verticalSpacer_22 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_22, 16, 1, 1, 1)

        self.horizontalLayout_29 = QHBoxLayout()
        self.horizontalLayout_29.setObjectName(u"horizontalLayout_29")
        self.Sector6 = QPushButton(self.LastNewsPanel_4)
        self.Sector6.setObjectName(u"Sector6")
        self.Sector6.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector6.setCheckable(False)
        self.Sector6.setChecked(False)

        self.horizontalLayout_29.addWidget(self.Sector6)

        self.check6 = QLabel(self.LastNewsPanel_4)
        self.check6.setObjectName(u"check6")
        sizePolicy4.setHeightForWidth(self.check6.sizePolicy().hasHeightForWidth())
        self.check6.setSizePolicy(sizePolicy4)
        self.check6.setMinimumSize(QSize(40, 10))
        self.check6.setStyleSheet(u"background-color: transparent;")
        self.check6.setPixmap(QPixmap(u":/login/Alert.png"))
        self.check6.setScaledContents(True)

        self.horizontalLayout_29.addWidget(self.check6)


        self.gridLayout_6.addLayout(self.horizontalLayout_29, 0, 5, 1, 1)

        self.horizontalLayout_30 = QHBoxLayout()
        self.horizontalLayout_30.setObjectName(u"horizontalLayout_30")
        self.Sector5 = QPushButton(self.LastNewsPanel_4)
        self.Sector5.setObjectName(u"Sector5")
        self.Sector5.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector5.setCheckable(False)
        self.Sector5.setChecked(False)

        self.horizontalLayout_30.addWidget(self.Sector5)

        self.check5 = QLabel(self.LastNewsPanel_4)
        self.check5.setObjectName(u"check5")
        sizePolicy4.setHeightForWidth(self.check5.sizePolicy().hasHeightForWidth())
        self.check5.setSizePolicy(sizePolicy4)
        self.check5.setMinimumSize(QSize(40, 10))
        self.check5.setStyleSheet(u"background-color: transparent;")
        self.check5.setPixmap(QPixmap(u":/login/Alert.png"))
        self.check5.setScaledContents(True)

        self.horizontalLayout_30.addWidget(self.check5)


        self.gridLayout_6.addLayout(self.horizontalLayout_30, 4, 5, 1, 1)

        self.horizontalLayout_28 = QHBoxLayout()
        self.horizontalLayout_28.setObjectName(u"horizontalLayout_28")
        self.Sector4 = QPushButton(self.LastNewsPanel_4)
        self.Sector4.setObjectName(u"Sector4")
        self.Sector4.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector4.setCheckable(False)
        self.Sector4.setChecked(False)

        self.horizontalLayout_28.addWidget(self.Sector4)

        self.check4 = QLabel(self.LastNewsPanel_4)
        self.check4.setObjectName(u"check4")
        sizePolicy4.setHeightForWidth(self.check4.sizePolicy().hasHeightForWidth())
        self.check4.setSizePolicy(sizePolicy4)
        self.check4.setMinimumSize(QSize(40, 10))
        self.check4.setStyleSheet(u"background-color: transparent;")
        self.check4.setPixmap(QPixmap(u":/login/Alert.png"))
        self.check4.setScaledContents(True)

        self.horizontalLayout_28.addWidget(self.check4)


        self.gridLayout_6.addLayout(self.horizontalLayout_28, 13, 5, 1, 1)

        self.verticalSpacer_21 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_21, 7, 7, 1, 1)

        self.verticalSpacer_14 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_14, 8, 1, 1, 1)

        self.horizontalLayout_14 = QHBoxLayout()
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.Sector1 = QPushButton(self.LastNewsPanel_4)
        self.Sector1.setObjectName(u"Sector1")
        self.Sector1.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector1.setCheckable(False)
        self.Sector1.setChecked(False)

        self.horizontalLayout_14.addWidget(self.Sector1)

        self.check1 = QLabel(self.LastNewsPanel_4)
        self.check1.setObjectName(u"check1")
        sizePolicy4.setHeightForWidth(self.check1.sizePolicy().hasHeightForWidth())
        self.check1.setSizePolicy(sizePolicy4)
        self.check1.setMinimumSize(QSize(40, 10))
        self.check1.setStyleSheet(u"background-color: transparent;")
        self.check1.setPixmap(QPixmap(u":/login/Alert.png"))
        self.check1.setScaledContents(True)

        self.horizontalLayout_14.addWidget(self.check1)


        self.gridLayout_6.addLayout(self.horizontalLayout_14, 2, 1, 1, 1)

        self.verticalSpacer_23 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_23, 14, 5, 1, 1)

        self.horizontalSpacer_16 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_16, 4, 0, 1, 1)

        self.verticalSpacer_18 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_18, 3, 3, 1, 1)

        self.verticalSpacer_17 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_17, 12, 1, 1, 1)

        self.horizontalSpacer_19 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_19, 6, 8, 1, 1)

        self.verticalSpacer_19 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_19, 15, 3, 1, 1)

        self.horizontalLayout_11 = QHBoxLayout()
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.Sector7 = QPushButton(self.LastNewsPanel_4)
        self.Sector7.setObjectName(u"Sector7")
        self.Sector7.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7.setCheckable(False)
        self.Sector7.setChecked(False)

        self.horizontalLayout_11.addWidget(self.Sector7)

        self.check7 = QLabel(self.LastNewsPanel_4)
        self.check7.setObjectName(u"check7")
        sizePolicy4.setHeightForWidth(self.check7.sizePolicy().hasHeightForWidth())
        self.check7.setSizePolicy(sizePolicy4)
        self.check7.setMinimumSize(QSize(40, 0))
        self.check7.setStyleSheet(u"background-color: transparent;")
        self.check7.setPixmap(QPixmap(u":/login/Alert.png"))
        self.check7.setScaledContents(True)

        self.horizontalLayout_11.addWidget(self.check7)


        self.gridLayout_6.addLayout(self.horizontalLayout_11, 6, 7, 1, 1)

        self.verticalSpacer_12 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_12, 0, 1, 1, 1)

        self.verticalSpacer_11 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_11, 13, 1, 1, 1)

        self.horizontalLayout_20 = QHBoxLayout()
        self.horizontalLayout_20.setObjectName(u"horizontalLayout_20")
        self.Sector2 = QPushButton(self.LastNewsPanel_4)
        self.Sector2.setObjectName(u"Sector2")
        self.Sector2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector2.setCheckable(False)
        self.Sector2.setChecked(False)

        self.horizontalLayout_20.addWidget(self.Sector2)

        self.check2 = QLabel(self.LastNewsPanel_4)
        self.check2.setObjectName(u"check2")
        sizePolicy4.setHeightForWidth(self.check2.sizePolicy().hasHeightForWidth())
        self.check2.setSizePolicy(sizePolicy4)
        self.check2.setMinimumSize(QSize(40, 10))
        self.check2.setStyleSheet(u"background-color: transparent;")
        self.check2.setPixmap(QPixmap(u":/login/Alert.png"))
        self.check2.setScaledContents(True)

        self.horizontalLayout_20.addWidget(self.check2)


        self.gridLayout_6.addLayout(self.horizontalLayout_20, 8, 3, 1, 1)


        self.horizontalLayout_9.addWidget(self.LastNewsPanel_4)


        self.horizontalLayout_33.addLayout(self.horizontalLayout_9)

        self.verticalLayout_27 = QVBoxLayout()
        self.verticalLayout_27.setObjectName(u"verticalLayout_27")
        self.verticalLayout_27.setContentsMargins(-1, -1, 0, 0)
        self.horizontalLayout_13 = QHBoxLayout()
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.horizontalSpacer_11 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_13.addItem(self.horizontalSpacer_11)

        self.TitleLastNews = QLabel(self.Status)
        self.TitleLastNews.setObjectName(u"TitleLastNews")
        self.TitleLastNews.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.TitleLastNews.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_13.addWidget(self.TitleLastNews)

        self.horizontalSpacer_12 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_13.addItem(self.horizontalSpacer_12)


        self.verticalLayout_27.addLayout(self.horizontalLayout_13)

        self.line_7 = QFrame(self.Status)
        self.line_7.setObjectName(u"line_7")
        self.line_7.setAutoFillBackground(False)
        self.line_7.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_7.setFrameShadow(QFrame.Shadow.Plain)
        self.line_7.setLineWidth(2)
        self.line_7.setMidLineWidth(2)
        self.line_7.setFrameShape(QFrame.Shape.HLine)

        self.verticalLayout_27.addWidget(self.line_7)

        self.scrollArea_3 = QScrollArea(self.Status)
        self.scrollArea_3.setObjectName(u"scrollArea_3")
        self.scrollArea_3.setWidgetResizable(True)
        self.scrollAreaWidgetContents_3 = QWidget()
        self.scrollAreaWidgetContents_3.setObjectName(u"scrollAreaWidgetContents_3")
        self.scrollAreaWidgetContents_3.setGeometry(QRect(0, 0, 76, 880))
        self.verticalLayout_7 = QVBoxLayout(self.scrollAreaWidgetContents_3)
        self.verticalLayout_7.setSpacing(0)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.TextoLastNews = QLabel(self.scrollAreaWidgetContents_3)
        self.TextoLastNews.setObjectName(u"TextoLastNews")
        self.TextoLastNews.setFont(font1)
        self.TextoLastNews.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.TextoLastNews.setStyleSheet(u"color: black;\n"
"text-align: center;\n"
"")
        self.TextoLastNews.setFrameShadow(QFrame.Shadow.Plain)
        self.TextoLastNews.setTextFormat(Qt.TextFormat.PlainText)
        self.TextoLastNews.setScaledContents(False)
        self.TextoLastNews.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)
        self.TextoLastNews.setWordWrap(True)

        self.verticalLayout_7.addWidget(self.TextoLastNews)

        self.scrollArea_3.setWidget(self.scrollAreaWidgetContents_3)

        self.verticalLayout_27.addWidget(self.scrollArea_3)

        self.horizontalLayout_32 = QHBoxLayout()
        self.horizontalLayout_32.setObjectName(u"horizontalLayout_32")
        self.horizontalSpacer_26 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_32.addItem(self.horizontalSpacer_26)

        self.TitleLastNews_2 = QLabel(self.Status)
        self.TitleLastNews_2.setObjectName(u"TitleLastNews_2")
        self.TitleLastNews_2.setStyleSheet(u"color: red;\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid red;")
        self.TitleLastNews_2.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_32.addWidget(self.TitleLastNews_2)

        self.horizontalSpacer_27 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_32.addItem(self.horizontalSpacer_27)


        self.verticalLayout_27.addLayout(self.horizontalLayout_32)

        self.line_9 = QFrame(self.Status)
        self.line_9.setObjectName(u"line_9")
        self.line_9.setAutoFillBackground(False)
        self.line_9.setStyleSheet(u"color: red")
        self.line_9.setFrameShadow(QFrame.Shadow.Plain)
        self.line_9.setLineWidth(2)
        self.line_9.setMidLineWidth(2)
        self.line_9.setFrameShape(QFrame.Shape.HLine)

        self.verticalLayout_27.addWidget(self.line_9)

        self.scrollArea_4 = QScrollArea(self.Status)
        self.scrollArea_4.setObjectName(u"scrollArea_4")
        self.scrollArea_4.setWidgetResizable(True)
        self.scrollAreaWidgetContents_4 = QWidget()
        self.scrollAreaWidgetContents_4.setObjectName(u"scrollAreaWidgetContents_4")
        self.scrollAreaWidgetContents_4.setGeometry(QRect(0, 0, 76, 880))
        self.verticalLayout_8 = QVBoxLayout(self.scrollAreaWidgetContents_4)
        self.verticalLayout_8.setSpacing(0)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.TextoLastNews_2 = QLabel(self.scrollAreaWidgetContents_4)
        self.TextoLastNews_2.setObjectName(u"TextoLastNews_2")
        self.TextoLastNews_2.setFont(font1)
        self.TextoLastNews_2.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.TextoLastNews_2.setStyleSheet(u"color: black;\n"
"text-align: center;\n"
"")
        self.TextoLastNews_2.setFrameShadow(QFrame.Shadow.Plain)
        self.TextoLastNews_2.setTextFormat(Qt.TextFormat.PlainText)
        self.TextoLastNews_2.setScaledContents(False)
        self.TextoLastNews_2.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)
        self.TextoLastNews_2.setWordWrap(True)

        self.verticalLayout_8.addWidget(self.TextoLastNews_2)

        self.scrollArea_4.setWidget(self.scrollAreaWidgetContents_4)

        self.verticalLayout_27.addWidget(self.scrollArea_4)


        self.horizontalLayout_33.addLayout(self.verticalLayout_27)

        self.horizontalLayout_33.setStretch(0, 5)
        self.horizontalLayout_33.setStretch(1, 1)

        self.horizontalLayout_10.addLayout(self.horizontalLayout_33)

        self.stackedWidget.addWidget(self.Status)
        self.Market = QWidget()
        self.Market.setObjectName(u"Market")
        self.gridLayout_12 = QGridLayout(self.Market)
        self.gridLayout_12.setObjectName(u"gridLayout_12")
        self.horizontalLayout_42 = QHBoxLayout()
        self.horizontalLayout_42.setObjectName(u"horizontalLayout_42")
        self.horizontalLayout_42.setContentsMargins(-1, -1, 0, -1)
        self.LastNewsPanel_7 = QFrame(self.Market)
        self.LastNewsPanel_7.setObjectName(u"LastNewsPanel_7")
        sizePolicy10.setHeightForWidth(self.LastNewsPanel_7.sizePolicy().hasHeightForWidth())
        self.LastNewsPanel_7.setSizePolicy(sizePolicy10)
        self.LastNewsPanel_7.setMinimumSize(QSize(0, 88))
        self.LastNewsPanel_7.setMaximumSize(QSize(10000, 10000))
        self.LastNewsPanel_7.setAutoFillBackground(False)
        self.LastNewsPanel_7.setStyleSheet(u"QFrame#LastNewsPanel_7{\n"
"	\n"
"	border-image: url(:/login/vista-aerea-techo-gran-centro-comercial.png);\n"
"}")
        self.LastNewsPanel_7.setFrameShape(QFrame.Shape.NoFrame)
        self.LastNewsPanel_7.setFrameShadow(QFrame.Shadow.Plain)
        self.gridLayout_13 = QGridLayout(self.LastNewsPanel_7)
        self.gridLayout_13.setSpacing(6)
        self.gridLayout_13.setObjectName(u"gridLayout_13")
        self.gridLayout_13.setContentsMargins(6, 6, 6, 6)
        self.verticalSpacer_46 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_46, 5, 5, 1, 1)

        self.horizontalLayout_43 = QHBoxLayout()
        self.horizontalLayout_43.setObjectName(u"horizontalLayout_43")
        self.Sector5_4 = QPushButton(self.LastNewsPanel_7)
        self.Sector5_4.setObjectName(u"Sector5_4")
        self.Sector5_4.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector5_4.setCheckable(False)
        self.Sector5_4.setChecked(False)

        self.horizontalLayout_43.addWidget(self.Sector5_4)

        self.check5_3 = QLabel(self.LastNewsPanel_7)
        self.check5_3.setObjectName(u"check5_3")
        sizePolicy4.setHeightForWidth(self.check5_3.sizePolicy().hasHeightForWidth())
        self.check5_3.setSizePolicy(sizePolicy4)
        self.check5_3.setMinimumSize(QSize(40, 10))
        self.check5_3.setStyleSheet(u"background-color: transparent;")
        self.check5_3.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check5_3.setScaledContents(True)

        self.horizontalLayout_43.addWidget(self.check5_3)


        self.gridLayout_13.addLayout(self.horizontalLayout_43, 4, 5, 1, 1)

        self.horizontalLayout_44 = QHBoxLayout()
        self.horizontalLayout_44.setObjectName(u"horizontalLayout_44")
        self.Sector4_4 = QPushButton(self.LastNewsPanel_7)
        self.Sector4_4.setObjectName(u"Sector4_4")
        self.Sector4_4.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector4_4.setCheckable(False)
        self.Sector4_4.setChecked(False)

        self.horizontalLayout_44.addWidget(self.Sector4_4)

        self.check4_3 = QLabel(self.LastNewsPanel_7)
        self.check4_3.setObjectName(u"check4_3")
        sizePolicy4.setHeightForWidth(self.check4_3.sizePolicy().hasHeightForWidth())
        self.check4_3.setSizePolicy(sizePolicy4)
        self.check4_3.setMinimumSize(QSize(40, 10))
        self.check4_3.setStyleSheet(u"background-color: transparent;")
        self.check4_3.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check4_3.setScaledContents(True)

        self.horizontalLayout_44.addWidget(self.check4_3)


        self.gridLayout_13.addLayout(self.horizontalLayout_44, 13, 5, 1, 1)

        self.horizontalLayout_45 = QHBoxLayout()
        self.horizontalLayout_45.setObjectName(u"horizontalLayout_45")
        self.Sector1_4 = QPushButton(self.LastNewsPanel_7)
        self.Sector1_4.setObjectName(u"Sector1_4")
        self.Sector1_4.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector1_4.setCheckable(False)
        self.Sector1_4.setChecked(False)

        self.horizontalLayout_45.addWidget(self.Sector1_4)

        self.check1_3 = QLabel(self.LastNewsPanel_7)
        self.check1_3.setObjectName(u"check1_3")
        sizePolicy4.setHeightForWidth(self.check1_3.sizePolicy().hasHeightForWidth())
        self.check1_3.setSizePolicy(sizePolicy4)
        self.check1_3.setMinimumSize(QSize(40, 10))
        self.check1_3.setStyleSheet(u"background-color: transparent;")
        self.check1_3.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check1_3.setScaledContents(True)

        self.horizontalLayout_45.addWidget(self.check1_3)


        self.gridLayout_13.addLayout(self.horizontalLayout_45, 2, 1, 1, 1)

        self.verticalSpacer_47 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_47, 0, 1, 1, 1)

        self.verticalSpacer_48 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_48, 15, 3, 1, 1)

        self.verticalSpacer_49 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_49, 10, 1, 1, 1)

        self.horizontalLayout_46 = QHBoxLayout()
        self.horizontalLayout_46.setObjectName(u"horizontalLayout_46")
        self.Sector7_11 = QPushButton(self.LastNewsPanel_7)
        self.Sector7_11.setObjectName(u"Sector7_11")
        self.Sector7_11.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_11.setCheckable(False)
        self.Sector7_11.setChecked(False)

        self.horizontalLayout_46.addWidget(self.Sector7_11)

        self.check7_3 = QLabel(self.LastNewsPanel_7)
        self.check7_3.setObjectName(u"check7_3")
        sizePolicy4.setHeightForWidth(self.check7_3.sizePolicy().hasHeightForWidth())
        self.check7_3.setSizePolicy(sizePolicy4)
        self.check7_3.setMinimumSize(QSize(40, 0))
        self.check7_3.setStyleSheet(u"background-color: transparent;")
        self.check7_3.setPixmap(QPixmap(u":/login/Alert.png"))
        self.check7_3.setScaledContents(True)

        self.horizontalLayout_46.addWidget(self.check7_3)


        self.gridLayout_13.addLayout(self.horizontalLayout_46, 6, 7, 1, 1)

        self.horizontalSpacer_33 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_13.addItem(self.horizontalSpacer_33, 8, 2, 1, 1)

        self.horizontalLayout_47 = QHBoxLayout()
        self.horizontalLayout_47.setObjectName(u"horizontalLayout_47")
        self.Sector2_4 = QPushButton(self.LastNewsPanel_7)
        self.Sector2_4.setObjectName(u"Sector2_4")
        self.Sector2_4.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector2_4.setCheckable(False)
        self.Sector2_4.setChecked(False)

        self.horizontalLayout_47.addWidget(self.Sector2_4)

        self.check2_3 = QLabel(self.LastNewsPanel_7)
        self.check2_3.setObjectName(u"check2_3")
        sizePolicy4.setHeightForWidth(self.check2_3.sizePolicy().hasHeightForWidth())
        self.check2_3.setSizePolicy(sizePolicy4)
        self.check2_3.setMinimumSize(QSize(40, 10))
        self.check2_3.setStyleSheet(u"background-color: transparent;")
        self.check2_3.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check2_3.setScaledContents(True)

        self.horizontalLayout_47.addWidget(self.check2_3)


        self.gridLayout_13.addLayout(self.horizontalLayout_47, 8, 3, 1, 1)

        self.horizontalSpacer_34 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_13.addItem(self.horizontalSpacer_34, 6, 6, 1, 1)

        self.verticalSpacer_50 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_50, 11, 7, 1, 1)

        self.verticalSpacer_51 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_51, 14, 5, 1, 1)

        self.verticalSpacer_52 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_52, 2, 3, 1, 1)

        self.horizontalSpacer_35 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_13.addItem(self.horizontalSpacer_35, 13, 4, 1, 1)

        self.verticalSpacer_53 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_53, 6, 1, 1, 1)

        self.verticalSpacer_54 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_54, 7, 7, 1, 1)

        self.horizontalLayout_48 = QHBoxLayout()
        self.horizontalLayout_48.setObjectName(u"horizontalLayout_48")
        self.Sector6_4 = QPushButton(self.LastNewsPanel_7)
        self.Sector6_4.setObjectName(u"Sector6_4")
        self.Sector6_4.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector6_4.setCheckable(False)
        self.Sector6_4.setChecked(False)

        self.horizontalLayout_48.addWidget(self.Sector6_4)

        self.check6_3 = QLabel(self.LastNewsPanel_7)
        self.check6_3.setObjectName(u"check6_3")
        sizePolicy4.setHeightForWidth(self.check6_3.sizePolicy().hasHeightForWidth())
        self.check6_3.setSizePolicy(sizePolicy4)
        self.check6_3.setMinimumSize(QSize(40, 10))
        self.check6_3.setStyleSheet(u"background-color: transparent;")
        self.check6_3.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check6_3.setScaledContents(True)

        self.horizontalLayout_48.addWidget(self.check6_3)


        self.gridLayout_13.addLayout(self.horizontalLayout_48, 0, 5, 1, 1)

        self.horizontalLayout_49 = QHBoxLayout()
        self.horizontalLayout_49.setObjectName(u"horizontalLayout_49")
        self.Sector3_4 = QPushButton(self.LastNewsPanel_7)
        self.Sector3_4.setObjectName(u"Sector3_4")
        self.Sector3_4.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector3_4.setCheckable(False)
        self.Sector3_4.setChecked(False)

        self.horizontalLayout_49.addWidget(self.Sector3_4)

        self.check3_3 = QLabel(self.LastNewsPanel_7)
        self.check3_3.setObjectName(u"check3_3")
        sizePolicy4.setHeightForWidth(self.check3_3.sizePolicy().hasHeightForWidth())
        self.check3_3.setSizePolicy(sizePolicy4)
        self.check3_3.setMinimumSize(QSize(40, 10))
        self.check3_3.setStyleSheet(u"background-color: transparent;")
        self.check3_3.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check3_3.setScaledContents(True)

        self.horizontalLayout_49.addWidget(self.check3_3)


        self.gridLayout_13.addLayout(self.horizontalLayout_49, 15, 1, 1, 1)

        self.verticalSpacer_55 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_55, 4, 1, 1, 1)

        self.horizontalSpacer_36 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_13.addItem(self.horizontalSpacer_36, 4, 0, 1, 1)

        self.verticalSpacer_56 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_56, 13, 1, 1, 1)

        self.verticalSpacer_57 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_57, 12, 1, 1, 1)

        self.horizontalSpacer_37 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_13.addItem(self.horizontalSpacer_37, 6, 8, 1, 1)

        self.verticalSpacer_58 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_58, 9, 3, 1, 1)

        self.verticalSpacer_59 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_59, 8, 1, 1, 1)

        self.verticalSpacer_60 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_60, 16, 1, 1, 1)

        self.verticalSpacer_61 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_61, 3, 3, 1, 1)

        self.verticalSpacer_62 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_13.addItem(self.verticalSpacer_62, 1, 5, 1, 1)


        self.horizontalLayout_42.addWidget(self.LastNewsPanel_7)

        self.verticalLayout_28 = QVBoxLayout()
        self.verticalLayout_28.setObjectName(u"verticalLayout_28")
        self.verticalLayout_28.setContentsMargins(-1, -1, 0, 0)
        self.horizontalLayout_51 = QHBoxLayout()
        self.horizontalLayout_51.setObjectName(u"horizontalLayout_51")
        self.horizontalSpacer_38 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_51.addItem(self.horizontalSpacer_38)

        self.TitleLastNews_3 = QLabel(self.Market)
        self.TitleLastNews_3.setObjectName(u"TitleLastNews_3")
        self.TitleLastNews_3.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.TitleLastNews_3.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_51.addWidget(self.TitleLastNews_3)

        self.horizontalSpacer_39 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_51.addItem(self.horizontalSpacer_39)


        self.verticalLayout_28.addLayout(self.horizontalLayout_51)

        self.line_10 = QFrame(self.Market)
        self.line_10.setObjectName(u"line_10")
        self.line_10.setAutoFillBackground(False)
        self.line_10.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_10.setFrameShadow(QFrame.Shadow.Plain)
        self.line_10.setLineWidth(2)
        self.line_10.setMidLineWidth(2)
        self.line_10.setFrameShape(QFrame.Shape.HLine)

        self.verticalLayout_28.addWidget(self.line_10)

        self.scrollArea_5 = QScrollArea(self.Market)
        self.scrollArea_5.setObjectName(u"scrollArea_5")
        self.scrollArea_5.setWidgetResizable(True)
        self.scrollAreaWidgetContents_5 = QWidget()
        self.scrollAreaWidgetContents_5.setObjectName(u"scrollAreaWidgetContents_5")
        self.scrollAreaWidgetContents_5.setGeometry(QRect(0, 0, 76, 880))
        self.verticalLayout_31 = QVBoxLayout(self.scrollAreaWidgetContents_5)
        self.verticalLayout_31.setObjectName(u"verticalLayout_31")
        self.verticalLayout_31.setContentsMargins(0, 0, 0, 0)
        self.TextoLastNews_3 = QLabel(self.scrollAreaWidgetContents_5)
        self.TextoLastNews_3.setObjectName(u"TextoLastNews_3")
        self.TextoLastNews_3.setFont(font1)
        self.TextoLastNews_3.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.TextoLastNews_3.setStyleSheet(u"color: black;\n"
"text-align: center;\n"
"")
        self.TextoLastNews_3.setFrameShadow(QFrame.Shadow.Plain)
        self.TextoLastNews_3.setTextFormat(Qt.TextFormat.PlainText)
        self.TextoLastNews_3.setScaledContents(False)
        self.TextoLastNews_3.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)
        self.TextoLastNews_3.setWordWrap(True)

        self.verticalLayout_31.addWidget(self.TextoLastNews_3)

        self.scrollArea_5.setWidget(self.scrollAreaWidgetContents_5)

        self.verticalLayout_28.addWidget(self.scrollArea_5)

        self.horizontalLayout_52 = QHBoxLayout()
        self.horizontalLayout_52.setObjectName(u"horizontalLayout_52")
        self.horizontalSpacer_40 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_52.addItem(self.horizontalSpacer_40)

        self.TitleLastNews_4 = QLabel(self.Market)
        self.TitleLastNews_4.setObjectName(u"TitleLastNews_4")
        self.TitleLastNews_4.setStyleSheet(u"color: red;\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid red;")
        self.TitleLastNews_4.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_52.addWidget(self.TitleLastNews_4)

        self.horizontalSpacer_41 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_52.addItem(self.horizontalSpacer_41)


        self.verticalLayout_28.addLayout(self.horizontalLayout_52)

        self.line_11 = QFrame(self.Market)
        self.line_11.setObjectName(u"line_11")
        self.line_11.setAutoFillBackground(False)
        self.line_11.setStyleSheet(u"color: red")
        self.line_11.setFrameShadow(QFrame.Shadow.Plain)
        self.line_11.setLineWidth(2)
        self.line_11.setMidLineWidth(2)
        self.line_11.setFrameShape(QFrame.Shape.HLine)

        self.verticalLayout_28.addWidget(self.line_11)

        self.scrollArea_6 = QScrollArea(self.Market)
        self.scrollArea_6.setObjectName(u"scrollArea_6")
        self.scrollArea_6.setWidgetResizable(True)
        self.scrollAreaWidgetContents_6 = QWidget()
        self.scrollAreaWidgetContents_6.setObjectName(u"scrollAreaWidgetContents_6")
        self.scrollAreaWidgetContents_6.setGeometry(QRect(0, 0, 76, 880))
        self.verticalLayout_30 = QVBoxLayout(self.scrollAreaWidgetContents_6)
        self.verticalLayout_30.setObjectName(u"verticalLayout_30")
        self.verticalLayout_30.setContentsMargins(0, 0, 0, 0)
        self.TextoLastNews_4 = QLabel(self.scrollAreaWidgetContents_6)
        self.TextoLastNews_4.setObjectName(u"TextoLastNews_4")
        self.TextoLastNews_4.setFont(font1)
        self.TextoLastNews_4.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.TextoLastNews_4.setStyleSheet(u"color: black;\n"
"text-align: center;\n"
"")
        self.TextoLastNews_4.setFrameShadow(QFrame.Shadow.Plain)
        self.TextoLastNews_4.setTextFormat(Qt.TextFormat.PlainText)
        self.TextoLastNews_4.setScaledContents(False)
        self.TextoLastNews_4.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)
        self.TextoLastNews_4.setWordWrap(True)

        self.verticalLayout_30.addWidget(self.TextoLastNews_4)

        self.scrollArea_6.setWidget(self.scrollAreaWidgetContents_6)

        self.verticalLayout_28.addWidget(self.scrollArea_6)


        self.horizontalLayout_42.addLayout(self.verticalLayout_28)

        self.horizontalLayout_42.setStretch(0, 5)
        self.horizontalLayout_42.setStretch(1, 1)

        self.gridLayout_12.addLayout(self.horizontalLayout_42, 0, 0, 1, 1)

        self.stackedWidget.addWidget(self.Market)
        self.Sectors = QWidget()
        self.Sectors.setObjectName(u"Sectors")
        self.horizontalLayout_69 = QHBoxLayout(self.Sectors)
        self.horizontalLayout_69.setObjectName(u"horizontalLayout_69")
        self.horizontalLayout_68 = QHBoxLayout()
        self.horizontalLayout_68.setObjectName(u"horizontalLayout_68")
        self.verticalLayout_26 = QVBoxLayout()
        self.verticalLayout_26.setObjectName(u"verticalLayout_26")
        self.Sector1_2 = QPushButton(self.Sectors)
        self.Sector1_2.setObjectName(u"Sector1_2")
        self.Sector1_2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector1_2.setCheckable(False)
        self.Sector1_2.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector1_2)

        self.Sector2_2 = QPushButton(self.Sectors)
        self.Sector2_2.setObjectName(u"Sector2_2")
        self.Sector2_2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector2_2.setCheckable(False)
        self.Sector2_2.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector2_2)

        self.Sector3_2 = QPushButton(self.Sectors)
        self.Sector3_2.setObjectName(u"Sector3_2")
        self.Sector3_2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector3_2.setCheckable(False)
        self.Sector3_2.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector3_2)

        self.Sector4_2 = QPushButton(self.Sectors)
        self.Sector4_2.setObjectName(u"Sector4_2")
        self.Sector4_2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector4_2.setCheckable(False)
        self.Sector4_2.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector4_2)

        self.Sector5_2 = QPushButton(self.Sectors)
        self.Sector5_2.setObjectName(u"Sector5_2")
        self.Sector5_2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector5_2.setCheckable(False)
        self.Sector5_2.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector5_2)

        self.Sector6_2 = QPushButton(self.Sectors)
        self.Sector6_2.setObjectName(u"Sector6_2")
        self.Sector6_2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector6_2.setCheckable(False)
        self.Sector6_2.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector6_2)

        self.Sector7_7 = QPushButton(self.Sectors)
        self.Sector7_7.setObjectName(u"Sector7_7")
        self.Sector7_7.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_7.setCheckable(False)
        self.Sector7_7.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector7_7)

        self.Sector8_2 = QPushButton(self.Sectors)
        self.Sector8_2.setObjectName(u"Sector8_2")
        self.Sector8_2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector8_2.setCheckable(False)
        self.Sector8_2.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector8_2)


        self.horizontalLayout_68.addLayout(self.verticalLayout_26)

        self.gridLayout_7 = QGridLayout()
        self.gridLayout_7.setObjectName(u"gridLayout_7")
        self.verticalSpacer_7 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_7.addItem(self.verticalSpacer_7, 3, 1, 1, 1)

        self.verticalSpacer_8 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_7.addItem(self.verticalSpacer_8, 1, 1, 1, 1)

        self.horizontalSpacer_13 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_7.addItem(self.horizontalSpacer_13, 2, 0, 1, 1)

        self.frame_7 = QFrame(self.Sectors)
        self.frame_7.setObjectName(u"frame_7")
        self.frame_7.setStyleSheet(u"QFrame#frame_7{\n"
"	\n"
"	border-image: url(:/login/Temperature_panel.png);\n"
"}")
        self.frame_7.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_7.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_9 = QGridLayout(self.frame_7)
        self.gridLayout_9.setSpacing(0)
        self.gridLayout_9.setObjectName(u"gridLayout_9")
        self.gridLayout_9.setContentsMargins(0, 0, 0, 0)
        self.verticalSpacer_10 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_10, 0, 2, 1, 1)

        self.verticalSpacer_9 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_9, 2, 2, 1, 1)

        self.horizontalSpacer_15 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_9.addItem(self.horizontalSpacer_15, 1, 3, 1, 1)

        self.horizontalSpacer_14 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_9.addItem(self.horizontalSpacer_14, 1, 0, 1, 1)

        self.widget_11 = TermostatoWidget(self.frame_7)
        self.widget_11.setObjectName(u"widget_11")
        self.widget_11.setStyleSheet(u"#widget_11{\n"
"	border-image: url(:/login/InnerTemp.png);\n"
"	background-color: rgba(255, 255, 255, 0);\n"
"}")

        self.gridLayout_9.addWidget(self.widget_11, 1, 2, 1, 1)

        self.gridLayout_9.setRowStretch(0, 1)
        self.gridLayout_9.setRowStretch(1, 5)
        self.gridLayout_9.setRowStretch(2, 1)
        self.gridLayout_9.setColumnStretch(0, 1)
        self.gridLayout_9.setColumnStretch(2, 5)
        self.gridLayout_9.setColumnStretch(3, 1)

        self.gridLayout_7.addWidget(self.frame_7, 2, 1, 1, 1)

        self.frame_6 = QFrame(self.Sectors)
        self.frame_6.setObjectName(u"frame_6")
        self.frame_6.setStyleSheet(u"QFrame{\n"
"	border-radius: 30px;\n"
"	background-color: rgb(181, 231, 240);\n"
"}")
        self.frame_6.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_6.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_8 = QGridLayout(self.frame_6)
        self.gridLayout_8.setObjectName(u"gridLayout_8")
        self.label_17 = QLabel(self.frame_6)
        self.label_17.setObjectName(u"label_17")
        sizePolicy4.setHeightForWidth(self.label_17.sizePolicy().hasHeightForWidth())
        self.label_17.setSizePolicy(sizePolicy4)

        self.gridLayout_8.addWidget(self.label_17, 0, 0, 1, 1)


        self.gridLayout_7.addWidget(self.frame_6, 1, 2, 2, 2)

        self.widget_8 = SensorLuzWidget(self.Sectors)
        self.widget_8.setObjectName(u"widget_8")

        self.gridLayout_7.addWidget(self.widget_8, 0, 1, 1, 1)

        self.widget_9 = CalidadAireWidget(self.Sectors)
        self.widget_9.setObjectName(u"widget_9")

        self.gridLayout_7.addWidget(self.widget_9, 0, 2, 1, 1)

        self.widget_10 = SensorRuidoWidget(self.Sectors)
        self.widget_10.setObjectName(u"widget_10")

        self.gridLayout_7.addWidget(self.widget_10, 0, 3, 1, 1)

        self.gridLayout_7.setRowStretch(0, 1)
        self.gridLayout_7.setRowStretch(2, 1)
        self.gridLayout_7.setColumnStretch(1, 1)
        self.gridLayout_7.setColumnStretch(2, 1)
        self.gridLayout_7.setColumnStretch(3, 1)

        self.horizontalLayout_68.addLayout(self.gridLayout_7)

        self.horizontalLayout_68.setStretch(0, 1)
        self.horizontalLayout_68.setStretch(1, 10)

        self.horizontalLayout_69.addLayout(self.horizontalLayout_68)

        self.stackedWidget.addWidget(self.Sectors)
        self.Profile = QWidget()
        self.Profile.setObjectName(u"Profile")
        self.horizontalLayout_67 = QHBoxLayout(self.Profile)
        self.horizontalLayout_67.setObjectName(u"horizontalLayout_67")
        self.horizontalLayout_50 = QHBoxLayout()
        self.horizontalLayout_50.setObjectName(u"horizontalLayout_50")
        self.horizontalLayout_50.setContentsMargins(-1, -1, 0, -1)
        self.LastNewsPanel_5 = QFrame(self.Profile)
        self.LastNewsPanel_5.setObjectName(u"LastNewsPanel_5")
        self.LastNewsPanel_5.setFrameShape(QFrame.Shape.NoFrame)
        self.LastNewsPanel_5.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_19 = QVBoxLayout(self.LastNewsPanel_5)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.scrollArea_2 = QScrollArea(self.LastNewsPanel_5)
        self.scrollArea_2.setObjectName(u"scrollArea_2")
        self.scrollArea_2.setStyleSheet(u"")
        self.scrollArea_2.setFrameShape(QFrame.Shape.NoFrame)
        self.scrollArea_2.setFrameShadow(QFrame.Shadow.Plain)
        self.scrollArea_2.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scrollArea_2.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scrollArea_2.setWidgetResizable(True)
        self.scrollAreaWidgetContents_2 = QWidget()
        self.scrollAreaWidgetContents_2.setObjectName(u"scrollAreaWidgetContents_2")
        self.scrollAreaWidgetContents_2.setGeometry(QRect(0, 0, 100, 500))
        self.scrollAreaWidgetContents_2.setMinimumSize(QSize(100, 500))
        self.scrollAreaWidgetContents_2.setStyleSheet(u"")
        self.verticalLayout_24 = QVBoxLayout(self.scrollAreaWidgetContents_2)
        self.verticalLayout_24.setObjectName(u"verticalLayout_24")
        self.Title_4 = QLabel(self.scrollAreaWidgetContents_2)
        self.Title_4.setObjectName(u"Title_4")
        self.Title_4.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_4.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_24.addWidget(self.Title_4)

        self.Sector7_2 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_2.setObjectName(u"Sector7_2")
        self.Sector7_2.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_2.setCheckable(False)
        self.Sector7_2.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_2)

        self.verticalSpacer_5 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_24.addItem(self.verticalSpacer_5)

        self.Title_5 = QLabel(self.scrollAreaWidgetContents_2)
        self.Title_5.setObjectName(u"Title_5")
        self.Title_5.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_5.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_24.addWidget(self.Title_5)

        self.Sector7_4 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_4.setObjectName(u"Sector7_4")
        self.Sector7_4.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_4.setCheckable(False)
        self.Sector7_4.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_4)

        self.Sector7_3 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_3.setObjectName(u"Sector7_3")
        self.Sector7_3.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_3.setCheckable(False)
        self.Sector7_3.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_3)

        self.Sector7_5 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_5.setObjectName(u"Sector7_5")
        self.Sector7_5.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_5.setCheckable(False)
        self.Sector7_5.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_5)

        self.verticalSpacer_6 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_24.addItem(self.verticalSpacer_6)

        self.Title_6 = QLabel(self.scrollAreaWidgetContents_2)
        self.Title_6.setObjectName(u"Title_6")
        self.Title_6.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_6.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_24.addWidget(self.Title_6)

        self.Sector7_6 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_6.setObjectName(u"Sector7_6")
        self.Sector7_6.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_6.setCheckable(False)
        self.Sector7_6.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_6)

        self.Sector7_10 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_10.setObjectName(u"Sector7_10")
        self.Sector7_10.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_10.setCheckable(False)
        self.Sector7_10.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_10)

        self.Sector7_12 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_12.setObjectName(u"Sector7_12")
        self.Sector7_12.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_12.setCheckable(False)
        self.Sector7_12.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_12)

        self.Sector7_13 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_13.setObjectName(u"Sector7_13")
        self.Sector7_13.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_13.setCheckable(False)
        self.Sector7_13.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_13)

        self.Sector7_14 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_14.setObjectName(u"Sector7_14")
        self.Sector7_14.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_14.setCheckable(False)
        self.Sector7_14.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_14)

        self.Sector7_15 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_15.setObjectName(u"Sector7_15")
        self.Sector7_15.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_15.setCheckable(False)
        self.Sector7_15.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_15)

        self.Sector7_8 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_8.setObjectName(u"Sector7_8")
        self.Sector7_8.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_8.setCheckable(False)
        self.Sector7_8.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_8)

        self.verticalLayout_24.setStretch(1, 1)
        self.verticalLayout_24.setStretch(4, 1)
        self.verticalLayout_24.setStretch(5, 1)
        self.verticalLayout_24.setStretch(6, 1)
        self.verticalLayout_24.setStretch(9, 1)
        self.verticalLayout_24.setStretch(15, 1)
        self.scrollArea_2.setWidget(self.scrollAreaWidgetContents_2)

        self.verticalLayout_19.addWidget(self.scrollArea_2)


        self.horizontalLayout_50.addWidget(self.LastNewsPanel_5)

        self.verticalLayout_15 = QVBoxLayout()
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.verticalLayout_15.setContentsMargins(-1, -1, 0, 0)
        self.horizontalLayout_58 = QHBoxLayout()
        self.horizontalLayout_58.setObjectName(u"horizontalLayout_58")
        self.horizontalLayout_58.setContentsMargins(-1, -1, -1, 0)
        self.horizontalSpacer_9 = QSpacerItem(150, 60, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_58.addItem(self.horizontalSpacer_9)

        self.label_2 = QLabel(self.Profile)
        self.label_2.setObjectName(u"label_2")
        sizePolicy.setHeightForWidth(self.label_2.sizePolicy().hasHeightForWidth())
        self.label_2.setSizePolicy(sizePolicy)
        self.label_2.setMaximumSize(QSize(1677, 1677))
        self.label_2.setPixmap(QPixmap(u":/login/Check-it 1.png"))
        self.label_2.setScaledContents(False)

        self.horizontalLayout_58.addWidget(self.label_2)

        self.horizontalSpacer_10 = QSpacerItem(150, 100, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_58.addItem(self.horizontalSpacer_10)


        self.verticalLayout_15.addLayout(self.horizontalLayout_58)

        self.horizontalLayout_53 = QHBoxLayout()
        self.horizontalLayout_53.setObjectName(u"horizontalLayout_53")
        self.horizontalLayout_53.setContentsMargins(-1, -1, -1, 0)
        self.Title_9 = QLabel(self.Profile)
        self.Title_9.setObjectName(u"Title_9")
        sizePolicy.setHeightForWidth(self.Title_9.sizePolicy().hasHeightForWidth())
        self.Title_9.setSizePolicy(sizePolicy)
        self.Title_9.setStyleSheet(u"color: grey;\n"
"font: bold 23px \"Segoe UI\";\n"
"border-bottom: 2px solid grey;")
        self.Title_9.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)

        self.horizontalLayout_53.addWidget(self.Title_9)


        self.verticalLayout_15.addLayout(self.horizontalLayout_53)

        self.horizontalLayout_59 = QHBoxLayout()
        self.horizontalLayout_59.setObjectName(u"horizontalLayout_59")
        self.horizontalLayout_59.setContentsMargins(-1, -1, 0, 0)
        self.verticalLayout_25 = QVBoxLayout()
        self.verticalLayout_25.setObjectName(u"verticalLayout_25")
        self.verticalLayout_25.setContentsMargins(-1, 0, 0, 0)
        self.label_36 = QLabel(self.Profile)
        self.label_36.setObjectName(u"label_36")
        sizePolicy11 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy11.setHorizontalStretch(0)
        sizePolicy11.setVerticalStretch(0)
        sizePolicy11.setHeightForWidth(self.label_36.sizePolicy().hasHeightForWidth())
        self.label_36.setSizePolicy(sizePolicy11)
        self.label_36.setStyleSheet(u"color: black;\n"
"font: bold 16px \"Segoe UI\";")

        self.verticalLayout_25.addWidget(self.label_36)

        self.label_35 = QLabel(self.Profile)
        self.label_35.setObjectName(u"label_35")
        sizePolicy11.setHeightForWidth(self.label_35.sizePolicy().hasHeightForWidth())
        self.label_35.setSizePolicy(sizePolicy11)
        self.label_35.setStyleSheet(u"color: black;\n"
"font: bold 16px \"Segoe UI\";")

        self.verticalLayout_25.addWidget(self.label_35)

        self.label_22 = QLabel(self.Profile)
        self.label_22.setObjectName(u"label_22")
        self.label_22.setStyleSheet(u"color: black;\n"
"font: bold 16px \"Segoe UI\";")

        self.verticalLayout_25.addWidget(self.label_22)

        self.label_8 = QLabel(self.Profile)
        self.label_8.setObjectName(u"label_8")
        sizePolicy11.setHeightForWidth(self.label_8.sizePolicy().hasHeightForWidth())
        self.label_8.setSizePolicy(sizePolicy11)
        self.label_8.setStyleSheet(u"color: black;\n"
"font: bold 16px \"Segoe UI\";")

        self.verticalLayout_25.addWidget(self.label_8)

        self.label_4 = QLabel(self.Profile)
        self.label_4.setObjectName(u"label_4")
        sizePolicy11.setHeightForWidth(self.label_4.sizePolicy().hasHeightForWidth())
        self.label_4.setSizePolicy(sizePolicy11)
        self.label_4.setStyleSheet(u"color: black;\n"
"font: bold 16px \"Segoe UI\";")

        self.verticalLayout_25.addWidget(self.label_4)


        self.horizontalLayout_59.addLayout(self.verticalLayout_25)

        self.verticalLayout_29 = QVBoxLayout()
        self.verticalLayout_29.setObjectName(u"verticalLayout_29")
        self.lineEdit_nombre = QLineEdit(self.Profile)
        self.lineEdit_nombre.setObjectName(u"lineEdit_nombre")
        sizePolicy.setHeightForWidth(self.lineEdit_nombre.sizePolicy().hasHeightForWidth())
        self.lineEdit_nombre.setSizePolicy(sizePolicy)
        self.lineEdit_nombre.setStyleSheet(u"QLineEdit {\n"
"    /* Fondo gris claro, similar al de la imagen */\n"
"    background-color: #F0F0F0; \n"
"    \n"
"    /* Bordes redondeados */\n"
"    border-radius: 15px; /* Ajusta este valor para la curvatura deseada */\n"
"    \n"
"    /* Borde sutil (opcional, si el widget principal tiene otro color) */\n"
"    border: 1px solid #D0D0D0;\n"
"    \n"
"    /* Espaciado interno para que el texto no toque los bordes */\n"
"    padding: 5px 35px 5px 10px; /* Arriba Der. Abajo Izq. (Deja espacio a la derecha para el \u00edcono) */\n"
"\n"
"    /* Fuente y color del texto (opcional) */\n"
"    font-size: 12pt;\n"
"    color: #555555;\n"
"}")

        self.verticalLayout_29.addWidget(self.lineEdit_nombre)

        self.lineEdit_apellido = QLineEdit(self.Profile)
        self.lineEdit_apellido.setObjectName(u"lineEdit_apellido")
        sizePolicy.setHeightForWidth(self.lineEdit_apellido.sizePolicy().hasHeightForWidth())
        self.lineEdit_apellido.setSizePolicy(sizePolicy)
        self.lineEdit_apellido.setStyleSheet(u"QLineEdit {\n"
"    /* Fondo gris claro, similar al de la imagen */\n"
"    background-color: #F0F0F0; \n"
"    \n"
"    /* Bordes redondeados */\n"
"    border-radius: 15px; /* Ajusta este valor para la curvatura deseada */\n"
"    \n"
"    /* Borde sutil (opcional, si el widget principal tiene otro color) */\n"
"    border: 1px solid #D0D0D0;\n"
"    \n"
"    /* Espaciado interno para que el texto no toque los bordes */\n"
"    padding: 5px 35px 5px 10px; /* Arriba Der. Abajo Izq. (Deja espacio a la derecha para el \u00edcono) */\n"
"\n"
"    /* Fuente y color del texto (opcional) */\n"
"    font-size: 12pt;\n"
"    color: #555555;\n"
"}")

        self.verticalLayout_29.addWidget(self.lineEdit_apellido)

        self.lineEdit_correo = QLineEdit(self.Profile)
        self.lineEdit_correo.setObjectName(u"lineEdit_correo")
        sizePolicy.setHeightForWidth(self.lineEdit_correo.sizePolicy().hasHeightForWidth())
        self.lineEdit_correo.setSizePolicy(sizePolicy)
        self.lineEdit_correo.setStyleSheet(u"QLineEdit {\n"
"    /* Fondo gris claro, similar al de la imagen */\n"
"    background-color: #F0F0F0; \n"
"    \n"
"    /* Bordes redondeados */\n"
"    border-radius: 15px; /* Ajusta este valor para la curvatura deseada */\n"
"    \n"
"    /* Borde sutil (opcional, si el widget principal tiene otro color) */\n"
"    border: 1px solid #D0D0D0;\n"
"    \n"
"    /* Espaciado interno para que el texto no toque los bordes */\n"
"    padding: 5px 35px 5px 10px; /* Arriba Der. Abajo Izq. (Deja espacio a la derecha para el \u00edcono) */\n"
"\n"
"    /* Fuente y color del texto (opcional) */\n"
"    font-size: 12pt;\n"
"    color: #555555;\n"
"}")

        self.verticalLayout_29.addWidget(self.lineEdit_correo)

        self.lineEdit_telefono = QLineEdit(self.Profile)
        self.lineEdit_telefono.setObjectName(u"lineEdit_telefono")
        sizePolicy.setHeightForWidth(self.lineEdit_telefono.sizePolicy().hasHeightForWidth())
        self.lineEdit_telefono.setSizePolicy(sizePolicy)
        self.lineEdit_telefono.setStyleSheet(u"QLineEdit {\n"
"    /* Fondo gris claro, similar al de la imagen */\n"
"    background-color: #F0F0F0; \n"
"    \n"
"    /* Bordes redondeados */\n"
"    border-radius: 15px; /* Ajusta este valor para la curvatura deseada */\n"
"    \n"
"    /* Borde sutil (opcional, si el widget principal tiene otro color) */\n"
"    border: 1px solid #D0D0D0;\n"
"    \n"
"    /* Espaciado interno para que el texto no toque los bordes */\n"
"    padding: 5px 35px 5px 10px; /* Arriba Der. Abajo Izq. (Deja espacio a la derecha para el \u00edcono) */\n"
"\n"
"    /* Fuente y color del texto (opcional) */\n"
"    font-size: 12pt;\n"
"    color: #555555;\n"
"}")

        self.verticalLayout_29.addWidget(self.lineEdit_telefono)

        self.lineEdit_id = QLineEdit(self.Profile)
        self.lineEdit_id.setObjectName(u"lineEdit_id")
        sizePolicy.setHeightForWidth(self.lineEdit_id.sizePolicy().hasHeightForWidth())
        self.lineEdit_id.setSizePolicy(sizePolicy)
        self.lineEdit_id.setStyleSheet(u"QLineEdit {\n"
"    /* Fondo gris claro, similar al de la imagen */\n"
"    background-color: #F0F0F0; \n"
"    \n"
"    /* Bordes redondeados */\n"
"    border-radius: 15px; /* Ajusta este valor para la curvatura deseada */\n"
"    \n"
"    /* Borde sutil (opcional, si el widget principal tiene otro color) */\n"
"    border: 1px solid #D0D0D0;\n"
"    \n"
"    /* Espaciado interno para que el texto no toque los bordes */\n"
"    padding: 5px 35px 5px 10px; /* Arriba Der. Abajo Izq. (Deja espacio a la derecha para el \u00edcono) */\n"
"\n"
"    /* Fuente y color del texto (opcional) */\n"
"    font-size: 12pt;\n"
"    color: #555555;\n"
"}")

        self.verticalLayout_29.addWidget(self.lineEdit_id)


        self.horizontalLayout_59.addLayout(self.verticalLayout_29)


        self.verticalLayout_15.addLayout(self.horizontalLayout_59)

        self.verticalLayout_15.setStretch(0, 2)
        self.verticalLayout_15.setStretch(1, 1)
        self.verticalLayout_15.setStretch(2, 4)

        self.horizontalLayout_50.addLayout(self.verticalLayout_15)

        self.horizontalLayout_50.setStretch(0, 1)
        self.horizontalLayout_50.setStretch(1, 2)

        self.horizontalLayout_67.addLayout(self.horizontalLayout_50)

        self.stackedWidget.addWidget(self.Profile)

        self.verticalLayout.addWidget(self.stackedWidget)


        self.horizontalLayout.addLayout(self.verticalLayout)


        self.verticalLayout_3.addLayout(self.horizontalLayout)

        self.verticalLayout_3.setStretch(0, 1)
        self.verticalLayout_3.setStretch(1, 5)

        self.gridLayout.addLayout(self.verticalLayout_3, 0, 0, 1, 1)

        WorkerWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(WorkerWindow)

        self.pushButton.setDefault(False)
        self.pushButton_2.setDefault(False)
        self.pushButton_3.setDefault(False)
        self.pushButton_4.setDefault(False)
        self.pushButton_5.setDefault(False)
        self.pushButton_9.setDefault(False)
        self.pushButton_8.setDefault(False)
        self.stackedWidget.setCurrentIndex(0)
        self.pushButton_7.setDefault(False)
        self.pushButton_6.setDefault(False)
        self.stackedWidget_2.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(WorkerWindow)
    # setupUi

    def retranslateUi(self, WorkerWindow):
        WorkerWindow.setWindowTitle(QCoreApplication.translate("WorkerWindow", u"MainWindow", None))
        self.label.setText("")
        self.pushButton.setText(QCoreApplication.translate("WorkerWindow", u"Home", None))
        self.pushButton_2.setText(QCoreApplication.translate("WorkerWindow", u"News", None))
        self.pushButton_3.setText(QCoreApplication.translate("WorkerWindow", u"Status", None))
        self.pushButton_4.setText(QCoreApplication.translate("WorkerWindow", u"Sectors", None))
        self.pushButton_5.setText(QCoreApplication.translate("WorkerWindow", u"Market", None))
        self.pushButton_9.setText(QCoreApplication.translate("WorkerWindow", u"Chat", None))
        self.pushButton_8.setText(QCoreApplication.translate("WorkerWindow", u"Profile", None))
        self.Title_7.setText(QCoreApplication.translate("WorkerWindow", u"Alerts", None))
        self.New_3.setText(QCoreApplication.translate("WorkerWindow", u"Smoke detectors are detecting excessive smoke in sector 15. Check for a possible fire. \n"
"If a fire is developing, activate the fire sprinklers.", None))
        self.pushButton_7.setText(QCoreApplication.translate("WorkerWindow", u"Activate", None))
        self.pushButton_6.setText(QCoreApplication.translate("WorkerWindow", u"Cancel", None))
        self.Title.setText(QCoreApplication.translate("WorkerWindow", u" Last News", None))
        self.label_3.setText("")
        self.New.setText(QCoreApplication.translate("WorkerWindow", u"Lorem ipsum dolor sit amet consectetur adipiscing elit sagittis iaculis nascetur", None))
        self.label_parking.setText(QCoreApplication.translate("WorkerWindow", u"Plazas disponibles:", None))
        self.Title_13.setText(QCoreApplication.translate("WorkerWindow", u"CHATS", None))
        self.Sector7_16.setText(QCoreApplication.translate("WorkerWindow", u"New Chat", None))
        self.label_19.setText("")
        self.label_20.setText(QCoreApplication.translate("WorkerWindow", u"Ningun chat ha sido seleccionado", None))
        self.Image.setText("")
        self.User.setText(QCoreApplication.translate("WorkerWindow", u"Usuario", None))
        self.Mensajes.setText("")
        self.plainTextEdit.setPlainText(QCoreApplication.translate("WorkerWindow", u"Text here", None))
        self.pushButton_10.setText(QCoreApplication.translate("WorkerWindow", u"Send", None))
        self.Title_2.setText(QCoreApplication.translate("WorkerWindow", u"PUBLISH NEWS", None))
        self.Sector7_9.setText(QCoreApplication.translate("WorkerWindow", u"PUBLISH", None))
        self.label_9.setText(QCoreApplication.translate("WorkerWindow", u"TITLE:", None))
        self.Name_Line_Edit_2.setText("")
        self.label_10.setText(QCoreApplication.translate("WorkerWindow", u"SHORT:", None))
        self.Name_Line_Edit.setText("")
        self.label_21.setText(QCoreApplication.translate("WorkerWindow", u"BODY:", None))
        self.Name_Line_Edit_5.setText("")
        self.Title_3.setText(QCoreApplication.translate("WorkerWindow", u"Your News", None))
        self.label_5.setText("")
        self.label_7.setText(QCoreApplication.translate("WorkerWindow", u"TextLabel", None))
        self.label_6.setText(QCoreApplication.translate("WorkerWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut leo euismod, sagittis nibh nec, congue enim. Mauris sagittis maximus diam a lacinia. Curabitur at ultrices massa, ut tempor metus. Nam non euismod ligula. Nam euismod rhoncus ornare. Morbi molestie vehicula turpis, quis aliquam leo finibus eu. Phasellus gravida, elit non posuere mattis, ipsum diam accumsan libero, sit amet tincidunt leo mauris quis arcu.", None))
        self.label_14.setText("")
        self.label_15.setText(QCoreApplication.translate("WorkerWindow", u"TextLabel", None))
        self.label_16.setText(QCoreApplication.translate("WorkerWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut leo euismod, sagittis nibh nec, congue enim. Mauris sagittis maximus diam a lacinia. Curabitur at ultrices massa, ut tempor metus. Nam non euismod ligula. Nam euismod rhoncus ornare. Morbi molestie vehicula turpis, quis aliquam leo finibus eu. Phasellus gravida, elit non posuere mattis, ipsum diam accumsan libero, sit amet tincidunt leo mauris quis arcu.", None))
        self.label_23.setText("")
        self.label_24.setText(QCoreApplication.translate("WorkerWindow", u"TextLabel", None))
        self.label_25.setText(QCoreApplication.translate("WorkerWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut leo euismod, sagittis nibh nec, congue enim. Mauris sagittis maximus diam a lacinia. Curabitur at ultrices massa, ut tempor metus. Nam non euismod ligula. Nam euismod rhoncus ornare. Morbi molestie vehicula turpis, quis aliquam leo finibus eu. Phasellus gravida, elit non posuere mattis, ipsum diam accumsan libero, sit amet tincidunt leo mauris quis arcu.", None))
        self.label_26.setText("")
        self.label_27.setText(QCoreApplication.translate("WorkerWindow", u"TextLabel", None))
        self.label_28.setText(QCoreApplication.translate("WorkerWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut leo euismod, sagittis nibh nec, congue enim. Mauris sagittis maximus diam a lacinia. Curabitur at ultrices massa, ut tempor metus. Nam non euismod ligula. Nam euismod rhoncus ornare. Morbi molestie vehicula turpis, quis aliquam leo finibus eu. Phasellus gravida, elit non posuere mattis, ipsum diam accumsan libero, sit amet tincidunt leo mauris quis arcu.", None))
        self.label_29.setText("")
        self.label_30.setText(QCoreApplication.translate("WorkerWindow", u"TextLabel", None))
        self.label_31.setText(QCoreApplication.translate("WorkerWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut leo euismod, sagittis nibh nec, congue enim. Mauris sagittis maximus diam a lacinia. Curabitur at ultrices massa, ut tempor metus. Nam non euismod ligula. Nam euismod rhoncus ornare. Morbi molestie vehicula turpis, quis aliquam leo finibus eu. Phasellus gravida, elit non posuere mattis, ipsum diam accumsan libero, sit amet tincidunt leo mauris quis arcu.", None))
        self.label_32.setText("")
        self.label_33.setText(QCoreApplication.translate("WorkerWindow", u"TextLabel", None))
        self.label_34.setText(QCoreApplication.translate("WorkerWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut leo euismod, sagittis nibh nec, congue enim. Mauris sagittis maximus diam a lacinia. Curabitur at ultrices massa, ut tempor metus. Nam non euismod ligula. Nam euismod rhoncus ornare. Morbi molestie vehicula turpis, quis aliquam leo finibus eu. Phasellus gravida, elit non posuere mattis, ipsum diam accumsan libero, sit amet tincidunt leo mauris quis arcu.", None))
        self.label_11.setText("")
        self.label_12.setText(QCoreApplication.translate("WorkerWindow", u"TextLabel", None))
        self.label_13.setText(QCoreApplication.translate("WorkerWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut leo euismod, sagittis nibh nec, congue enim. Mauris sagittis maximus diam a lacinia. Curabitur at ultrices massa, ut tempor metus. Nam non euismod ligula. Nam euismod rhoncus ornare. Morbi molestie vehicula turpis, quis aliquam leo finibus eu. Phasellus gravida, elit non posuere mattis, ipsum diam accumsan libero, sit amet tincidunt leo mauris quis arcu.", None))
        self.Sector3.setText(QCoreApplication.translate("WorkerWindow", u"Sector 3:", None))
        self.check3.setText("")
        self.Sector8.setText(QCoreApplication.translate("WorkerWindow", u"Sector 8:", None))
        self.check8.setText("")
        self.Sector6.setText(QCoreApplication.translate("WorkerWindow", u"Sector 6:", None))
        self.check6.setText("")
        self.Sector5.setText(QCoreApplication.translate("WorkerWindow", u"Sector 5:", None))
        self.check5.setText("")
        self.Sector4.setText(QCoreApplication.translate("WorkerWindow", u"Sector 4:", None))
        self.check4.setText("")
        self.Sector1.setText(QCoreApplication.translate("WorkerWindow", u"Sector 1:", None))
        self.check1.setText("")
        self.Sector7.setText(QCoreApplication.translate("WorkerWindow", u"Sector 7:", None))
        self.check7.setText("")
        self.Sector2.setText(QCoreApplication.translate("WorkerWindow", u"Sector 2:", None))
        self.check2.setText("")
        self.TitleLastNews.setText(QCoreApplication.translate("WorkerWindow", u"Information", None))
        self.TextoLastNews.setText(QCoreApplication.translate("WorkerWindow", u"Lorem ipsum dolor sit amet consectetur adipiscing elit sagittis iaculis nascetur, vestibulum convallis arcu varius ullamcorper accumsan a urna sodales, rutrum odio magna consequat dapibus mauris leo proin posuere. Pharetra aptent luctus justo quam in fusce morbi ad himenaeos, hendrerit conubia fames ultrices nulla vitae suspendisse ante malesuada dis, enim cubilia molestie purus nisi mattis ut mi. Lacinia conubia urna penatibus ridiculus quisque et scelerisque, natoque condimentum dapibus fermentum montes fringilla facilisis, neque inceptos tempor euismod turpis nascetur.", None))
        self.TitleLastNews_2.setText(QCoreApplication.translate("WorkerWindow", u"Alerts", None))
        self.TextoLastNews_2.setText(QCoreApplication.translate("WorkerWindow", u"Lorem ipsum dolor sit amet consectetur adipiscing elit sagittis iaculis nascetur, vestibulum convallis arcu varius ullamcorper accumsan a urna sodales, rutrum odio magna consequat dapibus mauris leo proin posuere. Pharetra aptent luctus justo quam in fusce morbi ad himenaeos, hendrerit conubia fames ultrices nulla vitae suspendisse ante malesuada dis, enim cubilia molestie purus nisi mattis ut mi. Lacinia conubia urna penatibus ridiculus quisque et scelerisque, natoque condimentum dapibus fermentum montes fringilla facilisis, neque inceptos tempor euismod turpis nascetur.", None))
        self.Sector5_4.setText(QCoreApplication.translate("WorkerWindow", u"Sector 5:", None))
        self.check5_3.setText("")
        self.Sector4_4.setText(QCoreApplication.translate("WorkerWindow", u"Sector 4:", None))
        self.check4_3.setText("")
        self.Sector1_4.setText(QCoreApplication.translate("WorkerWindow", u"Sector 1:", None))
        self.check1_3.setText("")
        self.Sector7_11.setText(QCoreApplication.translate("WorkerWindow", u"Sector 7:", None))
        self.check7_3.setText("")
        self.Sector2_4.setText(QCoreApplication.translate("WorkerWindow", u"Sector 2:", None))
        self.check2_3.setText("")
        self.Sector6_4.setText(QCoreApplication.translate("WorkerWindow", u"Sector 6:", None))
        self.check6_3.setText("")
        self.Sector3_4.setText(QCoreApplication.translate("WorkerWindow", u"Sector 3:", None))
        self.check3_3.setText("")
        self.TitleLastNews_3.setText(QCoreApplication.translate("WorkerWindow", u"Information", None))
        self.TextoLastNews_3.setText(QCoreApplication.translate("WorkerWindow", u"Lorem ipsum dolor sit amet consectetur adipiscing elit sagittis iaculis nascetur, vestibulum convallis arcu varius ullamcorper accumsan a urna sodales, rutrum odio magna consequat dapibus mauris leo proin posuere. Pharetra aptent luctus justo quam in fusce morbi ad himenaeos, hendrerit conubia fames ultrices nulla vitae suspendisse ante malesuada dis, enim cubilia molestie purus nisi mattis ut mi. Lacinia conubia urna penatibus ridiculus quisque et scelerisque, natoque condimentum dapibus fermentum montes fringilla facilisis, neque inceptos tempor euismod turpis nascetur.", None))
        self.TitleLastNews_4.setText(QCoreApplication.translate("WorkerWindow", u"Alerts", None))
        self.TextoLastNews_4.setText(QCoreApplication.translate("WorkerWindow", u"Lorem ipsum dolor sit amet consectetur adipiscing elit sagittis iaculis nascetur, vestibulum convallis arcu varius ullamcorper accumsan a urna sodales, rutrum odio magna consequat dapibus mauris leo proin posuere. Pharetra aptent luctus justo quam in fusce morbi ad himenaeos, hendrerit conubia fames ultrices nulla vitae suspendisse ante malesuada dis, enim cubilia molestie purus nisi mattis ut mi. Lacinia conubia urna penatibus ridiculus quisque et scelerisque, natoque condimentum dapibus fermentum montes fringilla facilisis, neque inceptos tempor euismod turpis nascetur.", None))
        self.Sector1_2.setText(QCoreApplication.translate("WorkerWindow", u"Sector 1:", None))
        self.Sector2_2.setText(QCoreApplication.translate("WorkerWindow", u"Sector 2:", None))
        self.Sector3_2.setText(QCoreApplication.translate("WorkerWindow", u"Sector 3:", None))
        self.Sector4_2.setText(QCoreApplication.translate("WorkerWindow", u"Sector 4:", None))
        self.Sector5_2.setText(QCoreApplication.translate("WorkerWindow", u"Sector 5:", None))
        self.Sector6_2.setText(QCoreApplication.translate("WorkerWindow", u"Sector 6:", None))
        self.Sector7_7.setText(QCoreApplication.translate("WorkerWindow", u"Sector 7:", None))
        self.Sector8_2.setText(QCoreApplication.translate("WorkerWindow", u"Sector 8:", None))
        self.label_17.setText(QCoreApplication.translate("WorkerWindow", u"DATA", None))
        self.Title_4.setText(QCoreApplication.translate("WorkerWindow", u"Profile", None))
        self.Sector7_2.setText(QCoreApplication.translate("WorkerWindow", u"Edit Profile", None))
        self.Title_5.setText(QCoreApplication.translate("WorkerWindow", u"Control & Security", None))
        self.Sector7_4.setText(QCoreApplication.translate("WorkerWindow", u"Privacy", None))
        self.Sector7_3.setText(QCoreApplication.translate("WorkerWindow", u"Subscriptions", None))
        self.Sector7_5.setText(QCoreApplication.translate("WorkerWindow", u"Accesibility", None))
        self.Title_6.setText(QCoreApplication.translate("WorkerWindow", u"App Settings", None))
        self.Sector7_6.setText(QCoreApplication.translate("WorkerWindow", u"Language", None))
        self.Sector7_10.setText(QCoreApplication.translate("WorkerWindow", u"Notifications", None))
        self.Sector7_12.setText(QCoreApplication.translate("WorkerWindow", u"Notifications", None))
        self.Sector7_13.setText(QCoreApplication.translate("WorkerWindow", u"Notifications", None))
        self.Sector7_14.setText(QCoreApplication.translate("WorkerWindow", u"Notifications", None))
        self.Sector7_15.setText(QCoreApplication.translate("WorkerWindow", u"Notifications", None))
        self.Sector7_8.setText(QCoreApplication.translate("WorkerWindow", u"Notifications", None))
        self.label_2.setText("")
        self.Title_9.setText(QCoreApplication.translate("WorkerWindow", u"Data", None))
        self.label_36.setText(QCoreApplication.translate("WorkerWindow", u"Name", None))
        self.label_35.setText(QCoreApplication.translate("WorkerWindow", u"Surname", None))
        self.label_22.setText(QCoreApplication.translate("WorkerWindow", u"Mail", None))
        self.label_8.setText(QCoreApplication.translate("WorkerWindow", u"Tlf", None))
        self.label_4.setText(QCoreApplication.translate("WorkerWindow", u"ID", None))
        self.lineEdit_nombre.setText(QCoreApplication.translate("WorkerWindow", u"Usuario", None))
        self.lineEdit_nombre.setPlaceholderText("")
        self.lineEdit_apellido.setText(QCoreApplication.translate("WorkerWindow", u"Ejemplo De Usuario", None))
        self.lineEdit_apellido.setPlaceholderText("")
        self.lineEdit_correo.setText(QCoreApplication.translate("WorkerWindow", u"user@example.com", None))
        self.lineEdit_correo.setPlaceholderText("")
        self.lineEdit_telefono.setText(QCoreApplication.translate("WorkerWindow", u"123456789", None))
        self.lineEdit_telefono.setPlaceholderText("")
        self.lineEdit_id.setText(QCoreApplication.translate("WorkerWindow", u"1425367R", None))
        self.lineEdit_id.setPlaceholderText("")
    # retranslateUi

