# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'User.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QHBoxLayout,
    QLabel, QLayout, QMainWindow, QPushButton,
    QScrollArea, QSizePolicy, QSpacerItem, QStackedWidget,
    QVBoxLayout, QWidget)

from componentes import TermostatoWidget
import rc_Recursos

class Ui_UserWindow(object):
    def setupUi(self, UserWindow):
        if not UserWindow.objectName():
            UserWindow.setObjectName(u"UserWindow")
        UserWindow.resize(842, 609)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(UserWindow.sizePolicy().hasHeightForWidth())
        UserWindow.setSizePolicy(sizePolicy)
        self.centralwidget = QWidget(UserWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(0, 0, 845, 610))
        self.frame.setStyleSheet(u"background-color: white")
        self.frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame.setFrameShadow(QFrame.Shadow.Plain)
        self.gridLayout = QGridLayout(self.frame)
        self.gridLayout.setSpacing(0)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.frame_2 = QFrame(self.frame)
        self.frame_2.setObjectName(u"frame_2")
        sizePolicy.setHeightForWidth(self.frame_2.sizePolicy().hasHeightForWidth())
        self.frame_2.setSizePolicy(sizePolicy)
        self.frame_2.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_5 = QGridLayout(self.frame_2)
        self.gridLayout_5.setSpacing(0)
        self.gridLayout_5.setObjectName(u"gridLayout_5")
        self.gridLayout_5.setContentsMargins(0, 0, 0, 0)
        self.frame_3 = QFrame(self.frame_2)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setAutoFillBackground(False)
        self.frame_3.setStyleSheet(u".QFrame {\n"
"    border-image: url(:/Login/Topcornerusers.png);\n"
"}")
        self.frame_3.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.frame_3)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(2, 2, 2, 2)
        self.label = QLabel(self.frame_3)
        self.label.setObjectName(u"label")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy1)
        self.label.setMinimumSize(QSize(80, 80))
        self.label.setMaximumSize(QSize(150, 150))
        self.label.setSizeIncrement(QSize(1, 1))
        self.label.setAutoFillBackground(False)
        self.label.setStyleSheet(u"QLabel{\n"
"background-color: transparent; \n"
"    border: none; /* A veces el borde a\u00f1ade color */\n"
"}")
        self.label.setPixmap(QPixmap(u":/Login/Check-it 1.png"))
        self.label.setScaledContents(True)

        self.horizontalLayout_2.addWidget(self.label)

        self.horizontalSpacer_3 = QSpacerItem(185, 20, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_3)

        self.pushButton = QPushButton(self.frame_3)
        self.pushButton.setObjectName(u"pushButton")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.pushButton.sizePolicy().hasHeightForWidth())
        self.pushButton.setSizePolicy(sizePolicy2)
        font = QFont()
        font.setPointSize(12)
        font.setBold(True)
        self.pushButton.setFont(font)
        self.pushButton.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton.setCheckable(False)
        self.pushButton.setChecked(False)

        self.horizontalLayout_2.addWidget(self.pushButton)

        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_5)

        self.pushButton_2 = QPushButton(self.frame_3)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setFont(font)
        self.pushButton_2.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_2.setCheckable(False)

        self.horizontalLayout_2.addWidget(self.pushButton_2)

        self.horizontalSpacer_6 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_6)

        self.pushButton_3 = QPushButton(self.frame_3)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setFont(font)
        self.pushButton_3.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_3.setCheckable(False)

        self.horizontalLayout_2.addWidget(self.pushButton_3)

        self.horizontalSpacer_7 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_7)

        self.pushButton_4 = QPushButton(self.frame_3)
        self.pushButton_4.setObjectName(u"pushButton_4")
        self.pushButton_4.setFont(font)
        self.pushButton_4.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_4.setCheckable(False)

        self.horizontalLayout_2.addWidget(self.pushButton_4)

        self.horizontalSpacer_8 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_8)

        self.pushButton_5 = QPushButton(self.frame_3)
        self.pushButton_5.setObjectName(u"pushButton_5")
        self.pushButton_5.setFont(font)
        self.pushButton_5.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_5.setCheckable(False)

        self.horizontalLayout_2.addWidget(self.pushButton_5)

        self.horizontalSpacer_4 = QSpacerItem(185, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_4)

        self.horizontalLayout_2.setStretch(0, 1)
        self.horizontalLayout_2.setStretch(3, 1)
        self.horizontalLayout_2.setStretch(5, 1)
        self.horizontalLayout_2.setStretch(7, 1)
        self.horizontalLayout_2.setStretch(9, 1)
        self.horizontalLayout_2.setStretch(11, 1)

        self.gridLayout_5.addWidget(self.frame_3, 0, 0, 2, 1)

        self.gridLayout_5.setRowStretch(0, 2)

        self.verticalLayout_3.addWidget(self.frame_2)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.stackedWidget = QStackedWidget(self.frame)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.Home = QWidget()
        self.Home.setObjectName(u"Home")
        self.gridLayout_2 = QGridLayout(self.Home)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.LastNewsPanel = QFrame(self.Home)
        self.LastNewsPanel.setObjectName(u"LastNewsPanel")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.LastNewsPanel.sizePolicy().hasHeightForWidth())
        self.LastNewsPanel.setSizePolicy(sizePolicy3)
        self.LastNewsPanel.setFrameShape(QFrame.Shape.StyledPanel)
        self.LastNewsPanel.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_5 = QVBoxLayout(self.LastNewsPanel)
        self.verticalLayout_5.setSpacing(5)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer_2)

        self.Title = QLabel(self.LastNewsPanel)
        self.Title.setObjectName(u"Title")
        self.Title.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_3.addWidget(self.Title)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer)


        self.verticalLayout_5.addLayout(self.horizontalLayout_3)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(25, -1, 25, -1)
        self.line = QFrame(self.LastNewsPanel)
        self.line.setObjectName(u"line")
        self.line.setAutoFillBackground(False)
        self.line.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line.setFrameShadow(QFrame.Shadow.Plain)
        self.line.setLineWidth(2)
        self.line.setMidLineWidth(2)
        self.line.setFrameShape(QFrame.Shape.HLine)

        self.horizontalLayout_4.addWidget(self.line)


        self.verticalLayout_5.addLayout(self.horizontalLayout_4)

        self.label_3 = QLabel(self.LastNewsPanel)
        self.label_3.setObjectName(u"label_3")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Ignored)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.label_3.sizePolicy().hasHeightForWidth())
        self.label_3.setSizePolicy(sizePolicy4)
        self.label_3.setPixmap(QPixmap(u":/Login/NewsImage.png"))
        self.label_3.setScaledContents(True)

        self.verticalLayout_5.addWidget(self.label_3)

        self.New = QLabel(self.LastNewsPanel)
        self.New.setObjectName(u"New")
        font1 = QFont()
        font1.setPointSize(7)
        self.New.setFont(font1)
        self.New.setFrameShadow(QFrame.Shadow.Plain)
        self.New.setTextFormat(Qt.TextFormat.PlainText)
        self.New.setScaledContents(False)
        self.New.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.New.setWordWrap(True)

        self.verticalLayout_5.addWidget(self.New)

        self.verticalLayout_5.setStretch(2, 1)
        self.verticalLayout_5.setStretch(3, 3)

        self.horizontalLayout_5.addWidget(self.LastNewsPanel)

        self.Data = QFrame(self.Home)
        self.Data.setObjectName(u"Data")
        sizePolicy3.setHeightForWidth(self.Data.sizePolicy().hasHeightForWidth())
        self.Data.setSizePolicy(sizePolicy3)
        self.Data.setFrameShape(QFrame.Shape.StyledPanel)
        self.Data.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_11 = QGridLayout(self.Data)
        self.gridLayout_11.setObjectName(u"gridLayout_11")
        self.frame_12 = QFrame(self.Data)
        self.frame_12.setObjectName(u"frame_12")
        self.frame_12.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_12.setFrameShadow(QFrame.Shadow.Raised)

        self.gridLayout_11.addWidget(self.frame_12, 0, 3, 1, 1)

        self.frame_15 = QFrame(self.Data)
        self.frame_15.setObjectName(u"frame_15")
        self.frame_15.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_15.setFrameShadow(QFrame.Shadow.Raised)

        self.gridLayout_11.addWidget(self.frame_15, 0, 1, 1, 1)

        self.frame_16 = QFrame(self.Data)
        self.frame_16.setObjectName(u"frame_16")
        self.frame_16.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_16.setFrameShadow(QFrame.Shadow.Raised)

        self.gridLayout_11.addWidget(self.frame_16, 0, 2, 1, 1)

        self.frame_13 = QFrame(self.Data)
        self.frame_13.setObjectName(u"frame_13")
        self.frame_13.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_13.setFrameShadow(QFrame.Shadow.Raised)

        self.gridLayout_11.addWidget(self.frame_13, 0, 0, 1, 1)

        self.frame_11 = QFrame(self.Data)
        self.frame_11.setObjectName(u"frame_11")
        self.frame_11.setStyleSheet(u"QFrame{\n"
"	border-radius: 30px;\n"
"	background-color: rgb(181, 231, 240);\n"
"}")
        self.frame_11.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_11.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_10 = QGridLayout(self.frame_11)
        self.gridLayout_10.setObjectName(u"gridLayout_10")
        self.label_18 = QLabel(self.frame_11)
        self.label_18.setObjectName(u"label_18")
        sizePolicy4.setHeightForWidth(self.label_18.sizePolicy().hasHeightForWidth())
        self.label_18.setSizePolicy(sizePolicy4)

        self.gridLayout_10.addWidget(self.label_18, 0, 0, 1, 1)


        self.gridLayout_11.addWidget(self.frame_11, 1, 0, 2, 4)

        self.gridLayout_11.setRowStretch(0, 1)
        self.gridLayout_11.setRowStretch(1, 1)
        self.gridLayout_11.setRowStretch(2, 1)
        self.gridLayout_11.setColumnStretch(0, 1)
        self.gridLayout_11.setColumnStretch(1, 1)
        self.gridLayout_11.setColumnStretch(2, 1)
        self.gridLayout_11.setColumnStretch(3, 1)

        self.horizontalLayout_5.addWidget(self.Data)

        self.horizontalLayout_5.setStretch(0, 1)
        self.horizontalLayout_5.setStretch(1, 3)

        self.gridLayout_2.addLayout(self.horizontalLayout_5, 0, 1, 1, 1)

        self.stackedWidget.addWidget(self.Home)
        self.News = QWidget()
        self.News.setObjectName(u"News")
        self.gridLayout_4 = QGridLayout(self.News)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.horizontalLayout_7 = QHBoxLayout()
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.LastNewsPanel_3 = QFrame(self.News)
        self.LastNewsPanel_3.setObjectName(u"LastNewsPanel_3")
        sizePolicy3.setHeightForWidth(self.LastNewsPanel_3.sizePolicy().hasHeightForWidth())
        self.LastNewsPanel_3.setSizePolicy(sizePolicy3)
        self.LastNewsPanel_3.setFrameShape(QFrame.Shape.StyledPanel)
        self.LastNewsPanel_3.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_9 = QVBoxLayout(self.LastNewsPanel_3)
        self.verticalLayout_9.setSpacing(5)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.horizontalLayout_8 = QHBoxLayout()
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.horizontalSpacer_9 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_8.addItem(self.horizontalSpacer_9)

        self.Title_2 = QLabel(self.LastNewsPanel_3)
        self.Title_2.setObjectName(u"Title_2")
        self.Title_2.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_2.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_8.addWidget(self.Title_2)

        self.horizontalSpacer_10 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_8.addItem(self.horizontalSpacer_10)


        self.verticalLayout_9.addLayout(self.horizontalLayout_8)

        self.horizontalLayout_9 = QHBoxLayout()
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.horizontalLayout_9.setContentsMargins(25, -1, 25, -1)
        self.line_2 = QFrame(self.LastNewsPanel_3)
        self.line_2.setObjectName(u"line_2")
        self.line_2.setAutoFillBackground(False)
        self.line_2.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_2.setFrameShadow(QFrame.Shadow.Plain)
        self.line_2.setLineWidth(2)
        self.line_2.setMidLineWidth(2)
        self.line_2.setFrameShape(QFrame.Shape.HLine)

        self.horizontalLayout_9.addWidget(self.line_2)


        self.verticalLayout_9.addLayout(self.horizontalLayout_9)

        self.label_4 = QLabel(self.LastNewsPanel_3)
        self.label_4.setObjectName(u"label_4")
        sizePolicy4.setHeightForWidth(self.label_4.sizePolicy().hasHeightForWidth())
        self.label_4.setSizePolicy(sizePolicy4)
        self.label_4.setPixmap(QPixmap(u":/Login/NewsImage.png"))
        self.label_4.setScaledContents(True)

        self.verticalLayout_9.addWidget(self.label_4)

        self.New_2 = QLabel(self.LastNewsPanel_3)
        self.New_2.setObjectName(u"New_2")
        self.New_2.setFont(font1)
        self.New_2.setFrameShadow(QFrame.Shadow.Plain)
        self.New_2.setTextFormat(Qt.TextFormat.PlainText)
        self.New_2.setScaledContents(False)
        self.New_2.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.New_2.setWordWrap(True)

        self.verticalLayout_9.addWidget(self.New_2)

        self.verticalLayout_9.setStretch(2, 1)
        self.verticalLayout_9.setStretch(3, 3)

        self.horizontalLayout_7.addWidget(self.LastNewsPanel_3)

        self.verticalLayout_10 = QVBoxLayout()
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalSpacer_2 = QSpacerItem(1, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_10.addItem(self.verticalSpacer_2)

        self.line_3 = QFrame(self.News)
        self.line_3.setObjectName(u"line_3")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Expanding)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.line_3.sizePolicy().hasHeightForWidth())
        self.line_3.setSizePolicy(sizePolicy5)
        self.line_3.setAutoFillBackground(False)
        self.line_3.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_3.setFrameShadow(QFrame.Shadow.Plain)
        self.line_3.setLineWidth(2)
        self.line_3.setMidLineWidth(2)
        self.line_3.setFrameShape(QFrame.Shape.VLine)

        self.verticalLayout_10.addWidget(self.line_3)

        self.verticalSpacer = QSpacerItem(1, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_10.addItem(self.verticalSpacer)

        self.verticalLayout_10.setStretch(1, 1)

        self.horizontalLayout_7.addLayout(self.verticalLayout_10)

        self.verticalLayout_11 = QVBoxLayout()
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalSpacer_3 = QSpacerItem(1, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_11.addItem(self.verticalSpacer_3)

        self.line_4 = QFrame(self.News)
        self.line_4.setObjectName(u"line_4")
        sizePolicy5.setHeightForWidth(self.line_4.sizePolicy().hasHeightForWidth())
        self.line_4.setSizePolicy(sizePolicy5)
        self.line_4.setAutoFillBackground(False)
        self.line_4.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_4.setFrameShadow(QFrame.Shadow.Plain)
        self.line_4.setLineWidth(2)
        self.line_4.setMidLineWidth(2)
        self.line_4.setFrameShape(QFrame.Shape.VLine)

        self.verticalLayout_11.addWidget(self.line_4)

        self.verticalSpacer_4 = QSpacerItem(1, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_11.addItem(self.verticalSpacer_4)

        self.verticalLayout_11.setStretch(0, 2)
        self.verticalLayout_11.setStretch(1, 5)
        self.verticalLayout_11.setStretch(2, 2)

        self.horizontalLayout_7.addLayout(self.verticalLayout_11)

        self.verticalLayout_12 = QVBoxLayout()
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.horizontalLayout_21 = QHBoxLayout()
        self.horizontalLayout_21.setObjectName(u"horizontalLayout_21")
        self.horizontalSpacer_17 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_21.addItem(self.horizontalSpacer_17)

        self.Title_3 = QLabel(self.News)
        self.Title_3.setObjectName(u"Title_3")
        self.Title_3.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_3.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_21.addWidget(self.Title_3)

        self.horizontalSpacer_18 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_21.addItem(self.horizontalSpacer_18)


        self.verticalLayout_12.addLayout(self.horizontalLayout_21)

        self.horizontalLayout_22 = QHBoxLayout()
        self.horizontalLayout_22.setObjectName(u"horizontalLayout_22")
        self.horizontalLayout_22.setContentsMargins(200, -1, 200, -1)
        self.line_5 = QFrame(self.News)
        self.line_5.setObjectName(u"line_5")
        self.line_5.setAutoFillBackground(False)
        self.line_5.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_5.setFrameShadow(QFrame.Shadow.Plain)
        self.line_5.setLineWidth(2)
        self.line_5.setMidLineWidth(2)
        self.line_5.setFrameShape(QFrame.Shape.HLine)

        self.horizontalLayout_22.addWidget(self.line_5)


        self.verticalLayout_12.addLayout(self.horizontalLayout_22)

        self.horizontalLayout_23 = QHBoxLayout()
        self.horizontalLayout_23.setObjectName(u"horizontalLayout_23")
        self.horizontalLayout_23.setContentsMargins(100, -1, 100, -1)
        self.line_6 = QFrame(self.News)
        self.line_6.setObjectName(u"line_6")
        self.line_6.setAutoFillBackground(False)
        self.line_6.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_6.setFrameShadow(QFrame.Shadow.Plain)
        self.line_6.setLineWidth(2)
        self.line_6.setMidLineWidth(2)
        self.line_6.setFrameShape(QFrame.Shape.HLine)

        self.horizontalLayout_23.addWidget(self.line_6)


        self.verticalLayout_12.addLayout(self.horizontalLayout_23)

        self.scrollArea = QScrollArea(self.News)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scrollArea.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 500, 1170))
        self.scrollAreaWidgetContents.setMinimumSize(QSize(500, 1000))
        self.scrollAreaWidgetContents.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.gridLayout_3 = QGridLayout(self.scrollAreaWidgetContents)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.verticalLayout_13 = QVBoxLayout()
        self.verticalLayout_13.setSpacing(12)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.horizontalLayout_12 = QHBoxLayout()
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.label_5 = QLabel(self.scrollAreaWidgetContents)
        self.label_5.setObjectName(u"label_5")
        sizePolicy4.setHeightForWidth(self.label_5.sizePolicy().hasHeightForWidth())
        self.label_5.setSizePolicy(sizePolicy4)
        self.label_5.setPixmap(QPixmap(u":/Login/NewsImage.png"))
        self.label_5.setScaledContents(True)

        self.horizontalLayout_12.addWidget(self.label_5)

        self.verticalLayout_14 = QVBoxLayout()
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.label_7 = QLabel(self.scrollAreaWidgetContents)
        self.label_7.setObjectName(u"label_7")

        self.verticalLayout_14.addWidget(self.label_7)

        self.label_6 = QLabel(self.scrollAreaWidgetContents)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setScaledContents(False)
        self.label_6.setWordWrap(True)

        self.verticalLayout_14.addWidget(self.label_6)


        self.horizontalLayout_12.addLayout(self.verticalLayout_14)

        self.horizontalLayout_12.setStretch(0, 1)
        self.horizontalLayout_12.setStretch(1, 2)

        self.verticalLayout_13.addLayout(self.horizontalLayout_12)

        self.horizontalLayout_18 = QHBoxLayout()
        self.horizontalLayout_18.setObjectName(u"horizontalLayout_18")
        self.label_14 = QLabel(self.scrollAreaWidgetContents)
        self.label_14.setObjectName(u"label_14")
        sizePolicy4.setHeightForWidth(self.label_14.sizePolicy().hasHeightForWidth())
        self.label_14.setSizePolicy(sizePolicy4)
        self.label_14.setPixmap(QPixmap(u":/Login/NewsImage.png"))
        self.label_14.setScaledContents(True)

        self.horizontalLayout_18.addWidget(self.label_14)

        self.verticalLayout_17 = QVBoxLayout()
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.label_15 = QLabel(self.scrollAreaWidgetContents)
        self.label_15.setObjectName(u"label_15")

        self.verticalLayout_17.addWidget(self.label_15)

        self.label_16 = QLabel(self.scrollAreaWidgetContents)
        self.label_16.setObjectName(u"label_16")
        self.label_16.setWordWrap(True)

        self.verticalLayout_17.addWidget(self.label_16)


        self.horizontalLayout_18.addLayout(self.verticalLayout_17)

        self.horizontalLayout_18.setStretch(0, 1)
        self.horizontalLayout_18.setStretch(1, 2)

        self.verticalLayout_13.addLayout(self.horizontalLayout_18)

        self.horizontalLayout_24 = QHBoxLayout()
        self.horizontalLayout_24.setObjectName(u"horizontalLayout_24")
        self.label_23 = QLabel(self.scrollAreaWidgetContents)
        self.label_23.setObjectName(u"label_23")
        sizePolicy4.setHeightForWidth(self.label_23.sizePolicy().hasHeightForWidth())
        self.label_23.setSizePolicy(sizePolicy4)
        self.label_23.setPixmap(QPixmap(u":/Login/NewsImage.png"))
        self.label_23.setScaledContents(True)

        self.horizontalLayout_24.addWidget(self.label_23)

        self.verticalLayout_20 = QVBoxLayout()
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.label_24 = QLabel(self.scrollAreaWidgetContents)
        self.label_24.setObjectName(u"label_24")

        self.verticalLayout_20.addWidget(self.label_24)

        self.label_25 = QLabel(self.scrollAreaWidgetContents)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setWordWrap(True)

        self.verticalLayout_20.addWidget(self.label_25)


        self.horizontalLayout_24.addLayout(self.verticalLayout_20)

        self.horizontalLayout_24.setStretch(0, 1)
        self.horizontalLayout_24.setStretch(1, 2)

        self.verticalLayout_13.addLayout(self.horizontalLayout_24)

        self.horizontalLayout_25 = QHBoxLayout()
        self.horizontalLayout_25.setObjectName(u"horizontalLayout_25")
        self.label_26 = QLabel(self.scrollAreaWidgetContents)
        self.label_26.setObjectName(u"label_26")
        sizePolicy4.setHeightForWidth(self.label_26.sizePolicy().hasHeightForWidth())
        self.label_26.setSizePolicy(sizePolicy4)
        self.label_26.setPixmap(QPixmap(u":/Login/NewsImage.png"))
        self.label_26.setScaledContents(True)

        self.horizontalLayout_25.addWidget(self.label_26)

        self.verticalLayout_21 = QVBoxLayout()
        self.verticalLayout_21.setObjectName(u"verticalLayout_21")
        self.label_27 = QLabel(self.scrollAreaWidgetContents)
        self.label_27.setObjectName(u"label_27")

        self.verticalLayout_21.addWidget(self.label_27)

        self.label_28 = QLabel(self.scrollAreaWidgetContents)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setWordWrap(True)

        self.verticalLayout_21.addWidget(self.label_28)


        self.horizontalLayout_25.addLayout(self.verticalLayout_21)

        self.horizontalLayout_25.setStretch(0, 1)
        self.horizontalLayout_25.setStretch(1, 2)

        self.verticalLayout_13.addLayout(self.horizontalLayout_25)

        self.horizontalLayout_26 = QHBoxLayout()
        self.horizontalLayout_26.setObjectName(u"horizontalLayout_26")
        self.label_29 = QLabel(self.scrollAreaWidgetContents)
        self.label_29.setObjectName(u"label_29")
        sizePolicy4.setHeightForWidth(self.label_29.sizePolicy().hasHeightForWidth())
        self.label_29.setSizePolicy(sizePolicy4)
        self.label_29.setPixmap(QPixmap(u":/Login/NewsImage.png"))
        self.label_29.setScaledContents(True)

        self.horizontalLayout_26.addWidget(self.label_29)

        self.verticalLayout_22 = QVBoxLayout()
        self.verticalLayout_22.setObjectName(u"verticalLayout_22")
        self.label_30 = QLabel(self.scrollAreaWidgetContents)
        self.label_30.setObjectName(u"label_30")

        self.verticalLayout_22.addWidget(self.label_30)

        self.label_31 = QLabel(self.scrollAreaWidgetContents)
        self.label_31.setObjectName(u"label_31")
        self.label_31.setWordWrap(True)

        self.verticalLayout_22.addWidget(self.label_31)


        self.horizontalLayout_26.addLayout(self.verticalLayout_22)

        self.horizontalLayout_26.setStretch(0, 1)
        self.horizontalLayout_26.setStretch(1, 2)

        self.verticalLayout_13.addLayout(self.horizontalLayout_26)

        self.horizontalLayout_27 = QHBoxLayout()
        self.horizontalLayout_27.setObjectName(u"horizontalLayout_27")
        self.label_32 = QLabel(self.scrollAreaWidgetContents)
        self.label_32.setObjectName(u"label_32")
        sizePolicy4.setHeightForWidth(self.label_32.sizePolicy().hasHeightForWidth())
        self.label_32.setSizePolicy(sizePolicy4)
        self.label_32.setPixmap(QPixmap(u":/Login/NewsImage.png"))
        self.label_32.setScaledContents(True)

        self.horizontalLayout_27.addWidget(self.label_32)

        self.verticalLayout_23 = QVBoxLayout()
        self.verticalLayout_23.setObjectName(u"verticalLayout_23")
        self.label_33 = QLabel(self.scrollAreaWidgetContents)
        self.label_33.setObjectName(u"label_33")

        self.verticalLayout_23.addWidget(self.label_33)

        self.label_34 = QLabel(self.scrollAreaWidgetContents)
        self.label_34.setObjectName(u"label_34")
        self.label_34.setWordWrap(True)

        self.verticalLayout_23.addWidget(self.label_34)


        self.horizontalLayout_27.addLayout(self.verticalLayout_23)

        self.horizontalLayout_27.setStretch(0, 1)
        self.horizontalLayout_27.setStretch(1, 2)

        self.verticalLayout_13.addLayout(self.horizontalLayout_27)

        self.horizontalLayout_17 = QHBoxLayout()
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.label_11 = QLabel(self.scrollAreaWidgetContents)
        self.label_11.setObjectName(u"label_11")
        sizePolicy4.setHeightForWidth(self.label_11.sizePolicy().hasHeightForWidth())
        self.label_11.setSizePolicy(sizePolicy4)
        self.label_11.setPixmap(QPixmap(u":/Login/NewsImage.png"))
        self.label_11.setScaledContents(True)

        self.horizontalLayout_17.addWidget(self.label_11)

        self.verticalLayout_16 = QVBoxLayout()
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.label_12 = QLabel(self.scrollAreaWidgetContents)
        self.label_12.setObjectName(u"label_12")

        self.verticalLayout_16.addWidget(self.label_12)

        self.label_13 = QLabel(self.scrollAreaWidgetContents)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setWordWrap(True)

        self.verticalLayout_16.addWidget(self.label_13)


        self.horizontalLayout_17.addLayout(self.verticalLayout_16)

        self.horizontalLayout_17.setStretch(0, 1)
        self.horizontalLayout_17.setStretch(1, 2)

        self.verticalLayout_13.addLayout(self.horizontalLayout_17)


        self.gridLayout_3.addLayout(self.verticalLayout_13, 0, 0, 1, 1)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)

        self.verticalLayout_12.addWidget(self.scrollArea)


        self.horizontalLayout_7.addLayout(self.verticalLayout_12)

        self.horizontalLayout_7.setStretch(0, 1)
        self.horizontalLayout_7.setStretch(3, 3)

        self.gridLayout_4.addLayout(self.horizontalLayout_7, 0, 0, 1, 1)

        self.stackedWidget.addWidget(self.News)
        self.Status = QWidget()
        self.Status.setObjectName(u"Status")
        sizePolicy3.setHeightForWidth(self.Status.sizePolicy().hasHeightForWidth())
        self.Status.setSizePolicy(sizePolicy3)
        self.horizontalLayout_10 = QHBoxLayout(self.Status)
        self.horizontalLayout_10.setSpacing(10)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.horizontalLayout_10.setContentsMargins(10, 10, 10, 10)
        self.LastNewsPanel_4 = QFrame(self.Status)
        self.LastNewsPanel_4.setObjectName(u"LastNewsPanel_4")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Maximum)
        sizePolicy6.setHorizontalStretch(0)
        sizePolicy6.setVerticalStretch(0)
        sizePolicy6.setHeightForWidth(self.LastNewsPanel_4.sizePolicy().hasHeightForWidth())
        self.LastNewsPanel_4.setSizePolicy(sizePolicy6)
        self.LastNewsPanel_4.setMinimumSize(QSize(0, 88))
        self.LastNewsPanel_4.setMaximumSize(QSize(10000, 10000))
        self.LastNewsPanel_4.setAutoFillBackground(False)
        self.LastNewsPanel_4.setStyleSheet(u"QFrame#LastNewsPanel_4{\n"
"	border-image: url(:/Login/vista-aerea-gran-centro-comercial.png);\n"
"}")
        self.LastNewsPanel_4.setFrameShape(QFrame.Shape.NoFrame)
        self.LastNewsPanel_4.setFrameShadow(QFrame.Shadow.Plain)
        self.gridLayout_6 = QGridLayout(self.LastNewsPanel_4)
        self.gridLayout_6.setSpacing(6)
        self.gridLayout_6.setObjectName(u"gridLayout_6")
        self.gridLayout_6.setContentsMargins(6, 6, 6, 6)
        self.verticalSpacer_26 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_26, 5, 5, 1, 1)

        self.horizontalLayout_30 = QHBoxLayout()
        self.horizontalLayout_30.setObjectName(u"horizontalLayout_30")
        self.Sector5 = QPushButton(self.LastNewsPanel_4)
        self.Sector5.setObjectName(u"Sector5")
        self.Sector5.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector5.setCheckable(False)
        self.Sector5.setChecked(False)

        self.horizontalLayout_30.addWidget(self.Sector5)

        self.check5 = QLabel(self.LastNewsPanel_4)
        self.check5.setObjectName(u"check5")
        sizePolicy4.setHeightForWidth(self.check5.sizePolicy().hasHeightForWidth())
        self.check5.setSizePolicy(sizePolicy4)
        self.check5.setMinimumSize(QSize(40, 10))
        self.check5.setStyleSheet(u"background-color: transparent;")
        self.check5.setPixmap(QPixmap(u":/Login/tick 1.png"))
        self.check5.setScaledContents(True)

        self.horizontalLayout_30.addWidget(self.check5)


        self.gridLayout_6.addLayout(self.horizontalLayout_30, 4, 5, 1, 1)

        self.horizontalLayout_28 = QHBoxLayout()
        self.horizontalLayout_28.setObjectName(u"horizontalLayout_28")
        self.Sector4 = QPushButton(self.LastNewsPanel_4)
        self.Sector4.setObjectName(u"Sector4")
        self.Sector4.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector4.setCheckable(False)
        self.Sector4.setChecked(False)

        self.horizontalLayout_28.addWidget(self.Sector4)

        self.check4 = QLabel(self.LastNewsPanel_4)
        self.check4.setObjectName(u"check4")
        sizePolicy4.setHeightForWidth(self.check4.sizePolicy().hasHeightForWidth())
        self.check4.setSizePolicy(sizePolicy4)
        self.check4.setMinimumSize(QSize(40, 10))
        self.check4.setStyleSheet(u"background-color: transparent;")
        self.check4.setPixmap(QPixmap(u":/Login/tick 1.png"))
        self.check4.setScaledContents(True)

        self.horizontalLayout_28.addWidget(self.check4)


        self.gridLayout_6.addLayout(self.horizontalLayout_28, 13, 5, 1, 1)

        self.horizontalLayout_14 = QHBoxLayout()
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.Sector1 = QPushButton(self.LastNewsPanel_4)
        self.Sector1.setObjectName(u"Sector1")
        self.Sector1.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector1.setCheckable(False)
        self.Sector1.setChecked(False)

        self.horizontalLayout_14.addWidget(self.Sector1)

        self.check1 = QLabel(self.LastNewsPanel_4)
        self.check1.setObjectName(u"check1")
        sizePolicy4.setHeightForWidth(self.check1.sizePolicy().hasHeightForWidth())
        self.check1.setSizePolicy(sizePolicy4)
        self.check1.setMinimumSize(QSize(40, 10))
        self.check1.setStyleSheet(u"background-color: transparent;")
        self.check1.setPixmap(QPixmap(u":/Login/tick 1.png"))
        self.check1.setScaledContents(True)

        self.horizontalLayout_14.addWidget(self.check1)


        self.gridLayout_6.addLayout(self.horizontalLayout_14, 2, 1, 1, 1)

        self.verticalSpacer_12 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_12, 0, 1, 1, 1)

        self.verticalSpacer_19 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_19, 15, 3, 1, 1)

        self.verticalSpacer_16 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_16, 10, 1, 1, 1)

        self.horizontalLayout_11 = QHBoxLayout()
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.Sector7 = QPushButton(self.LastNewsPanel_4)
        self.Sector7.setObjectName(u"Sector7")
        self.Sector7.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7.setCheckable(False)
        self.Sector7.setChecked(False)

        self.horizontalLayout_11.addWidget(self.Sector7)

        self.check7 = QLabel(self.LastNewsPanel_4)
        self.check7.setObjectName(u"check7")
        sizePolicy4.setHeightForWidth(self.check7.sizePolicy().hasHeightForWidth())
        self.check7.setSizePolicy(sizePolicy4)
        self.check7.setMinimumSize(QSize(40, 0))
        self.check7.setStyleSheet(u"background-color: transparent;")
        self.check7.setPixmap(QPixmap(u":/Login/Alert.png"))
        self.check7.setScaledContents(True)

        self.horizontalLayout_11.addWidget(self.check7)


        self.gridLayout_6.addLayout(self.horizontalLayout_11, 6, 7, 1, 1)

        self.horizontalSpacer_20 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_20, 8, 2, 1, 1)

        self.horizontalLayout_20 = QHBoxLayout()
        self.horizontalLayout_20.setObjectName(u"horizontalLayout_20")
        self.Sector2 = QPushButton(self.LastNewsPanel_4)
        self.Sector2.setObjectName(u"Sector2")
        self.Sector2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector2.setCheckable(False)
        self.Sector2.setChecked(False)

        self.horizontalLayout_20.addWidget(self.Sector2)

        self.check2 = QLabel(self.LastNewsPanel_4)
        self.check2.setObjectName(u"check2")
        sizePolicy4.setHeightForWidth(self.check2.sizePolicy().hasHeightForWidth())
        self.check2.setSizePolicy(sizePolicy4)
        self.check2.setMinimumSize(QSize(40, 10))
        self.check2.setStyleSheet(u"background-color: transparent;")
        self.check2.setPixmap(QPixmap(u":/Login/tick 1.png"))
        self.check2.setScaledContents(True)

        self.horizontalLayout_20.addWidget(self.check2)


        self.gridLayout_6.addLayout(self.horizontalLayout_20, 8, 3, 1, 1)

        self.horizontalSpacer_22 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_22, 6, 6, 1, 1)

        self.verticalSpacer_24 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_24, 11, 7, 1, 1)

        self.verticalSpacer_23 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_23, 14, 5, 1, 1)

        self.verticalSpacer_15 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_15, 2, 3, 1, 1)

        self.horizontalSpacer_21 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_21, 13, 4, 1, 1)

        self.verticalSpacer_20 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_20, 6, 1, 1, 1)

        self.verticalSpacer_21 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_21, 7, 7, 1, 1)

        self.horizontalLayout_29 = QHBoxLayout()
        self.horizontalLayout_29.setObjectName(u"horizontalLayout_29")
        self.Sector6 = QPushButton(self.LastNewsPanel_4)
        self.Sector6.setObjectName(u"Sector6")
        self.Sector6.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector6.setCheckable(False)
        self.Sector6.setChecked(False)

        self.horizontalLayout_29.addWidget(self.Sector6)

        self.check6 = QLabel(self.LastNewsPanel_4)
        self.check6.setObjectName(u"check6")
        sizePolicy4.setHeightForWidth(self.check6.sizePolicy().hasHeightForWidth())
        self.check6.setSizePolicy(sizePolicy4)
        self.check6.setMinimumSize(QSize(40, 10))
        self.check6.setStyleSheet(u"background-color: transparent;")
        self.check6.setPixmap(QPixmap(u":/Login/tick 1.png"))
        self.check6.setScaledContents(True)

        self.horizontalLayout_29.addWidget(self.check6)


        self.gridLayout_6.addLayout(self.horizontalLayout_29, 0, 5, 1, 1)

        self.horizontalLayout_19 = QHBoxLayout()
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.Sector3 = QPushButton(self.LastNewsPanel_4)
        self.Sector3.setObjectName(u"Sector3")
        self.Sector3.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector3.setCheckable(False)
        self.Sector3.setChecked(False)

        self.horizontalLayout_19.addWidget(self.Sector3)

        self.check3 = QLabel(self.LastNewsPanel_4)
        self.check3.setObjectName(u"check3")
        sizePolicy4.setHeightForWidth(self.check3.sizePolicy().hasHeightForWidth())
        self.check3.setSizePolicy(sizePolicy4)
        self.check3.setMinimumSize(QSize(40, 10))
        self.check3.setStyleSheet(u"background-color: transparent;")
        self.check3.setPixmap(QPixmap(u":/Login/tick 1.png"))
        self.check3.setScaledContents(True)

        self.horizontalLayout_19.addWidget(self.check3)


        self.gridLayout_6.addLayout(self.horizontalLayout_19, 15, 1, 1, 1)

        self.horizontalLayout_16 = QHBoxLayout()
        self.horizontalLayout_16.setObjectName(u"horizontalLayout_16")
        self.Sector8 = QPushButton(self.LastNewsPanel_4)
        self.Sector8.setObjectName(u"Sector8")
        self.Sector8.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector8.setCheckable(False)
        self.Sector8.setChecked(False)

        self.horizontalLayout_16.addWidget(self.Sector8)

        self.check8 = QLabel(self.LastNewsPanel_4)
        self.check8.setObjectName(u"check8")
        sizePolicy4.setHeightForWidth(self.check8.sizePolicy().hasHeightForWidth())
        self.check8.setSizePolicy(sizePolicy4)
        self.check8.setMinimumSize(QSize(40, 0))
        self.check8.setStyleSheet(u"background-color: transparent;")
        self.check8.setPixmap(QPixmap(u":/Login/Alert.png"))
        self.check8.setScaledContents(True)

        self.horizontalLayout_16.addWidget(self.check8)


        self.gridLayout_6.addLayout(self.horizontalLayout_16, 10, 7, 1, 1)

        self.verticalSpacer_13 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_13, 4, 1, 1, 1)

        self.horizontalSpacer_16 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_16, 4, 0, 1, 1)

        self.verticalSpacer_11 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_11, 13, 1, 1, 1)

        self.verticalSpacer_17 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_17, 12, 1, 1, 1)

        self.horizontalSpacer_19 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_19, 6, 8, 1, 1)

        self.verticalSpacer_25 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_25, 9, 3, 1, 1)

        self.verticalSpacer_14 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_14, 8, 1, 1, 1)

        self.verticalSpacer_22 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_22, 16, 1, 1, 1)

        self.verticalSpacer_18 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_18, 3, 3, 1, 1)

        self.verticalSpacer_27 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_27, 1, 5, 1, 1)


        self.horizontalLayout_10.addWidget(self.LastNewsPanel_4)

        self.frame_4 = QFrame(self.Status)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_4.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_15 = QVBoxLayout(self.frame_4)
        self.verticalLayout_15.setSpacing(6)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.horizontalLayout_13 = QHBoxLayout()
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.horizontalSpacer_11 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_13.addItem(self.horizontalSpacer_11)

        self.TitleLastNews = QLabel(self.frame_4)
        self.TitleLastNews.setObjectName(u"TitleLastNews")
        self.TitleLastNews.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.TitleLastNews.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_13.addWidget(self.TitleLastNews)

        self.horizontalSpacer_12 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_13.addItem(self.horizontalSpacer_12)


        self.verticalLayout_15.addLayout(self.horizontalLayout_13)

        self.line_7 = QFrame(self.frame_4)
        self.line_7.setObjectName(u"line_7")
        self.line_7.setAutoFillBackground(False)
        self.line_7.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_7.setFrameShadow(QFrame.Shadow.Plain)
        self.line_7.setLineWidth(2)
        self.line_7.setMidLineWidth(2)
        self.line_7.setFrameShape(QFrame.Shape.HLine)

        self.verticalLayout_15.addWidget(self.line_7)

        self.TextoLastNews = QLabel(self.frame_4)
        self.TextoLastNews.setObjectName(u"TextoLastNews")
        self.TextoLastNews.setFont(font1)
        self.TextoLastNews.setStyleSheet(u"color: black;\n"
"text-align: center;\n"
"")
        self.TextoLastNews.setFrameShadow(QFrame.Shadow.Plain)
        self.TextoLastNews.setTextFormat(Qt.TextFormat.PlainText)
        self.TextoLastNews.setScaledContents(False)
        self.TextoLastNews.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)
        self.TextoLastNews.setWordWrap(True)

        self.verticalLayout_15.addWidget(self.TextoLastNews)

        self.verticalLayout_15.setStretch(0, 1)
        self.verticalLayout_15.setStretch(1, 1)
        self.verticalLayout_15.setStretch(2, 5)

        self.horizontalLayout_10.addWidget(self.frame_4)

        self.horizontalLayout_10.setStretch(0, 4)
        self.horizontalLayout_10.setStretch(1, 1)
        self.stackedWidget.addWidget(self.Status)
        self.Sectors = QWidget()
        self.Sectors.setObjectName(u"Sectors")
        self.horizontalLayout_69 = QHBoxLayout(self.Sectors)
        self.horizontalLayout_69.setObjectName(u"horizontalLayout_69")
        self.horizontalLayout_68 = QHBoxLayout()
        self.horizontalLayout_68.setObjectName(u"horizontalLayout_68")
        self.verticalLayout_26 = QVBoxLayout()
        self.verticalLayout_26.setObjectName(u"verticalLayout_26")
        self.Sector1_2 = QPushButton(self.Sectors)
        self.Sector1_2.setObjectName(u"Sector1_2")
        self.Sector1_2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector1_2.setCheckable(False)
        self.Sector1_2.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector1_2)

        self.Sector2_2 = QPushButton(self.Sectors)
        self.Sector2_2.setObjectName(u"Sector2_2")
        self.Sector2_2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector2_2.setCheckable(False)
        self.Sector2_2.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector2_2)

        self.Sector3_2 = QPushButton(self.Sectors)
        self.Sector3_2.setObjectName(u"Sector3_2")
        self.Sector3_2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector3_2.setCheckable(False)
        self.Sector3_2.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector3_2)

        self.Sector4_2 = QPushButton(self.Sectors)
        self.Sector4_2.setObjectName(u"Sector4_2")
        self.Sector4_2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector4_2.setCheckable(False)
        self.Sector4_2.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector4_2)

        self.Sector5_2 = QPushButton(self.Sectors)
        self.Sector5_2.setObjectName(u"Sector5_2")
        self.Sector5_2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector5_2.setCheckable(False)
        self.Sector5_2.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector5_2)

        self.Sector6_2 = QPushButton(self.Sectors)
        self.Sector6_2.setObjectName(u"Sector6_2")
        self.Sector6_2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector6_2.setCheckable(False)
        self.Sector6_2.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector6_2)

        self.Sector7_7 = QPushButton(self.Sectors)
        self.Sector7_7.setObjectName(u"Sector7_7")
        self.Sector7_7.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_7.setCheckable(False)
        self.Sector7_7.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector7_7)

        self.Sector8_2 = QPushButton(self.Sectors)
        self.Sector8_2.setObjectName(u"Sector8_2")
        self.Sector8_2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector8_2.setCheckable(False)
        self.Sector8_2.setChecked(False)

        self.verticalLayout_26.addWidget(self.Sector8_2)


        self.horizontalLayout_68.addLayout(self.verticalLayout_26)

        self.gridLayout_7 = QGridLayout()
        self.gridLayout_7.setObjectName(u"gridLayout_7")
        self.verticalSpacer_7 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_7.addItem(self.verticalSpacer_7, 3, 1, 1, 1)

        self.verticalSpacer_8 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_7.addItem(self.verticalSpacer_8, 1, 1, 1, 1)

        self.horizontalSpacer_13 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_7.addItem(self.horizontalSpacer_13, 2, 0, 1, 1)

        self.frame_7 = QFrame(self.Sectors)
        self.frame_7.setObjectName(u"frame_7")
        self.frame_7.setStyleSheet(u"QFrame#frame_7{\n"
"	\n"
"	border-image: url(:/Login/Temperature_panel.png);\n"
"}")
        self.frame_7.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_7.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_9 = QGridLayout(self.frame_7)
        self.gridLayout_9.setSpacing(0)
        self.gridLayout_9.setObjectName(u"gridLayout_9")
        self.gridLayout_9.setContentsMargins(0, 0, 0, 0)
        self.verticalSpacer_10 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_10, 0, 2, 1, 1)

        self.verticalSpacer_9 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_9, 2, 2, 1, 1)

        self.horizontalSpacer_15 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_9.addItem(self.horizontalSpacer_15, 1, 3, 1, 1)

        self.horizontalSpacer_14 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_9.addItem(self.horizontalSpacer_14, 1, 0, 1, 1)

        self.widget_11 = TermostatoWidget(self.frame_7)
        self.widget_11.setObjectName(u"widget_11")
        self.widget_11.setStyleSheet(u"#widget_11{\n"
"	border-image: url(:/Login/InnerTemp.png);\n"
"	background-color: rgba(255, 255, 255, 0);\n"
"}")

        self.gridLayout_9.addWidget(self.widget_11, 1, 2, 1, 1)

        self.gridLayout_9.setRowStretch(0, 1)
        self.gridLayout_9.setRowStretch(1, 5)
        self.gridLayout_9.setRowStretch(2, 1)
        self.gridLayout_9.setColumnStretch(0, 1)
        self.gridLayout_9.setColumnStretch(2, 5)
        self.gridLayout_9.setColumnStretch(3, 1)

        self.gridLayout_7.addWidget(self.frame_7, 2, 1, 1, 1)

        self.frame_8 = QFrame(self.Sectors)
        self.frame_8.setObjectName(u"frame_8")
        self.frame_8.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_8.setFrameShadow(QFrame.Shadow.Raised)

        self.gridLayout_7.addWidget(self.frame_8, 0, 1, 1, 1)

        self.frame_9 = QFrame(self.Sectors)
        self.frame_9.setObjectName(u"frame_9")
        self.frame_9.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_9.setFrameShadow(QFrame.Shadow.Raised)

        self.gridLayout_7.addWidget(self.frame_9, 0, 2, 1, 1)

        self.frame_10 = QFrame(self.Sectors)
        self.frame_10.setObjectName(u"frame_10")
        self.frame_10.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_10.setFrameShadow(QFrame.Shadow.Raised)

        self.gridLayout_7.addWidget(self.frame_10, 0, 3, 1, 1)

        self.frame_6 = QFrame(self.Sectors)
        self.frame_6.setObjectName(u"frame_6")
        self.frame_6.setStyleSheet(u"QFrame{\n"
"	border-radius: 30px;\n"
"	background-color: rgb(181, 231, 240);\n"
"}")
        self.frame_6.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_6.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_8 = QGridLayout(self.frame_6)
        self.gridLayout_8.setObjectName(u"gridLayout_8")
        self.label_17 = QLabel(self.frame_6)
        self.label_17.setObjectName(u"label_17")
        sizePolicy4.setHeightForWidth(self.label_17.sizePolicy().hasHeightForWidth())
        self.label_17.setSizePolicy(sizePolicy4)

        self.gridLayout_8.addWidget(self.label_17, 0, 0, 1, 1)


        self.gridLayout_7.addWidget(self.frame_6, 1, 2, 2, 2)

        self.gridLayout_7.setRowStretch(0, 1)
        self.gridLayout_7.setRowStretch(2, 1)
        self.gridLayout_7.setColumnStretch(1, 1)
        self.gridLayout_7.setColumnStretch(2, 1)
        self.gridLayout_7.setColumnStretch(3, 1)

        self.horizontalLayout_68.addLayout(self.gridLayout_7)

        self.horizontalLayout_68.setStretch(0, 1)
        self.horizontalLayout_68.setStretch(1, 10)

        self.horizontalLayout_69.addLayout(self.horizontalLayout_68)

        self.stackedWidget.addWidget(self.Sectors)
        self.Profile = QWidget()
        self.Profile.setObjectName(u"Profile")
        self.horizontalLayout_67 = QHBoxLayout(self.Profile)
        self.horizontalLayout_67.setObjectName(u"horizontalLayout_67")
        self.LastNewsPanel_5 = QFrame(self.Profile)
        self.LastNewsPanel_5.setObjectName(u"LastNewsPanel_5")
        self.LastNewsPanel_5.setFrameShape(QFrame.Shape.NoFrame)
        self.LastNewsPanel_5.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_19 = QVBoxLayout(self.LastNewsPanel_5)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.scrollArea_2 = QScrollArea(self.LastNewsPanel_5)
        self.scrollArea_2.setObjectName(u"scrollArea_2")
        self.scrollArea_2.setStyleSheet(u"")
        self.scrollArea_2.setFrameShape(QFrame.Shape.NoFrame)
        self.scrollArea_2.setFrameShadow(QFrame.Shadow.Plain)
        self.scrollArea_2.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scrollArea_2.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scrollArea_2.setWidgetResizable(True)
        self.scrollAreaWidgetContents_2 = QWidget()
        self.scrollAreaWidgetContents_2.setObjectName(u"scrollAreaWidgetContents_2")
        self.scrollAreaWidgetContents_2.setGeometry(QRect(0, 0, 100, 500))
        self.scrollAreaWidgetContents_2.setMinimumSize(QSize(100, 500))
        self.scrollAreaWidgetContents_2.setStyleSheet(u"")
        self.verticalLayout_24 = QVBoxLayout(self.scrollAreaWidgetContents_2)
        self.verticalLayout_24.setObjectName(u"verticalLayout_24")
        self.Title_4 = QLabel(self.scrollAreaWidgetContents_2)
        self.Title_4.setObjectName(u"Title_4")
        self.Title_4.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_4.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_24.addWidget(self.Title_4)

        self.Sector7_2 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_2.setObjectName(u"Sector7_2")
        self.Sector7_2.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_2.setCheckable(False)
        self.Sector7_2.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_2)

        self.verticalSpacer_5 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_24.addItem(self.verticalSpacer_5)

        self.Title_5 = QLabel(self.scrollAreaWidgetContents_2)
        self.Title_5.setObjectName(u"Title_5")
        self.Title_5.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_5.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_24.addWidget(self.Title_5)

        self.Sector7_4 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_4.setObjectName(u"Sector7_4")
        self.Sector7_4.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_4.setCheckable(False)
        self.Sector7_4.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_4)

        self.Sector7_3 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_3.setObjectName(u"Sector7_3")
        self.Sector7_3.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_3.setCheckable(False)
        self.Sector7_3.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_3)

        self.Sector7_5 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_5.setObjectName(u"Sector7_5")
        self.Sector7_5.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_5.setCheckable(False)
        self.Sector7_5.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_5)

        self.verticalSpacer_6 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_24.addItem(self.verticalSpacer_6)

        self.Title_6 = QLabel(self.scrollAreaWidgetContents_2)
        self.Title_6.setObjectName(u"Title_6")
        self.Title_6.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_6.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_24.addWidget(self.Title_6)

        self.Sector7_6 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_6.setObjectName(u"Sector7_6")
        self.Sector7_6.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_6.setCheckable(False)
        self.Sector7_6.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_6)

        self.Sector7_8 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_8.setObjectName(u"Sector7_8")
        self.Sector7_8.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_8.setCheckable(False)
        self.Sector7_8.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_8)

        self.verticalLayout_24.setStretch(0, 1)
        self.verticalLayout_24.setStretch(1, 1)
        self.verticalLayout_24.setStretch(3, 1)
        self.verticalLayout_24.setStretch(4, 1)
        self.verticalLayout_24.setStretch(5, 1)
        self.verticalLayout_24.setStretch(6, 1)
        self.verticalLayout_24.setStretch(8, 1)
        self.verticalLayout_24.setStretch(9, 1)
        self.verticalLayout_24.setStretch(10, 1)
        self.scrollArea_2.setWidget(self.scrollAreaWidgetContents_2)

        self.verticalLayout_19.addWidget(self.scrollArea_2)


        self.horizontalLayout_67.addWidget(self.LastNewsPanel_5)

        self.frame_5 = QFrame(self.Profile)
        self.frame_5.setObjectName(u"frame_5")
        self.frame_5.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_5.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_25 = QVBoxLayout(self.frame_5)
        self.verticalLayout_25.setObjectName(u"verticalLayout_25")

        self.horizontalLayout_67.addWidget(self.frame_5)

        self.horizontalLayout_67.setStretch(0, 1)
        self.horizontalLayout_67.setStretch(1, 3)
        self.stackedWidget.addWidget(self.Profile)

        self.verticalLayout.addWidget(self.stackedWidget)


        self.horizontalLayout.addLayout(self.verticalLayout)

        self.horizontalLayout.setStretch(0, 3)

        self.verticalLayout_3.addLayout(self.horizontalLayout)

        self.verticalLayout_3.setStretch(0, 1)
        self.verticalLayout_3.setStretch(1, 5)

        self.gridLayout.addLayout(self.verticalLayout_3, 0, 0, 1, 1)

        UserWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(UserWindow)

        self.pushButton.setDefault(False)
        self.pushButton_2.setDefault(False)
        self.pushButton_3.setDefault(False)
        self.pushButton_4.setDefault(False)
        self.pushButton_5.setDefault(False)
        self.stackedWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(UserWindow)
    # setupUi

    def retranslateUi(self, UserWindow):
        UserWindow.setWindowTitle(QCoreApplication.translate("UserWindow", u"MainWindow", None))
        self.label.setText("")
        self.pushButton.setText(QCoreApplication.translate("UserWindow", u"Home", None))
        self.pushButton_2.setText(QCoreApplication.translate("UserWindow", u"News", None))
        self.pushButton_3.setText(QCoreApplication.translate("UserWindow", u"Status", None))
        self.pushButton_4.setText(QCoreApplication.translate("UserWindow", u"Sectors", None))
        self.pushButton_5.setText(QCoreApplication.translate("UserWindow", u"Profile", None))
        self.Title.setText(QCoreApplication.translate("UserWindow", u" Last News", None))
        self.label_3.setText("")
        self.New.setText(QCoreApplication.translate("UserWindow", u"Lorem ipsum dolor sit amet consectetur adipiscing elit sagittis iaculis nascetur, vestibulum convallis arcu varius ullamcorper accumsan a urna sodales, rutrum odio magna consequat dapibus mauris leo proin posuere. Pharetra aptent luctus justo quam in fusce morbi ad himenaeos, hendrerit conubia fames ultrices nulla vitae suspendisse ante malesuada dis, enim cubilia molestie purus nisi mattis ut mi. Lacinia conubia urna penatibus ridiculus quisque et scelerisque, natoque condimentum dapibus fermentum montes fringilla facilisis, neque inceptos tempor euismod turpis nascetur.", None))
        self.label_18.setText(QCoreApplication.translate("UserWindow", u"DATA", None))
        self.Title_2.setText(QCoreApplication.translate("UserWindow", u" Last News", None))
        self.label_4.setText("")
        self.New_2.setText(QCoreApplication.translate("UserWindow", u"Lorem ipsum dolor sit amet consectetur adipiscing elit sagittis iaculis nascetur, vestibulum convallis arcu varius ullamcorper accumsan a urna sodales, rutrum odio magna consequat dapibus mauris leo proin posuere. Pharetra aptent luctus justo quam in fusce morbi ad himenaeos, hendrerit conubia fames ultrices nulla vitae suspendisse ante malesuada dis, enim cubilia molestie purus nisi mattis ut mi. Lacinia conubia urna penatibus ridiculus quisque et scelerisque, natoque condimentum dapibus fermentum montes fringilla facilisis, neque inceptos tempor euismod turpis nascetur.", None))
        self.Title_3.setText(QCoreApplication.translate("UserWindow", u"All News", None))
        self.label_5.setText("")
        self.label_7.setText(QCoreApplication.translate("UserWindow", u"TextLabel", None))
        self.label_6.setText(QCoreApplication.translate("UserWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut leo euismod, sagittis nibh nec, congue enim. Mauris sagittis maximus diam a lacinia. Curabitur at ultrices massa, ut tempor metus. Nam non euismod ligula. Nam euismod rhoncus ornare. Morbi molestie vehicula turpis, quis aliquam leo finibus eu. Phasellus gravida, elit non posuere mattis, ipsum diam accumsan libero, sit amet tincidunt leo mauris quis arcu.", None))
        self.label_14.setText("")
        self.label_15.setText(QCoreApplication.translate("UserWindow", u"TextLabel", None))
        self.label_16.setText(QCoreApplication.translate("UserWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut leo euismod, sagittis nibh nec, congue enim. Mauris sagittis maximus diam a lacinia. Curabitur at ultrices massa, ut tempor metus. Nam non euismod ligula. Nam euismod rhoncus ornare. Morbi molestie vehicula turpis, quis aliquam leo finibus eu. Phasellus gravida, elit non posuere mattis, ipsum diam accumsan libero, sit amet tincidunt leo mauris quis arcu.", None))
        self.label_23.setText("")
        self.label_24.setText(QCoreApplication.translate("UserWindow", u"TextLabel", None))
        self.label_25.setText(QCoreApplication.translate("UserWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut leo euismod, sagittis nibh nec, congue enim. Mauris sagittis maximus diam a lacinia. Curabitur at ultrices massa, ut tempor metus. Nam non euismod ligula. Nam euismod rhoncus ornare. Morbi molestie vehicula turpis, quis aliquam leo finibus eu. Phasellus gravida, elit non posuere mattis, ipsum diam accumsan libero, sit amet tincidunt leo mauris quis arcu.", None))
        self.label_26.setText("")
        self.label_27.setText(QCoreApplication.translate("UserWindow", u"TextLabel", None))
        self.label_28.setText(QCoreApplication.translate("UserWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut leo euismod, sagittis nibh nec, congue enim. Mauris sagittis maximus diam a lacinia. Curabitur at ultrices massa, ut tempor metus. Nam non euismod ligula. Nam euismod rhoncus ornare. Morbi molestie vehicula turpis, quis aliquam leo finibus eu. Phasellus gravida, elit non posuere mattis, ipsum diam accumsan libero, sit amet tincidunt leo mauris quis arcu.", None))
        self.label_29.setText("")
        self.label_30.setText(QCoreApplication.translate("UserWindow", u"TextLabel", None))
        self.label_31.setText(QCoreApplication.translate("UserWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut leo euismod, sagittis nibh nec, congue enim. Mauris sagittis maximus diam a lacinia. Curabitur at ultrices massa, ut tempor metus. Nam non euismod ligula. Nam euismod rhoncus ornare. Morbi molestie vehicula turpis, quis aliquam leo finibus eu. Phasellus gravida, elit non posuere mattis, ipsum diam accumsan libero, sit amet tincidunt leo mauris quis arcu.", None))
        self.label_32.setText("")
        self.label_33.setText(QCoreApplication.translate("UserWindow", u"TextLabel", None))
        self.label_34.setText(QCoreApplication.translate("UserWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut leo euismod, sagittis nibh nec, congue enim. Mauris sagittis maximus diam a lacinia. Curabitur at ultrices massa, ut tempor metus. Nam non euismod ligula. Nam euismod rhoncus ornare. Morbi molestie vehicula turpis, quis aliquam leo finibus eu. Phasellus gravida, elit non posuere mattis, ipsum diam accumsan libero, sit amet tincidunt leo mauris quis arcu.", None))
        self.label_11.setText("")
        self.label_12.setText(QCoreApplication.translate("UserWindow", u"TextLabel", None))
        self.label_13.setText(QCoreApplication.translate("UserWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce ut leo euismod, sagittis nibh nec, congue enim. Mauris sagittis maximus diam a lacinia. Curabitur at ultrices massa, ut tempor metus. Nam non euismod ligula. Nam euismod rhoncus ornare. Morbi molestie vehicula turpis, quis aliquam leo finibus eu. Phasellus gravida, elit non posuere mattis, ipsum diam accumsan libero, sit amet tincidunt leo mauris quis arcu.", None))
        self.Sector5.setText(QCoreApplication.translate("UserWindow", u"Sector 5:", None))
        self.check5.setText("")
        self.Sector4.setText(QCoreApplication.translate("UserWindow", u"Sector 4:", None))
        self.check4.setText("")
        self.Sector1.setText(QCoreApplication.translate("UserWindow", u"Sector 1:", None))
        self.check1.setText("")
        self.Sector7.setText(QCoreApplication.translate("UserWindow", u"Sector 7:", None))
        self.check7.setText("")
        self.Sector2.setText(QCoreApplication.translate("UserWindow", u"Sector 2:", None))
        self.check2.setText("")
        self.Sector6.setText(QCoreApplication.translate("UserWindow", u"Sector 6:", None))
        self.check6.setText("")
        self.Sector3.setText(QCoreApplication.translate("UserWindow", u"Sector 3:", None))
        self.check3.setText("")
        self.Sector8.setText(QCoreApplication.translate("UserWindow", u"Sector 8:", None))
        self.check8.setText("")
        self.TitleLastNews.setText(QCoreApplication.translate("UserWindow", u"Information", None))
        self.TextoLastNews.setText(QCoreApplication.translate("UserWindow", u"Lorem ipsum dolor sit amet consectetur adipiscing elit sagittis iaculis nascetur, vestibulum convallis arcu varius ullamcorper accumsan a urna sodales, rutrum odio magna consequat dapibus mauris leo proin posuere. Pharetra aptent luctus justo quam in fusce morbi ad himenaeos, hendrerit conubia fames ultrices nulla vitae suspendisse ante malesuada dis, enim cubilia molestie purus nisi mattis ut mi. Lacinia conubia urna penatibus ridiculus quisque et scelerisque, natoque condimentum dapibus fermentum montes fringilla facilisis, neque inceptos tempor euismod turpis nascetur.", None))
        self.Sector1_2.setText(QCoreApplication.translate("UserWindow", u"Sector 1:", None))
        self.Sector2_2.setText(QCoreApplication.translate("UserWindow", u"Sector 2:", None))
        self.Sector3_2.setText(QCoreApplication.translate("UserWindow", u"Sector 3:", None))
        self.Sector4_2.setText(QCoreApplication.translate("UserWindow", u"Sector 4:", None))
        self.Sector5_2.setText(QCoreApplication.translate("UserWindow", u"Sector 5:", None))
        self.Sector6_2.setText(QCoreApplication.translate("UserWindow", u"Sector 6:", None))
        self.Sector7_7.setText(QCoreApplication.translate("UserWindow", u"Sector 7:", None))
        self.Sector8_2.setText(QCoreApplication.translate("UserWindow", u"Sector 8:", None))
        self.label_17.setText(QCoreApplication.translate("UserWindow", u"DATA", None))
        self.Title_4.setText(QCoreApplication.translate("UserWindow", u"Profile", None))
        self.Sector7_2.setText(QCoreApplication.translate("UserWindow", u"Edit Profile", None))
        self.Title_5.setText(QCoreApplication.translate("UserWindow", u"Control & Security", None))
        self.Sector7_4.setText(QCoreApplication.translate("UserWindow", u"Privacy", None))
        self.Sector7_3.setText(QCoreApplication.translate("UserWindow", u"Subscriptions", None))
        self.Sector7_5.setText(QCoreApplication.translate("UserWindow", u"Accesibility", None))
        self.Title_6.setText(QCoreApplication.translate("UserWindow", u"App Settings", None))
        self.Sector7_6.setText(QCoreApplication.translate("UserWindow", u"Language", None))
        self.Sector7_8.setText(QCoreApplication.translate("UserWindow", u"Notifications", None))
    # retranslateUi

