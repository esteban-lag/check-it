# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'UserAdmin.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractScrollArea, QApplication, QFrame, QGridLayout,
    QHBoxLayout, QLabel, QLayout, QLineEdit,
    QMainWindow, QPlainTextEdit, QPushButton, QScrollArea,
    QSizePolicy, QSpacerItem, QStackedWidget, QVBoxLayout,
    QWidget)

from componentes import (CalidadAireWidget, SensorLuzWidget, SensorRuidoWidget, TermostatoWidget)
import Recursos_rc

class Ui_AdministratorWindow(object):
    def setupUi(self, AdministratorWindow):
        if not AdministratorWindow.objectName():
            AdministratorWindow.setObjectName(u"AdministratorWindow")
        AdministratorWindow.resize(842, 609)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(AdministratorWindow.sizePolicy().hasHeightForWidth())
        AdministratorWindow.setSizePolicy(sizePolicy)
        self.centralwidget = QWidget(AdministratorWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(0, 0, 842, 609))
        self.frame.setStyleSheet(u"background-color: white")
        self.frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame.setFrameShadow(QFrame.Shadow.Plain)
        self.gridLayout = QGridLayout(self.frame)
        self.gridLayout.setSpacing(0)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_3 = QVBoxLayout()
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setSizeConstraint(QLayout.SizeConstraint.SetDefaultConstraint)
        self.frame_2 = QFrame(self.frame)
        self.frame_2.setObjectName(u"frame_2")
        sizePolicy.setHeightForWidth(self.frame_2.sizePolicy().hasHeightForWidth())
        self.frame_2.setSizePolicy(sizePolicy)
        self.frame_2.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_5 = QGridLayout(self.frame_2)
        self.gridLayout_5.setSpacing(0)
        self.gridLayout_5.setObjectName(u"gridLayout_5")
        self.gridLayout_5.setContentsMargins(0, 0, 0, 0)
        self.frame_3 = QFrame(self.frame_2)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setAutoFillBackground(False)
        self.frame_3.setStyleSheet(u".QFrame {\n"
"    border-image: url(:/login/Topcornerusers.png);\n"
"}")
        self.frame_3.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.frame_3)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(2, 2, 2, 2)
        self.label = QLabel(self.frame_3)
        self.label.setObjectName(u"label")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.label.sizePolicy().hasHeightForWidth())
        self.label.setSizePolicy(sizePolicy1)
        self.label.setMinimumSize(QSize(80, 80))
        self.label.setMaximumSize(QSize(150, 150))
        self.label.setSizeIncrement(QSize(1, 1))
        self.label.setAutoFillBackground(False)
        self.label.setStyleSheet(u"QLabel{\n"
"background-color: transparent; \n"
"    border: none; /* A veces el borde a\u00f1ade color */\n"
"}")
        self.label.setPixmap(QPixmap(u":/login/Check-it 1.png"))
        self.label.setScaledContents(True)

        self.horizontalLayout_2.addWidget(self.label)

        self.horizontalSpacer_3 = QSpacerItem(100, 20, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_3)

        self.pushButton = QPushButton(self.frame_3)
        self.pushButton.setObjectName(u"pushButton")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.pushButton.sizePolicy().hasHeightForWidth())
        self.pushButton.setSizePolicy(sizePolicy2)
        font = QFont()
        font.setPointSize(12)
        font.setBold(True)
        self.pushButton.setFont(font)
        self.pushButton.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton.setCheckable(False)
        self.pushButton.setChecked(False)

        self.horizontalLayout_2.addWidget(self.pushButton)

        self.horizontalSpacer_9 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_9)

        self.pushButton_24 = QPushButton(self.frame_3)
        self.pushButton_24.setObjectName(u"pushButton_24")
        sizePolicy2.setHeightForWidth(self.pushButton_24.sizePolicy().hasHeightForWidth())
        self.pushButton_24.setSizePolicy(sizePolicy2)
        self.pushButton_24.setFont(font)
        self.pushButton_24.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_24.setCheckable(False)
        self.pushButton_24.setChecked(False)

        self.horizontalLayout_2.addWidget(self.pushButton_24)

        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_5)

        self.pushButton_2 = QPushButton(self.frame_3)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setFont(font)
        self.pushButton_2.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_2.setCheckable(False)

        self.horizontalLayout_2.addWidget(self.pushButton_2)

        self.horizontalSpacer_6 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_6)

        self.pushButton_3 = QPushButton(self.frame_3)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setFont(font)
        self.pushButton_3.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_3.setCheckable(False)

        self.horizontalLayout_2.addWidget(self.pushButton_3)

        self.horizontalSpacer_7 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_7)

        self.pushButton_4 = QPushButton(self.frame_3)
        self.pushButton_4.setObjectName(u"pushButton_4")
        self.pushButton_4.setFont(font)
        self.pushButton_4.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_4.setCheckable(False)

        self.horizontalLayout_2.addWidget(self.pushButton_4)

        self.horizontalSpacer_8 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_8)

        self.pushButton_5 = QPushButton(self.frame_3)
        self.pushButton_5.setObjectName(u"pushButton_5")
        self.pushButton_5.setFont(font)
        self.pushButton_5.setStyleSheet(u"QPushButton {\n"
"    background: transparent;\n"
"    border: none;\n"
"    color: rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_5.setCheckable(False)

        self.horizontalLayout_2.addWidget(self.pushButton_5)

        self.horizontalSpacer_4 = QSpacerItem(185, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_4)

        self.horizontalLayout_2.setStretch(0, 1)
        self.horizontalLayout_2.setStretch(3, 1)
        self.horizontalLayout_2.setStretch(5, 1)
        self.horizontalLayout_2.setStretch(7, 1)
        self.horizontalLayout_2.setStretch(9, 1)
        self.horizontalLayout_2.setStretch(11, 1)
        self.horizontalLayout_2.setStretch(13, 1)

        self.gridLayout_5.addWidget(self.frame_3, 0, 0, 2, 1)

        self.gridLayout_5.setRowStretch(0, 2)

        self.verticalLayout_3.addWidget(self.frame_2)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.stackedWidget = QStackedWidget(self.frame)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.Home = QWidget()
        self.Home.setObjectName(u"Home")
        self.gridLayout_2 = QGridLayout(self.Home)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.LastNewsPanel = QFrame(self.Home)
        self.LastNewsPanel.setObjectName(u"LastNewsPanel")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.LastNewsPanel.sizePolicy().hasHeightForWidth())
        self.LastNewsPanel.setSizePolicy(sizePolicy3)
        self.LastNewsPanel.setFrameShape(QFrame.Shape.StyledPanel)
        self.LastNewsPanel.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_5 = QVBoxLayout(self.LastNewsPanel)
        self.verticalLayout_5.setSpacing(5)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer_2)

        self.Title = QLabel(self.LastNewsPanel)
        self.Title.setObjectName(u"Title")
        self.Title.setStyleSheet(u"color: red;\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid red;")
        self.Title.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_3.addWidget(self.Title)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer)


        self.verticalLayout_5.addLayout(self.horizontalLayout_3)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(25, -1, 25, -1)
        self.line = QFrame(self.LastNewsPanel)
        self.line.setObjectName(u"line")
        self.line.setAutoFillBackground(False)
        self.line.setStyleSheet(u"color: red;\n"
"")
        self.line.setFrameShadow(QFrame.Shadow.Plain)
        self.line.setLineWidth(2)
        self.line.setMidLineWidth(2)
        self.line.setFrameShape(QFrame.Shape.HLine)

        self.horizontalLayout_4.addWidget(self.line)


        self.verticalLayout_5.addLayout(self.horizontalLayout_4)

        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.horizontalLayout_6.setContentsMargins(-1, 0, -1, -1)
        self.New_3 = QLabel(self.LastNewsPanel)
        self.New_3.setObjectName(u"New_3")
        font1 = QFont()
        font1.setPointSize(7)
        self.New_3.setFont(font1)
        self.New_3.setStyleSheet(u"color: black;")
        self.New_3.setFrameShadow(QFrame.Shadow.Plain)
        self.New_3.setTextFormat(Qt.TextFormat.PlainText)
        self.New_3.setScaledContents(False)
        self.New_3.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.New_3.setWordWrap(True)

        self.horizontalLayout_6.addWidget(self.New_3)


        self.verticalLayout_5.addLayout(self.horizontalLayout_6)

        self.horizontalLayout_15 = QHBoxLayout()
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.horizontalLayout_15.setContentsMargins(-1, 0, -1, -1)
        self.pushButton_7 = QPushButton(self.LastNewsPanel)
        self.pushButton_7.setObjectName(u"pushButton_7")
        sizePolicy2.setHeightForWidth(self.pushButton_7.sizePolicy().hasHeightForWidth())
        self.pushButton_7.setSizePolicy(sizePolicy2)
        font2 = QFont()
        font2.setPointSize(10)
        font2.setBold(True)
        self.pushButton_7.setFont(font2)
        self.pushButton_7.setStyleSheet(u"QPushButton {\n"
"background-color: #56E765; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_7.setCheckable(False)
        self.pushButton_7.setChecked(False)

        self.horizontalLayout_15.addWidget(self.pushButton_7)

        self.pushButton_6 = QPushButton(self.LastNewsPanel)
        self.pushButton_6.setObjectName(u"pushButton_6")
        sizePolicy2.setHeightForWidth(self.pushButton_6.sizePolicy().hasHeightForWidth())
        self.pushButton_6.setSizePolicy(sizePolicy2)
        self.pushButton_6.setFont(font2)
        self.pushButton_6.setStyleSheet(u"QPushButton {\n"
"background-color: #DC3434; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_6.setCheckable(False)
        self.pushButton_6.setChecked(False)

        self.horizontalLayout_15.addWidget(self.pushButton_6)


        self.verticalLayout_5.addLayout(self.horizontalLayout_15)

        self.verticalSpacer_28 = QSpacerItem(10, 10, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.MinimumExpanding)

        self.verticalLayout_5.addItem(self.verticalSpacer_28)

        self.horizontalLayout_32 = QHBoxLayout()
        self.horizontalLayout_32.setObjectName(u"horizontalLayout_32")
        self.horizontalSpacer_23 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_32.addItem(self.horizontalSpacer_23)

        self.Title_7 = QLabel(self.LastNewsPanel)
        self.Title_7.setObjectName(u"Title_7")
        self.Title_7.setStyleSheet(u"color: red;\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid red;")
        self.Title_7.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_32.addWidget(self.Title_7)

        self.horizontalSpacer_24 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_32.addItem(self.horizontalSpacer_24)


        self.verticalLayout_5.addLayout(self.horizontalLayout_32)

        self.horizontalLayout_33 = QHBoxLayout()
        self.horizontalLayout_33.setObjectName(u"horizontalLayout_33")
        self.horizontalLayout_33.setContentsMargins(25, -1, 25, -1)
        self.line_8 = QFrame(self.LastNewsPanel)
        self.line_8.setObjectName(u"line_8")
        self.line_8.setAutoFillBackground(False)
        self.line_8.setStyleSheet(u"color: red;\n"
"")
        self.line_8.setFrameShadow(QFrame.Shadow.Plain)
        self.line_8.setLineWidth(2)
        self.line_8.setMidLineWidth(2)
        self.line_8.setFrameShape(QFrame.Shape.HLine)

        self.horizontalLayout_33.addWidget(self.line_8)


        self.verticalLayout_5.addLayout(self.horizontalLayout_33)

        self.horizontalLayout_31 = QHBoxLayout()
        self.horizontalLayout_31.setObjectName(u"horizontalLayout_31")
        self.horizontalLayout_31.setContentsMargins(-1, 0, -1, -1)
        self.pushButton_10 = QPushButton(self.LastNewsPanel)
        self.pushButton_10.setObjectName(u"pushButton_10")
        sizePolicy2.setHeightForWidth(self.pushButton_10.sizePolicy().hasHeightForWidth())
        self.pushButton_10.setSizePolicy(sizePolicy2)
        font3 = QFont()
        font3.setPointSize(8)
        font3.setBold(True)
        self.pushButton_10.setFont(font3)
        self.pushButton_10.setStyleSheet(u"QPushButton {\n"
"background-color: transparent; \n"
"    color: black;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 8pt;         \n"
"    font-weight: bold;  \n"
"}")
        self.pushButton_10.setCheckable(False)
        self.pushButton_10.setChecked(False)

        self.horizontalLayout_31.addWidget(self.pushButton_10)

        self.pushButton_8 = QPushButton(self.LastNewsPanel)
        self.pushButton_8.setObjectName(u"pushButton_8")
        sizePolicy2.setHeightForWidth(self.pushButton_8.sizePolicy().hasHeightForWidth())
        self.pushButton_8.setSizePolicy(sizePolicy2)
        self.pushButton_8.setFont(font2)
        self.pushButton_8.setStyleSheet(u"QPushButton {\n"
"background-color: #69BB71; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_8.setCheckable(False)
        self.pushButton_8.setChecked(False)

        self.horizontalLayout_31.addWidget(self.pushButton_8)

        self.pushButton_9 = QPushButton(self.LastNewsPanel)
        self.pushButton_9.setObjectName(u"pushButton_9")
        sizePolicy2.setHeightForWidth(self.pushButton_9.sizePolicy().hasHeightForWidth())
        self.pushButton_9.setSizePolicy(sizePolicy2)
        self.pushButton_9.setFont(font3)
        self.pushButton_9.setStyleSheet(u"QPushButton {\n"
"background-color: transparent; \n"
"    color: black;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 8pt;         \n"
"    font-weight: bold;  \n"
"}")
        self.pushButton_9.setCheckable(False)
        self.pushButton_9.setChecked(False)

        self.horizontalLayout_31.addWidget(self.pushButton_9)

        self.pushButton_11 = QPushButton(self.LastNewsPanel)
        self.pushButton_11.setObjectName(u"pushButton_11")
        sizePolicy2.setHeightForWidth(self.pushButton_11.sizePolicy().hasHeightForWidth())
        self.pushButton_11.setSizePolicy(sizePolicy2)
        self.pushButton_11.setFont(font2)
        self.pushButton_11.setStyleSheet(u"QPushButton {\n"
"background-color: #FFA8A8; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_11.setCheckable(False)
        self.pushButton_11.setChecked(False)

        self.horizontalLayout_31.addWidget(self.pushButton_11)


        self.verticalLayout_5.addLayout(self.horizontalLayout_31)

        self.horizontalLayout_34 = QHBoxLayout()
        self.horizontalLayout_34.setObjectName(u"horizontalLayout_34")
        self.horizontalLayout_34.setContentsMargins(-1, 0, -1, -1)
        self.pushButton_12 = QPushButton(self.LastNewsPanel)
        self.pushButton_12.setObjectName(u"pushButton_12")
        sizePolicy2.setHeightForWidth(self.pushButton_12.sizePolicy().hasHeightForWidth())
        self.pushButton_12.setSizePolicy(sizePolicy2)
        self.pushButton_12.setFont(font3)
        self.pushButton_12.setStyleSheet(u"QPushButton {\n"
"background-color: transparent; \n"
"    color: black;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 8pt;         \n"
"    font-weight: bold;  \n"
"}")
        self.pushButton_12.setCheckable(False)
        self.pushButton_12.setChecked(False)

        self.horizontalLayout_34.addWidget(self.pushButton_12)

        self.pushButton_13 = QPushButton(self.LastNewsPanel)
        self.pushButton_13.setObjectName(u"pushButton_13")
        sizePolicy2.setHeightForWidth(self.pushButton_13.sizePolicy().hasHeightForWidth())
        self.pushButton_13.setSizePolicy(sizePolicy2)
        self.pushButton_13.setFont(font2)
        self.pushButton_13.setStyleSheet(u"QPushButton {\n"
"background-color: #69BB71; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_13.setCheckable(False)
        self.pushButton_13.setChecked(False)

        self.horizontalLayout_34.addWidget(self.pushButton_13)

        self.pushButton_14 = QPushButton(self.LastNewsPanel)
        self.pushButton_14.setObjectName(u"pushButton_14")
        sizePolicy2.setHeightForWidth(self.pushButton_14.sizePolicy().hasHeightForWidth())
        self.pushButton_14.setSizePolicy(sizePolicy2)
        self.pushButton_14.setFont(font3)
        self.pushButton_14.setStyleSheet(u"QPushButton {\n"
"background-color: transparent; \n"
"    color: black;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 8pt;         \n"
"    font-weight: bold;  \n"
"}")
        self.pushButton_14.setCheckable(False)
        self.pushButton_14.setChecked(False)

        self.horizontalLayout_34.addWidget(self.pushButton_14)

        self.pushButton_15 = QPushButton(self.LastNewsPanel)
        self.pushButton_15.setObjectName(u"pushButton_15")
        sizePolicy2.setHeightForWidth(self.pushButton_15.sizePolicy().hasHeightForWidth())
        self.pushButton_15.setSizePolicy(sizePolicy2)
        self.pushButton_15.setFont(font2)
        self.pushButton_15.setStyleSheet(u"QPushButton {\n"
"background-color: #FFA8A8; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_15.setCheckable(False)
        self.pushButton_15.setChecked(False)

        self.horizontalLayout_34.addWidget(self.pushButton_15)


        self.verticalLayout_5.addLayout(self.horizontalLayout_34)

        self.horizontalLayout_35 = QHBoxLayout()
        self.horizontalLayout_35.setObjectName(u"horizontalLayout_35")
        self.horizontalLayout_35.setContentsMargins(-1, 0, -1, -1)
        self.pushButton_16 = QPushButton(self.LastNewsPanel)
        self.pushButton_16.setObjectName(u"pushButton_16")
        sizePolicy2.setHeightForWidth(self.pushButton_16.sizePolicy().hasHeightForWidth())
        self.pushButton_16.setSizePolicy(sizePolicy2)
        self.pushButton_16.setFont(font3)
        self.pushButton_16.setStyleSheet(u"QPushButton {\n"
"background-color: transparent; \n"
"    color: black;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 8pt;         \n"
"    font-weight: bold;  \n"
"}")
        self.pushButton_16.setCheckable(False)
        self.pushButton_16.setChecked(False)

        self.horizontalLayout_35.addWidget(self.pushButton_16)

        self.pushButton_17 = QPushButton(self.LastNewsPanel)
        self.pushButton_17.setObjectName(u"pushButton_17")
        sizePolicy2.setHeightForWidth(self.pushButton_17.sizePolicy().hasHeightForWidth())
        self.pushButton_17.setSizePolicy(sizePolicy2)
        self.pushButton_17.setFont(font2)
        self.pushButton_17.setStyleSheet(u"QPushButton {\n"
"background-color: #69BB71; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_17.setCheckable(False)
        self.pushButton_17.setChecked(False)

        self.horizontalLayout_35.addWidget(self.pushButton_17)

        self.pushButton_18 = QPushButton(self.LastNewsPanel)
        self.pushButton_18.setObjectName(u"pushButton_18")
        sizePolicy2.setHeightForWidth(self.pushButton_18.sizePolicy().hasHeightForWidth())
        self.pushButton_18.setSizePolicy(sizePolicy2)
        self.pushButton_18.setFont(font3)
        self.pushButton_18.setStyleSheet(u"QPushButton {\n"
"background-color: transparent; \n"
"    color: black;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 8pt;         \n"
"    font-weight: bold;  \n"
"}")
        self.pushButton_18.setCheckable(False)
        self.pushButton_18.setChecked(False)

        self.horizontalLayout_35.addWidget(self.pushButton_18)

        self.pushButton_19 = QPushButton(self.LastNewsPanel)
        self.pushButton_19.setObjectName(u"pushButton_19")
        sizePolicy2.setHeightForWidth(self.pushButton_19.sizePolicy().hasHeightForWidth())
        self.pushButton_19.setSizePolicy(sizePolicy2)
        self.pushButton_19.setFont(font2)
        self.pushButton_19.setStyleSheet(u"QPushButton {\n"
"background-color: #FFA8A8; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_19.setCheckable(False)
        self.pushButton_19.setChecked(False)

        self.horizontalLayout_35.addWidget(self.pushButton_19)


        self.verticalLayout_5.addLayout(self.horizontalLayout_35)

        self.horizontalLayout_36 = QHBoxLayout()
        self.horizontalLayout_36.setObjectName(u"horizontalLayout_36")
        self.horizontalLayout_36.setContentsMargins(-1, 0, -1, -1)
        self.pushButton_20 = QPushButton(self.LastNewsPanel)
        self.pushButton_20.setObjectName(u"pushButton_20")
        sizePolicy2.setHeightForWidth(self.pushButton_20.sizePolicy().hasHeightForWidth())
        self.pushButton_20.setSizePolicy(sizePolicy2)
        self.pushButton_20.setFont(font3)
        self.pushButton_20.setStyleSheet(u"QPushButton {\n"
"background-color: transparent; \n"
"    color: black;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 8pt;         \n"
"    font-weight: bold;  \n"
"}")
        self.pushButton_20.setCheckable(False)
        self.pushButton_20.setChecked(False)

        self.horizontalLayout_36.addWidget(self.pushButton_20)

        self.pushButton_21 = QPushButton(self.LastNewsPanel)
        self.pushButton_21.setObjectName(u"pushButton_21")
        sizePolicy2.setHeightForWidth(self.pushButton_21.sizePolicy().hasHeightForWidth())
        self.pushButton_21.setSizePolicy(sizePolicy2)
        self.pushButton_21.setFont(font2)
        self.pushButton_21.setStyleSheet(u"QPushButton {\n"
"background-color: #69BB71; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_21.setCheckable(False)
        self.pushButton_21.setChecked(False)

        self.horizontalLayout_36.addWidget(self.pushButton_21)

        self.pushButton_22 = QPushButton(self.LastNewsPanel)
        self.pushButton_22.setObjectName(u"pushButton_22")
        sizePolicy2.setHeightForWidth(self.pushButton_22.sizePolicy().hasHeightForWidth())
        self.pushButton_22.setSizePolicy(sizePolicy2)
        self.pushButton_22.setFont(font3)
        self.pushButton_22.setStyleSheet(u"QPushButton {\n"
"background-color: transparent; \n"
"    color: black;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 8pt;         \n"
"    font-weight: bold;  \n"
"}")
        self.pushButton_22.setCheckable(False)
        self.pushButton_22.setChecked(False)

        self.horizontalLayout_36.addWidget(self.pushButton_22)

        self.pushButton_23 = QPushButton(self.LastNewsPanel)
        self.pushButton_23.setObjectName(u"pushButton_23")
        sizePolicy2.setHeightForWidth(self.pushButton_23.sizePolicy().hasHeightForWidth())
        self.pushButton_23.setSizePolicy(sizePolicy2)
        self.pushButton_23.setFont(font2)
        self.pushButton_23.setStyleSheet(u"QPushButton {\n"
"background-color: #FFA8A8; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.pushButton_23.setCheckable(False)
        self.pushButton_23.setChecked(False)

        self.horizontalLayout_36.addWidget(self.pushButton_23)


        self.verticalLayout_5.addLayout(self.horizontalLayout_36)

        self.verticalLayout_5.setStretch(2, 2)
        self.verticalLayout_5.setStretch(3, 1)
        self.verticalLayout_5.setStretch(4, 2)
        self.verticalLayout_5.setStretch(7, 1)
        self.verticalLayout_5.setStretch(8, 1)
        self.verticalLayout_5.setStretch(9, 1)
        self.verticalLayout_5.setStretch(10, 1)

        self.horizontalLayout_5.addWidget(self.LastNewsPanel)

        self.Data = QFrame(self.Home)
        self.Data.setObjectName(u"Data")
        sizePolicy3.setHeightForWidth(self.Data.sizePolicy().hasHeightForWidth())
        self.Data.setSizePolicy(sizePolicy3)
        self.Data.setFrameShape(QFrame.Shape.StyledPanel)
        self.Data.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_11 = QGridLayout(self.Data)
        self.gridLayout_11.setObjectName(u"gridLayout_11")
        self.widget_15 = SensorLuzWidget(self.Data)
        self.widget_15.setObjectName(u"widget_15")

        self.gridLayout_11.addWidget(self.widget_15, 0, 1, 1, 1)

        self.frame_grafica = QFrame(self.Data)
        self.frame_grafica.setObjectName(u"frame_grafica")
        self.frame_grafica.setStyleSheet(u"QFrame{\n"
"	border-radius: 30px;\n"
"	background-color: rgb(181, 231, 240);\n"
"}")
        self.frame_grafica.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_grafica.setFrameShadow(QFrame.Shadow.Raised)
        self.gridLayout_10 = QGridLayout(self.frame_grafica)
        self.gridLayout_10.setObjectName(u"gridLayout_10")

        self.gridLayout_11.addWidget(self.frame_grafica, 1, 0, 2, 4)

        self.widget_12 = SensorRuidoWidget(self.Data)
        self.widget_12.setObjectName(u"widget_12")

        self.gridLayout_11.addWidget(self.widget_12, 0, 3, 1, 1)

        self.widget_16 = CalidadAireWidget(self.Data)
        self.widget_16.setObjectName(u"widget_16")

        self.gridLayout_11.addWidget(self.widget_16, 0, 2, 1, 1)

        self.widget_13 = TermostatoWidget(self.Data)
        self.widget_13.setObjectName(u"widget_13")

        self.gridLayout_11.addWidget(self.widget_13, 0, 0, 1, 1)

        self.label_parking = QLabel(self.Data)
        self.label_parking.setObjectName(u"label_parking")

        self.gridLayout_11.addWidget(self.label_parking, 3, 0, 1, 2)

        self.gridLayout_11.setRowStretch(0, 1)
        self.gridLayout_11.setRowStretch(1, 1)
        self.gridLayout_11.setRowStretch(2, 1)
        self.gridLayout_11.setColumnStretch(0, 1)
        self.gridLayout_11.setColumnStretch(1, 1)
        self.gridLayout_11.setColumnStretch(2, 1)
        self.gridLayout_11.setColumnStretch(3, 1)

        self.horizontalLayout_5.addWidget(self.Data)

        self.horizontalLayout_5.setStretch(0, 1)
        self.horizontalLayout_5.setStretch(1, 5)

        self.gridLayout_2.addLayout(self.horizontalLayout_5, 0, 1, 1, 1)

        self.stackedWidget.addWidget(self.Home)
        self.Sensors = QWidget()
        self.Sensors.setObjectName(u"Sensors")
        self.gridLayout_4 = QGridLayout(self.Sensors)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.horizontalLayout_7 = QHBoxLayout()
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.horizontalLayout_7.setContentsMargins(-1, 0, -1, -1)
        self.LastNewsPanel_6 = QFrame(self.Sensors)
        self.LastNewsPanel_6.setObjectName(u"LastNewsPanel_6")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Maximum)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.LastNewsPanel_6.sizePolicy().hasHeightForWidth())
        self.LastNewsPanel_6.setSizePolicy(sizePolicy4)
        self.LastNewsPanel_6.setMinimumSize(QSize(0, 88))
        self.LastNewsPanel_6.setMaximumSize(QSize(10000, 10000))
        self.LastNewsPanel_6.setAutoFillBackground(False)
        self.LastNewsPanel_6.setStyleSheet(u"QFrame#LastNewsPanel_6{\n"
"	border-image: url(:/login/vista-aerea-gran-centro-comercial.png);\n"
"}")
        self.LastNewsPanel_6.setFrameShape(QFrame.Shape.NoFrame)
        self.LastNewsPanel_6.setFrameShadow(QFrame.Shadow.Plain)
        self.gridLayout_12 = QGridLayout(self.LastNewsPanel_6)
        self.gridLayout_12.setSpacing(6)
        self.gridLayout_12.setObjectName(u"gridLayout_12")
        self.gridLayout_12.setContentsMargins(6, 6, 6, 6)
        self.verticalSpacer_29 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_29, 5, 5, 1, 1)

        self.horizontalLayout_37 = QHBoxLayout()
        self.horizontalLayout_37.setObjectName(u"horizontalLayout_37")
        self.Sector5_3 = QPushButton(self.LastNewsPanel_6)
        self.Sector5_3.setObjectName(u"Sector5_3")
        self.Sector5_3.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector5_3.setCheckable(False)
        self.Sector5_3.setChecked(False)

        self.horizontalLayout_37.addWidget(self.Sector5_3)

        self.check5_2 = QLabel(self.LastNewsPanel_6)
        self.check5_2.setObjectName(u"check5_2")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Ignored)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.check5_2.sizePolicy().hasHeightForWidth())
        self.check5_2.setSizePolicy(sizePolicy5)
        self.check5_2.setMinimumSize(QSize(40, 10))
        self.check5_2.setStyleSheet(u"background-color: transparent;")
        self.check5_2.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check5_2.setScaledContents(True)

        self.horizontalLayout_37.addWidget(self.check5_2)


        self.gridLayout_12.addLayout(self.horizontalLayout_37, 4, 5, 1, 1)

        self.horizontalLayout_38 = QHBoxLayout()
        self.horizontalLayout_38.setObjectName(u"horizontalLayout_38")
        self.Sector4_3 = QPushButton(self.LastNewsPanel_6)
        self.Sector4_3.setObjectName(u"Sector4_3")
        self.Sector4_3.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector4_3.setCheckable(False)
        self.Sector4_3.setChecked(False)

        self.horizontalLayout_38.addWidget(self.Sector4_3)

        self.check4_2 = QLabel(self.LastNewsPanel_6)
        self.check4_2.setObjectName(u"check4_2")
        sizePolicy5.setHeightForWidth(self.check4_2.sizePolicy().hasHeightForWidth())
        self.check4_2.setSizePolicy(sizePolicy5)
        self.check4_2.setMinimumSize(QSize(40, 10))
        self.check4_2.setStyleSheet(u"background-color: transparent;")
        self.check4_2.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check4_2.setScaledContents(True)

        self.horizontalLayout_38.addWidget(self.check4_2)


        self.gridLayout_12.addLayout(self.horizontalLayout_38, 13, 5, 1, 1)

        self.horizontalLayout_17 = QHBoxLayout()
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.Sector1_4 = QPushButton(self.LastNewsPanel_6)
        self.Sector1_4.setObjectName(u"Sector1_4")
        self.Sector1_4.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector1_4.setCheckable(False)
        self.Sector1_4.setChecked(False)

        self.horizontalLayout_17.addWidget(self.Sector1_4)

        self.check1_2 = QLabel(self.LastNewsPanel_6)
        self.check1_2.setObjectName(u"check1_2")
        sizePolicy5.setHeightForWidth(self.check1_2.sizePolicy().hasHeightForWidth())
        self.check1_2.setSizePolicy(sizePolicy5)
        self.check1_2.setMinimumSize(QSize(40, 10))
        self.check1_2.setStyleSheet(u"background-color: transparent;")
        self.check1_2.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check1_2.setScaledContents(True)

        self.horizontalLayout_17.addWidget(self.check1_2)


        self.gridLayout_12.addLayout(self.horizontalLayout_17, 2, 1, 1, 1)

        self.verticalSpacer_30 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_30, 0, 1, 1, 1)

        self.verticalSpacer_31 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_31, 15, 3, 1, 1)

        self.verticalSpacer_32 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_32, 10, 1, 1, 1)

        self.horizontalLayout_12 = QHBoxLayout()
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.Sector7_9 = QPushButton(self.LastNewsPanel_6)
        self.Sector7_9.setObjectName(u"Sector7_9")
        self.Sector7_9.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_9.setCheckable(False)
        self.Sector7_9.setChecked(False)

        self.horizontalLayout_12.addWidget(self.Sector7_9)

        self.check7_2 = QLabel(self.LastNewsPanel_6)
        self.check7_2.setObjectName(u"check7_2")
        sizePolicy5.setHeightForWidth(self.check7_2.sizePolicy().hasHeightForWidth())
        self.check7_2.setSizePolicy(sizePolicy5)
        self.check7_2.setMinimumSize(QSize(40, 0))
        self.check7_2.setStyleSheet(u"background-color: transparent;")
        self.check7_2.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check7_2.setScaledContents(True)

        self.horizontalLayout_12.addWidget(self.check7_2)


        self.gridLayout_12.addLayout(self.horizontalLayout_12, 6, 7, 1, 1)

        self.horizontalSpacer_25 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_12.addItem(self.horizontalSpacer_25, 8, 2, 1, 1)

        self.horizontalLayout_21 = QHBoxLayout()
        self.horizontalLayout_21.setObjectName(u"horizontalLayout_21")
        self.Sector2_3 = QPushButton(self.LastNewsPanel_6)
        self.Sector2_3.setObjectName(u"Sector2_3")
        self.Sector2_3.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector2_3.setCheckable(False)
        self.Sector2_3.setChecked(False)

        self.horizontalLayout_21.addWidget(self.Sector2_3)

        self.check2_2 = QLabel(self.LastNewsPanel_6)
        self.check2_2.setObjectName(u"check2_2")
        sizePolicy5.setHeightForWidth(self.check2_2.sizePolicy().hasHeightForWidth())
        self.check2_2.setSizePolicy(sizePolicy5)
        self.check2_2.setMinimumSize(QSize(40, 10))
        self.check2_2.setStyleSheet(u"background-color: transparent;")
        self.check2_2.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check2_2.setScaledContents(True)

        self.horizontalLayout_21.addWidget(self.check2_2)


        self.gridLayout_12.addLayout(self.horizontalLayout_21, 8, 3, 1, 1)

        self.horizontalSpacer_26 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_12.addItem(self.horizontalSpacer_26, 6, 6, 1, 1)

        self.verticalSpacer_33 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_33, 11, 7, 1, 1)

        self.verticalSpacer_34 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_34, 14, 5, 1, 1)

        self.verticalSpacer_35 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_35, 2, 3, 1, 1)

        self.horizontalSpacer_27 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_12.addItem(self.horizontalSpacer_27, 13, 4, 1, 1)

        self.verticalSpacer_36 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_36, 6, 1, 1, 1)

        self.verticalSpacer_37 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_37, 7, 7, 1, 1)

        self.horizontalLayout_39 = QHBoxLayout()
        self.horizontalLayout_39.setObjectName(u"horizontalLayout_39")
        self.Sector6_3 = QPushButton(self.LastNewsPanel_6)
        self.Sector6_3.setObjectName(u"Sector6_3")
        self.Sector6_3.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector6_3.setCheckable(False)
        self.Sector6_3.setChecked(False)

        self.horizontalLayout_39.addWidget(self.Sector6_3)

        self.check6_2 = QLabel(self.LastNewsPanel_6)
        self.check6_2.setObjectName(u"check6_2")
        sizePolicy5.setHeightForWidth(self.check6_2.sizePolicy().hasHeightForWidth())
        self.check6_2.setSizePolicy(sizePolicy5)
        self.check6_2.setMinimumSize(QSize(40, 10))
        self.check6_2.setStyleSheet(u"background-color: transparent;")
        self.check6_2.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check6_2.setScaledContents(True)

        self.horizontalLayout_39.addWidget(self.check6_2)


        self.gridLayout_12.addLayout(self.horizontalLayout_39, 0, 5, 1, 1)

        self.horizontalLayout_22 = QHBoxLayout()
        self.horizontalLayout_22.setObjectName(u"horizontalLayout_22")
        self.Sector3_3 = QPushButton(self.LastNewsPanel_6)
        self.Sector3_3.setObjectName(u"Sector3_3")
        self.Sector3_3.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector3_3.setCheckable(False)
        self.Sector3_3.setChecked(False)

        self.horizontalLayout_22.addWidget(self.Sector3_3)

        self.check3_2 = QLabel(self.LastNewsPanel_6)
        self.check3_2.setObjectName(u"check3_2")
        sizePolicy5.setHeightForWidth(self.check3_2.sizePolicy().hasHeightForWidth())
        self.check3_2.setSizePolicy(sizePolicy5)
        self.check3_2.setMinimumSize(QSize(40, 10))
        self.check3_2.setStyleSheet(u"background-color: transparent;")
        self.check3_2.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check3_2.setScaledContents(True)

        self.horizontalLayout_22.addWidget(self.check3_2)


        self.gridLayout_12.addLayout(self.horizontalLayout_22, 15, 1, 1, 1)

        self.horizontalLayout_18 = QHBoxLayout()
        self.horizontalLayout_18.setObjectName(u"horizontalLayout_18")
        self.Sector8_3 = QPushButton(self.LastNewsPanel_6)
        self.Sector8_3.setObjectName(u"Sector8_3")
        self.Sector8_3.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector8_3.setCheckable(False)
        self.Sector8_3.setChecked(False)

        self.horizontalLayout_18.addWidget(self.Sector8_3)

        self.check8_2 = QLabel(self.LastNewsPanel_6)
        self.check8_2.setObjectName(u"check8_2")
        sizePolicy5.setHeightForWidth(self.check8_2.sizePolicy().hasHeightForWidth())
        self.check8_2.setSizePolicy(sizePolicy5)
        self.check8_2.setMinimumSize(QSize(40, 0))
        self.check8_2.setStyleSheet(u"background-color: transparent;")
        self.check8_2.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check8_2.setScaledContents(True)

        self.horizontalLayout_18.addWidget(self.check8_2)


        self.gridLayout_12.addLayout(self.horizontalLayout_18, 10, 7, 1, 1)

        self.verticalSpacer_38 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_38, 4, 1, 1, 1)

        self.horizontalSpacer_17 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_12.addItem(self.horizontalSpacer_17, 4, 0, 1, 1)

        self.verticalSpacer_39 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_39, 13, 1, 1, 1)

        self.verticalSpacer_40 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_40, 12, 1, 1, 1)

        self.horizontalSpacer_28 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_12.addItem(self.horizontalSpacer_28, 6, 8, 1, 1)

        self.verticalSpacer_41 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_41, 9, 3, 1, 1)

        self.verticalSpacer_42 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_42, 8, 1, 1, 1)

        self.verticalSpacer_43 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_43, 16, 1, 1, 1)

        self.verticalSpacer_44 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_44, 3, 3, 1, 1)

        self.verticalSpacer_45 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_12.addItem(self.verticalSpacer_45, 1, 5, 1, 1)


        self.horizontalLayout_7.addWidget(self.LastNewsPanel_6)

        self.verticalLayout_4 = QVBoxLayout()
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(-1, -1, 0, -1)
        self.horizontalLayout_23 = QHBoxLayout()
        self.horizontalLayout_23.setObjectName(u"horizontalLayout_23")
        self.horizontalSpacer_18 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_23.addItem(self.horizontalSpacer_18)

        self.TitleLastNews_3 = QLabel(self.Sensors)
        self.TitleLastNews_3.setObjectName(u"TitleLastNews_3")
        self.TitleLastNews_3.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.TitleLastNews_3.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_23.addWidget(self.TitleLastNews_3)

        self.horizontalSpacer_31 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_23.addItem(self.horizontalSpacer_31)


        self.verticalLayout_4.addLayout(self.horizontalLayout_23)

        self.verticalLayout_10 = QVBoxLayout()
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalLayout_10.setContentsMargins(-1, 0, -1, -1)
        self.line_10 = QFrame(self.Sensors)
        self.line_10.setObjectName(u"line_10")
        self.line_10.setAutoFillBackground(False)
        self.line_10.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_10.setFrameShadow(QFrame.Shadow.Plain)
        self.line_10.setLineWidth(2)
        self.line_10.setMidLineWidth(2)
        self.line_10.setFrameShape(QFrame.Shape.HLine)

        self.verticalLayout_10.addWidget(self.line_10)


        self.verticalLayout_4.addLayout(self.verticalLayout_10)

        self.verticalLayout_12 = QVBoxLayout()
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.verticalLayout_12.setContentsMargins(-1, 0, -1, -1)
        self.scrollArea_5 = QScrollArea(self.Sensors)
        self.scrollArea_5.setObjectName(u"scrollArea_5")
        self.scrollArea_5.setWidgetResizable(True)
        self.scrollAreaWidgetContents_5 = QWidget()
        self.scrollAreaWidgetContents_5.setObjectName(u"scrollAreaWidgetContents_5")
        self.scrollAreaWidgetContents_5.setGeometry(QRect(0, 0, 76, 880))
        self.verticalLayout_21 = QVBoxLayout(self.scrollAreaWidgetContents_5)
        self.verticalLayout_21.setObjectName(u"verticalLayout_21")
        self.verticalLayout_21.setContentsMargins(0, 0, 0, 0)
        self.TextoLastNews_2 = QLabel(self.scrollAreaWidgetContents_5)
        self.TextoLastNews_2.setObjectName(u"TextoLastNews_2")
        self.TextoLastNews_2.setFont(font1)
        self.TextoLastNews_2.setStyleSheet(u"color: black;\n"
"text-align: center;\n"
"")
        self.TextoLastNews_2.setFrameShadow(QFrame.Shadow.Plain)
        self.TextoLastNews_2.setTextFormat(Qt.TextFormat.PlainText)
        self.TextoLastNews_2.setScaledContents(False)
        self.TextoLastNews_2.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)
        self.TextoLastNews_2.setWordWrap(True)

        self.verticalLayout_21.addWidget(self.TextoLastNews_2)

        self.scrollArea_5.setWidget(self.scrollAreaWidgetContents_5)

        self.verticalLayout_12.addWidget(self.scrollArea_5)


        self.verticalLayout_4.addLayout(self.verticalLayout_12)

        self.verticalSpacer_2 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_4.addItem(self.verticalSpacer_2)

        self.horizontalLayout_41 = QHBoxLayout()
        self.horizontalLayout_41.setObjectName(u"horizontalLayout_41")
        self.horizontalSpacer_32 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_41.addItem(self.horizontalSpacer_32)

        self.TitleLastNews_4 = QLabel(self.Sensors)
        self.TitleLastNews_4.setObjectName(u"TitleLastNews_4")
        self.TitleLastNews_4.setStyleSheet(u"color: red;\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid red;")
        self.TitleLastNews_4.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_41.addWidget(self.TitleLastNews_4)

        self.horizontalSpacer_33 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_41.addItem(self.horizontalSpacer_33)


        self.verticalLayout_4.addLayout(self.horizontalLayout_41)

        self.verticalLayout_11 = QVBoxLayout()
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_11.setContentsMargins(-1, 0, -1, -1)
        self.line_11 = QFrame(self.Sensors)
        self.line_11.setObjectName(u"line_11")
        self.line_11.setAutoFillBackground(False)
        self.line_11.setStyleSheet(u"color: red;\n"
"")
        self.line_11.setFrameShadow(QFrame.Shadow.Plain)
        self.line_11.setLineWidth(2)
        self.line_11.setMidLineWidth(2)
        self.line_11.setFrameShape(QFrame.Shape.HLine)

        self.verticalLayout_11.addWidget(self.line_11)


        self.verticalLayout_4.addLayout(self.verticalLayout_11)

        self.verticalLayout_9 = QVBoxLayout()
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_9.setContentsMargins(-1, 0, -1, -1)
        self.TitleLastNews_5 = QLabel(self.Sensors)
        self.TitleLastNews_5.setObjectName(u"TitleLastNews_5")
        self.TitleLastNews_5.setStyleSheet(u"color: red;\n"
"font: bold 16px \"Segoe UI\";")
        self.TitleLastNews_5.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)

        self.verticalLayout_9.addWidget(self.TitleLastNews_5)

        self.scrollArea_6 = QScrollArea(self.Sensors)
        self.scrollArea_6.setObjectName(u"scrollArea_6")
        self.scrollArea_6.setWidgetResizable(True)
        self.scrollAreaWidgetContents_6 = QWidget()
        self.scrollAreaWidgetContents_6.setObjectName(u"scrollAreaWidgetContents_6")
        self.scrollAreaWidgetContents_6.setGeometry(QRect(0, 0, 76, 880))
        self.verticalLayout_23 = QVBoxLayout(self.scrollAreaWidgetContents_6)
        self.verticalLayout_23.setObjectName(u"verticalLayout_23")
        self.verticalLayout_23.setContentsMargins(0, 0, 0, 0)
        self.TextoLastNews_4 = QLabel(self.scrollAreaWidgetContents_6)
        self.TextoLastNews_4.setObjectName(u"TextoLastNews_4")
        self.TextoLastNews_4.setFont(font1)
        self.TextoLastNews_4.setStyleSheet(u"color: black;\n"
"text-align: center;\n"
"")
        self.TextoLastNews_4.setFrameShadow(QFrame.Shadow.Plain)
        self.TextoLastNews_4.setTextFormat(Qt.TextFormat.PlainText)
        self.TextoLastNews_4.setScaledContents(False)
        self.TextoLastNews_4.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.TextoLastNews_4.setWordWrap(True)

        self.verticalLayout_23.addWidget(self.TextoLastNews_4)

        self.scrollArea_6.setWidget(self.scrollAreaWidgetContents_6)

        self.verticalLayout_9.addWidget(self.scrollArea_6)

        self.TitleLastNews_6 = QLabel(self.Sensors)
        self.TitleLastNews_6.setObjectName(u"TitleLastNews_6")
        self.TitleLastNews_6.setStyleSheet(u"color: orange;\n"
"font: bold 16px \"Segoe UI\";")
        self.TitleLastNews_6.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)

        self.verticalLayout_9.addWidget(self.TitleLastNews_6)

        self.scrollArea_7 = QScrollArea(self.Sensors)
        self.scrollArea_7.setObjectName(u"scrollArea_7")
        self.scrollArea_7.setWidgetResizable(True)
        self.scrollAreaWidgetContents_7 = QWidget()
        self.scrollAreaWidgetContents_7.setObjectName(u"scrollAreaWidgetContents_7")
        self.scrollAreaWidgetContents_7.setGeometry(QRect(0, 0, 76, 880))
        self.verticalLayout_26 = QVBoxLayout(self.scrollAreaWidgetContents_7)
        self.verticalLayout_26.setObjectName(u"verticalLayout_26")
        self.verticalLayout_26.setContentsMargins(0, 0, 0, 0)
        self.TextoLastNews_5 = QLabel(self.scrollAreaWidgetContents_7)
        self.TextoLastNews_5.setObjectName(u"TextoLastNews_5")
        self.TextoLastNews_5.setFont(font1)
        self.TextoLastNews_5.setStyleSheet(u"color: black;\n"
"text-align: center;\n"
"")
        self.TextoLastNews_5.setFrameShadow(QFrame.Shadow.Plain)
        self.TextoLastNews_5.setTextFormat(Qt.TextFormat.PlainText)
        self.TextoLastNews_5.setScaledContents(False)
        self.TextoLastNews_5.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignTop)
        self.TextoLastNews_5.setWordWrap(True)

        self.verticalLayout_26.addWidget(self.TextoLastNews_5)

        self.scrollArea_7.setWidget(self.scrollAreaWidgetContents_7)

        self.verticalLayout_9.addWidget(self.scrollArea_7)


        self.verticalLayout_4.addLayout(self.verticalLayout_9)

        self.verticalLayout_4.setStretch(3, 1)

        self.horizontalLayout_7.addLayout(self.verticalLayout_4)

        self.horizontalLayout_7.setStretch(0, 5)
        self.horizontalLayout_7.setStretch(1, 1)

        self.gridLayout_4.addLayout(self.horizontalLayout_7, 0, 0, 1, 1)

        self.stackedWidget.addWidget(self.Sensors)
        self.Status = QWidget()
        self.Status.setObjectName(u"Status")
        sizePolicy3.setHeightForWidth(self.Status.sizePolicy().hasHeightForWidth())
        self.Status.setSizePolicy(sizePolicy3)
        self.horizontalLayout_10 = QHBoxLayout(self.Status)
        self.horizontalLayout_10.setSpacing(10)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.horizontalLayout_10.setContentsMargins(10, 10, 10, 10)
        self.horizontalLayout_72 = QHBoxLayout()
        self.horizontalLayout_72.setObjectName(u"horizontalLayout_72")
        self.horizontalLayout_72.setContentsMargins(-1, -1, 0, -1)
        self.LastNewsPanel_4 = QFrame(self.Status)
        self.LastNewsPanel_4.setObjectName(u"LastNewsPanel_4")
        sizePolicy4.setHeightForWidth(self.LastNewsPanel_4.sizePolicy().hasHeightForWidth())
        self.LastNewsPanel_4.setSizePolicy(sizePolicy4)
        self.LastNewsPanel_4.setMinimumSize(QSize(0, 88))
        self.LastNewsPanel_4.setMaximumSize(QSize(10000, 10000))
        self.LastNewsPanel_4.setAutoFillBackground(False)
        self.LastNewsPanel_4.setStyleSheet(u"QFrame#LastNewsPanel_4{\n"
"	border-image: url(:/login/vista-aerea-gran-centro-comercial.png);\n"
"}")
        self.LastNewsPanel_4.setFrameShape(QFrame.Shape.NoFrame)
        self.LastNewsPanel_4.setFrameShadow(QFrame.Shadow.Plain)
        self.gridLayout_6 = QGridLayout(self.LastNewsPanel_4)
        self.gridLayout_6.setSpacing(6)
        self.gridLayout_6.setObjectName(u"gridLayout_6")
        self.gridLayout_6.setContentsMargins(6, 6, 6, 6)
        self.verticalSpacer_26 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_26, 5, 5, 1, 1)

        self.horizontalLayout_30 = QHBoxLayout()
        self.horizontalLayout_30.setObjectName(u"horizontalLayout_30")
        self.Sector5 = QPushButton(self.LastNewsPanel_4)
        self.Sector5.setObjectName(u"Sector5")
        self.Sector5.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector5.setCheckable(False)
        self.Sector5.setChecked(False)

        self.horizontalLayout_30.addWidget(self.Sector5)

        self.check5 = QLabel(self.LastNewsPanel_4)
        self.check5.setObjectName(u"check5")
        sizePolicy5.setHeightForWidth(self.check5.sizePolicy().hasHeightForWidth())
        self.check5.setSizePolicy(sizePolicy5)
        self.check5.setMinimumSize(QSize(40, 10))
        self.check5.setStyleSheet(u"background-color: transparent;")
        self.check5.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check5.setScaledContents(True)

        self.horizontalLayout_30.addWidget(self.check5)


        self.gridLayout_6.addLayout(self.horizontalLayout_30, 4, 5, 1, 1)

        self.horizontalLayout_28 = QHBoxLayout()
        self.horizontalLayout_28.setObjectName(u"horizontalLayout_28")
        self.Sector4 = QPushButton(self.LastNewsPanel_4)
        self.Sector4.setObjectName(u"Sector4")
        self.Sector4.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector4.setCheckable(False)
        self.Sector4.setChecked(False)

        self.horizontalLayout_28.addWidget(self.Sector4)

        self.check4 = QLabel(self.LastNewsPanel_4)
        self.check4.setObjectName(u"check4")
        sizePolicy5.setHeightForWidth(self.check4.sizePolicy().hasHeightForWidth())
        self.check4.setSizePolicy(sizePolicy5)
        self.check4.setMinimumSize(QSize(40, 10))
        self.check4.setStyleSheet(u"background-color: transparent;")
        self.check4.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check4.setScaledContents(True)

        self.horizontalLayout_28.addWidget(self.check4)


        self.gridLayout_6.addLayout(self.horizontalLayout_28, 13, 5, 1, 1)

        self.horizontalLayout_14 = QHBoxLayout()
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.Sector1 = QPushButton(self.LastNewsPanel_4)
        self.Sector1.setObjectName(u"Sector1")
        self.Sector1.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector1.setCheckable(False)
        self.Sector1.setChecked(False)

        self.horizontalLayout_14.addWidget(self.Sector1)

        self.check1 = QLabel(self.LastNewsPanel_4)
        self.check1.setObjectName(u"check1")
        sizePolicy5.setHeightForWidth(self.check1.sizePolicy().hasHeightForWidth())
        self.check1.setSizePolicy(sizePolicy5)
        self.check1.setMinimumSize(QSize(40, 10))
        self.check1.setStyleSheet(u"background-color: transparent;")
        self.check1.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check1.setScaledContents(True)

        self.horizontalLayout_14.addWidget(self.check1)


        self.gridLayout_6.addLayout(self.horizontalLayout_14, 2, 1, 1, 1)

        self.verticalSpacer_12 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_12, 0, 1, 1, 1)

        self.verticalSpacer_19 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_19, 15, 3, 1, 1)

        self.verticalSpacer_16 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_16, 10, 1, 1, 1)

        self.horizontalLayout_11 = QHBoxLayout()
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.Sector7 = QPushButton(self.LastNewsPanel_4)
        self.Sector7.setObjectName(u"Sector7")
        self.Sector7.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7.setCheckable(False)
        self.Sector7.setChecked(False)

        self.horizontalLayout_11.addWidget(self.Sector7)

        self.check7 = QLabel(self.LastNewsPanel_4)
        self.check7.setObjectName(u"check7")
        sizePolicy5.setHeightForWidth(self.check7.sizePolicy().hasHeightForWidth())
        self.check7.setSizePolicy(sizePolicy5)
        self.check7.setMinimumSize(QSize(40, 0))
        self.check7.setStyleSheet(u"background-color: transparent;")
        self.check7.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check7.setScaledContents(True)

        self.horizontalLayout_11.addWidget(self.check7)


        self.gridLayout_6.addLayout(self.horizontalLayout_11, 6, 7, 1, 1)

        self.horizontalSpacer_20 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_20, 8, 2, 1, 1)

        self.horizontalLayout_20 = QHBoxLayout()
        self.horizontalLayout_20.setObjectName(u"horizontalLayout_20")
        self.Sector2 = QPushButton(self.LastNewsPanel_4)
        self.Sector2.setObjectName(u"Sector2")
        self.Sector2.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector2.setCheckable(False)
        self.Sector2.setChecked(False)

        self.horizontalLayout_20.addWidget(self.Sector2)

        self.check2 = QLabel(self.LastNewsPanel_4)
        self.check2.setObjectName(u"check2")
        sizePolicy5.setHeightForWidth(self.check2.sizePolicy().hasHeightForWidth())
        self.check2.setSizePolicy(sizePolicy5)
        self.check2.setMinimumSize(QSize(40, 10))
        self.check2.setStyleSheet(u"background-color: transparent;")
        self.check2.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check2.setScaledContents(True)

        self.horizontalLayout_20.addWidget(self.check2)


        self.gridLayout_6.addLayout(self.horizontalLayout_20, 8, 3, 1, 1)

        self.horizontalSpacer_22 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_22, 6, 6, 1, 1)

        self.verticalSpacer_24 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_24, 11, 7, 1, 1)

        self.verticalSpacer_23 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_23, 14, 5, 1, 1)

        self.verticalSpacer_15 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_15, 2, 3, 1, 1)

        self.horizontalSpacer_21 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_21, 13, 4, 1, 1)

        self.verticalSpacer_20 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_20, 6, 1, 1, 1)

        self.verticalSpacer_21 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_21, 7, 7, 1, 1)

        self.horizontalLayout_29 = QHBoxLayout()
        self.horizontalLayout_29.setObjectName(u"horizontalLayout_29")
        self.Sector6 = QPushButton(self.LastNewsPanel_4)
        self.Sector6.setObjectName(u"Sector6")
        self.Sector6.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector6.setCheckable(False)
        self.Sector6.setChecked(False)

        self.horizontalLayout_29.addWidget(self.Sector6)

        self.check6 = QLabel(self.LastNewsPanel_4)
        self.check6.setObjectName(u"check6")
        sizePolicy5.setHeightForWidth(self.check6.sizePolicy().hasHeightForWidth())
        self.check6.setSizePolicy(sizePolicy5)
        self.check6.setMinimumSize(QSize(40, 10))
        self.check6.setStyleSheet(u"background-color: transparent;")
        self.check6.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check6.setScaledContents(True)

        self.horizontalLayout_29.addWidget(self.check6)


        self.gridLayout_6.addLayout(self.horizontalLayout_29, 0, 5, 1, 1)

        self.horizontalLayout_19 = QHBoxLayout()
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.Sector3 = QPushButton(self.LastNewsPanel_4)
        self.Sector3.setObjectName(u"Sector3")
        self.Sector3.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector3.setCheckable(False)
        self.Sector3.setChecked(False)

        self.horizontalLayout_19.addWidget(self.Sector3)

        self.check3 = QLabel(self.LastNewsPanel_4)
        self.check3.setObjectName(u"check3")
        sizePolicy5.setHeightForWidth(self.check3.sizePolicy().hasHeightForWidth())
        self.check3.setSizePolicy(sizePolicy5)
        self.check3.setMinimumSize(QSize(40, 10))
        self.check3.setStyleSheet(u"background-color: transparent;")
        self.check3.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check3.setScaledContents(True)

        self.horizontalLayout_19.addWidget(self.check3)


        self.gridLayout_6.addLayout(self.horizontalLayout_19, 15, 1, 1, 1)

        self.horizontalLayout_16 = QHBoxLayout()
        self.horizontalLayout_16.setObjectName(u"horizontalLayout_16")
        self.Sector8 = QPushButton(self.LastNewsPanel_4)
        self.Sector8.setObjectName(u"Sector8")
        self.Sector8.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector8.setCheckable(False)
        self.Sector8.setChecked(False)

        self.horizontalLayout_16.addWidget(self.Sector8)

        self.check8 = QLabel(self.LastNewsPanel_4)
        self.check8.setObjectName(u"check8")
        sizePolicy5.setHeightForWidth(self.check8.sizePolicy().hasHeightForWidth())
        self.check8.setSizePolicy(sizePolicy5)
        self.check8.setMinimumSize(QSize(40, 0))
        self.check8.setStyleSheet(u"background-color: transparent;")
        self.check8.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check8.setScaledContents(True)

        self.horizontalLayout_16.addWidget(self.check8)


        self.gridLayout_6.addLayout(self.horizontalLayout_16, 10, 7, 1, 1)

        self.verticalSpacer_13 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_13, 4, 1, 1, 1)

        self.horizontalSpacer_16 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_16, 4, 0, 1, 1)

        self.verticalSpacer_11 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_11, 13, 1, 1, 1)

        self.verticalSpacer_17 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_17, 12, 1, 1, 1)

        self.horizontalSpacer_19 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_6.addItem(self.horizontalSpacer_19, 6, 8, 1, 1)

        self.verticalSpacer_25 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_25, 9, 3, 1, 1)

        self.verticalSpacer_14 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_14, 8, 1, 1, 1)

        self.verticalSpacer_22 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_22, 16, 1, 1, 1)

        self.verticalSpacer_18 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_18, 3, 3, 1, 1)

        self.verticalSpacer_27 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_6.addItem(self.verticalSpacer_27, 1, 5, 1, 1)


        self.horizontalLayout_72.addWidget(self.LastNewsPanel_4)

        self.verticalLayout_22 = QVBoxLayout()
        self.verticalLayout_22.setObjectName(u"verticalLayout_22")
        self.verticalLayout_22.setContentsMargins(-1, -1, 0, -1)
        self.frame_4 = QFrame(self.Status)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_4.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_15 = QVBoxLayout(self.frame_4)
        self.verticalLayout_15.setSpacing(6)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.Sector1_3 = QPushButton(self.frame_4)
        self.Sector1_3.setObjectName(u"Sector1_3")
        self.Sector1_3.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 9pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector1_3.setCheckable(False)
        self.Sector1_3.setChecked(False)

        self.verticalLayout_15.addWidget(self.Sector1_3)

        self.verticalSpacer_4 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_15.addItem(self.verticalSpacer_4)

        self.horizontalLayout_13 = QHBoxLayout()
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.horizontalSpacer_11 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_13.addItem(self.horizontalSpacer_11)

        self.TitleLastNews = QLabel(self.frame_4)
        self.TitleLastNews.setObjectName(u"TitleLastNews")
        self.TitleLastNews.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.TitleLastNews.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_13.addWidget(self.TitleLastNews)

        self.horizontalSpacer_12 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_13.addItem(self.horizontalSpacer_12)


        self.verticalLayout_15.addLayout(self.horizontalLayout_13)

        self.verticalLayout_6 = QVBoxLayout()
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(-1, 0, -1, -1)
        self.line_7 = QFrame(self.frame_4)
        self.line_7.setObjectName(u"line_7")
        self.line_7.setAutoFillBackground(False)
        self.line_7.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_7.setFrameShadow(QFrame.Shadow.Plain)
        self.line_7.setLineWidth(2)
        self.line_7.setMidLineWidth(2)
        self.line_7.setFrameShape(QFrame.Shape.HLine)

        self.verticalLayout_6.addWidget(self.line_7)


        self.verticalLayout_15.addLayout(self.verticalLayout_6)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(-1, 0, -1, -1)
        self.scrollArea = QScrollArea(self.frame_4)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 98, 902))
        self.verticalLayout_20 = QVBoxLayout(self.scrollAreaWidgetContents)
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.TextoLastNews = QLabel(self.scrollAreaWidgetContents)
        self.TextoLastNews.setObjectName(u"TextoLastNews")
        self.TextoLastNews.setFont(font1)
        self.TextoLastNews.setStyleSheet(u"color: black;\n"
"text-align: center;\n"
"")
        self.TextoLastNews.setFrameShadow(QFrame.Shadow.Plain)
        self.TextoLastNews.setTextFormat(Qt.TextFormat.PlainText)
        self.TextoLastNews.setScaledContents(False)
        self.TextoLastNews.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)
        self.TextoLastNews.setWordWrap(True)

        self.verticalLayout_20.addWidget(self.TextoLastNews)

        self.scrollArea.setWidget(self.scrollAreaWidgetContents)

        self.verticalLayout_2.addWidget(self.scrollArea)


        self.verticalLayout_15.addLayout(self.verticalLayout_2)

        self.verticalSpacer_7 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_15.addItem(self.verticalSpacer_7)

        self.horizontalLayout_40 = QHBoxLayout()
        self.horizontalLayout_40.setObjectName(u"horizontalLayout_40")
        self.horizontalSpacer_29 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_40.addItem(self.horizontalSpacer_29)

        self.TitleLastNews_2 = QLabel(self.frame_4)
        self.TitleLastNews_2.setObjectName(u"TitleLastNews_2")
        self.TitleLastNews_2.setStyleSheet(u"color: red;\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid red;")
        self.TitleLastNews_2.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_40.addWidget(self.TitleLastNews_2)

        self.horizontalSpacer_30 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_40.addItem(self.horizontalSpacer_30)


        self.verticalLayout_15.addLayout(self.horizontalLayout_40)

        self.verticalLayout_7 = QVBoxLayout()
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(-1, 0, -1, -1)
        self.line_9 = QFrame(self.frame_4)
        self.line_9.setObjectName(u"line_9")
        self.line_9.setAutoFillBackground(False)
        self.line_9.setStyleSheet(u"color: red;\n"
"")
        self.line_9.setFrameShadow(QFrame.Shadow.Plain)
        self.line_9.setLineWidth(2)
        self.line_9.setMidLineWidth(2)
        self.line_9.setFrameShape(QFrame.Shape.HLine)

        self.verticalLayout_7.addWidget(self.line_9)


        self.verticalLayout_15.addLayout(self.verticalLayout_7)

        self.verticalLayout_8 = QVBoxLayout()
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(-1, 0, -1, -1)
        self.scrollArea_4 = QScrollArea(self.frame_4)
        self.scrollArea_4.setObjectName(u"scrollArea_4")
        self.scrollArea_4.setWidgetResizable(True)
        self.scrollAreaWidgetContents_4 = QWidget()
        self.scrollAreaWidgetContents_4.setObjectName(u"scrollAreaWidgetContents_4")
        self.scrollAreaWidgetContents_4.setGeometry(QRect(0, 0, 98, 902))
        self.verticalLayout_18 = QVBoxLayout(self.scrollAreaWidgetContents_4)
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.TextoLastNews_3 = QLabel(self.scrollAreaWidgetContents_4)
        self.TextoLastNews_3.setObjectName(u"TextoLastNews_3")
        self.TextoLastNews_3.setFont(font1)
        self.TextoLastNews_3.setStyleSheet(u"color: black;\n"
"text-align: center;\n"
"")
        self.TextoLastNews_3.setFrameShadow(QFrame.Shadow.Plain)
        self.TextoLastNews_3.setTextFormat(Qt.TextFormat.PlainText)
        self.TextoLastNews_3.setScaledContents(False)
        self.TextoLastNews_3.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)
        self.TextoLastNews_3.setWordWrap(True)

        self.verticalLayout_18.addWidget(self.TextoLastNews_3)

        self.scrollArea_4.setWidget(self.scrollAreaWidgetContents_4)

        self.verticalLayout_8.addWidget(self.scrollArea_4)


        self.verticalLayout_15.addLayout(self.verticalLayout_8)

        self.verticalLayout_15.setStretch(0, 1)
        self.verticalLayout_15.setStretch(4, 1)
        self.verticalLayout_15.setStretch(5, 1)
        self.verticalLayout_15.setStretch(8, 1)

        self.verticalLayout_22.addWidget(self.frame_4)


        self.horizontalLayout_72.addLayout(self.verticalLayout_22)

        self.horizontalLayout_72.setStretch(0, 5)
        self.horizontalLayout_72.setStretch(1, 1)

        self.horizontalLayout_10.addLayout(self.horizontalLayout_72)

        self.stackedWidget.addWidget(self.Status)
        self.Sectors = QWidget()
        self.Sectors.setObjectName(u"Sectors")
        self.horizontalLayout_69 = QHBoxLayout(self.Sectors)
        self.horizontalLayout_69.setObjectName(u"horizontalLayout_69")
        self.horizontalLayout_59 = QHBoxLayout()
        self.horizontalLayout_59.setObjectName(u"horizontalLayout_59")
        self.LastNewsPanel_7 = QFrame(self.Sectors)
        self.LastNewsPanel_7.setObjectName(u"LastNewsPanel_7")
        sizePolicy4.setHeightForWidth(self.LastNewsPanel_7.sizePolicy().hasHeightForWidth())
        self.LastNewsPanel_7.setSizePolicy(sizePolicy4)
        self.LastNewsPanel_7.setMinimumSize(QSize(0, 88))
        self.LastNewsPanel_7.setMaximumSize(QSize(10000, 10000))
        self.LastNewsPanel_7.setAutoFillBackground(False)
        self.LastNewsPanel_7.setStyleSheet(u"QFrame#LastNewsPanel_7{\n"
"	border-image: url(:/login/vista-aerea-techo-gran-centro-comercial.png);\n"
"}")
        self.LastNewsPanel_7.setFrameShape(QFrame.Shape.NoFrame)
        self.LastNewsPanel_7.setFrameShadow(QFrame.Shadow.Plain)
        self.gridLayout_9 = QGridLayout(self.LastNewsPanel_7)
        self.gridLayout_9.setSpacing(6)
        self.gridLayout_9.setObjectName(u"gridLayout_9")
        self.gridLayout_9.setContentsMargins(6, 6, 6, 6)
        self.horizontalLayout_65 = QHBoxLayout()
        self.horizontalLayout_65.setObjectName(u"horizontalLayout_65")
        self.Sector6_5 = QPushButton(self.LastNewsPanel_7)
        self.Sector6_5.setObjectName(u"Sector6_5")
        self.Sector6_5.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector6_5.setCheckable(False)
        self.Sector6_5.setChecked(False)

        self.horizontalLayout_65.addWidget(self.Sector6_5)

        self.check6_5 = QLabel(self.LastNewsPanel_7)
        self.check6_5.setObjectName(u"check6_5")
        sizePolicy5.setHeightForWidth(self.check6_5.sizePolicy().hasHeightForWidth())
        self.check6_5.setSizePolicy(sizePolicy5)
        self.check6_5.setMinimumSize(QSize(40, 10))
        self.check6_5.setStyleSheet(u"background-color: transparent;")
        self.check6_5.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check6_5.setScaledContents(True)

        self.horizontalLayout_65.addWidget(self.check6_5)


        self.gridLayout_9.addLayout(self.horizontalLayout_65, 0, 5, 1, 1)

        self.horizontalSpacer_44 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_9.addItem(self.horizontalSpacer_44, 8, 2, 1, 1)

        self.verticalSpacer_89 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_89, 4, 1, 1, 1)

        self.verticalSpacer_80 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_80, 5, 5, 1, 1)

        self.verticalSpacer_85 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_85, 14, 5, 1, 1)

        self.verticalSpacer_92 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_92, 9, 3, 1, 1)

        self.horizontalLayout_64 = QHBoxLayout()
        self.horizontalLayout_64.setObjectName(u"horizontalLayout_64")
        self.Sector2_5 = QPushButton(self.LastNewsPanel_7)
        self.Sector2_5.setObjectName(u"Sector2_5")
        self.Sector2_5.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector2_5.setCheckable(False)
        self.Sector2_5.setChecked(False)

        self.horizontalLayout_64.addWidget(self.Sector2_5)

        self.check2_5 = QLabel(self.LastNewsPanel_7)
        self.check2_5.setObjectName(u"check2_5")
        sizePolicy5.setHeightForWidth(self.check2_5.sizePolicy().hasHeightForWidth())
        self.check2_5.setSizePolicy(sizePolicy5)
        self.check2_5.setMinimumSize(QSize(40, 10))
        self.check2_5.setStyleSheet(u"background-color: transparent;")
        self.check2_5.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check2_5.setScaledContents(True)

        self.horizontalLayout_64.addWidget(self.check2_5)


        self.gridLayout_9.addLayout(self.horizontalLayout_64, 8, 3, 1, 1)

        self.verticalSpacer_95 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_95, 3, 3, 1, 1)

        self.horizontalLayout_62 = QHBoxLayout()
        self.horizontalLayout_62.setObjectName(u"horizontalLayout_62")
        self.Sector1_6 = QPushButton(self.LastNewsPanel_7)
        self.Sector1_6.setObjectName(u"Sector1_6")
        self.Sector1_6.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector1_6.setCheckable(False)
        self.Sector1_6.setChecked(False)

        self.horizontalLayout_62.addWidget(self.Sector1_6)

        self.check1_5 = QLabel(self.LastNewsPanel_7)
        self.check1_5.setObjectName(u"check1_5")
        sizePolicy5.setHeightForWidth(self.check1_5.sizePolicy().hasHeightForWidth())
        self.check1_5.setSizePolicy(sizePolicy5)
        self.check1_5.setMinimumSize(QSize(40, 10))
        self.check1_5.setStyleSheet(u"background-color: transparent;")
        self.check1_5.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check1_5.setScaledContents(True)

        self.horizontalLayout_62.addWidget(self.check1_5)


        self.gridLayout_9.addLayout(self.horizontalLayout_62, 2, 1, 1, 1)

        self.horizontalSpacer_48 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_9.addItem(self.horizontalSpacer_48, 6, 8, 1, 1)

        self.verticalSpacer_84 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_84, 11, 7, 1, 1)

        self.verticalSpacer_83 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_83, 10, 1, 1, 1)

        self.verticalSpacer_87 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_87, 6, 1, 1, 1)

        self.verticalSpacer_88 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_88, 7, 7, 1, 1)

        self.horizontalSpacer_47 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_9.addItem(self.horizontalSpacer_47, 4, 0, 1, 1)

        self.verticalSpacer_90 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_90, 13, 1, 1, 1)

        self.verticalSpacer_86 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_86, 2, 3, 1, 1)

        self.horizontalLayout_66 = QHBoxLayout()
        self.horizontalLayout_66.setObjectName(u"horizontalLayout_66")
        self.Sector3_5 = QPushButton(self.LastNewsPanel_7)
        self.Sector3_5.setObjectName(u"Sector3_5")
        self.Sector3_5.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector3_5.setCheckable(False)
        self.Sector3_5.setChecked(False)

        self.horizontalLayout_66.addWidget(self.Sector3_5)

        self.check3_5 = QLabel(self.LastNewsPanel_7)
        self.check3_5.setObjectName(u"check3_5")
        sizePolicy5.setHeightForWidth(self.check3_5.sizePolicy().hasHeightForWidth())
        self.check3_5.setSizePolicy(sizePolicy5)
        self.check3_5.setMinimumSize(QSize(40, 10))
        self.check3_5.setStyleSheet(u"background-color: transparent;")
        self.check3_5.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check3_5.setScaledContents(True)

        self.horizontalLayout_66.addWidget(self.check3_5)


        self.gridLayout_9.addLayout(self.horizontalLayout_66, 15, 1, 1, 1)

        self.verticalSpacer_96 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_96, 1, 5, 1, 1)

        self.verticalSpacer_94 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_94, 16, 1, 1, 1)

        self.horizontalSpacer_46 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_9.addItem(self.horizontalSpacer_46, 13, 4, 1, 1)

        self.verticalSpacer_91 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_91, 12, 1, 1, 1)

        self.horizontalLayout_61 = QHBoxLayout()
        self.horizontalLayout_61.setObjectName(u"horizontalLayout_61")
        self.Sector4_5 = QPushButton(self.LastNewsPanel_7)
        self.Sector4_5.setObjectName(u"Sector4_5")
        self.Sector4_5.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector4_5.setCheckable(False)
        self.Sector4_5.setChecked(False)

        self.horizontalLayout_61.addWidget(self.Sector4_5)

        self.check4_5 = QLabel(self.LastNewsPanel_7)
        self.check4_5.setObjectName(u"check4_5")
        sizePolicy5.setHeightForWidth(self.check4_5.sizePolicy().hasHeightForWidth())
        self.check4_5.setSizePolicy(sizePolicy5)
        self.check4_5.setMinimumSize(QSize(40, 10))
        self.check4_5.setStyleSheet(u"background-color: transparent;")
        self.check4_5.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check4_5.setScaledContents(True)

        self.horizontalLayout_61.addWidget(self.check4_5)


        self.gridLayout_9.addLayout(self.horizontalLayout_61, 13, 5, 1, 1)

        self.verticalSpacer_81 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_81, 0, 1, 1, 1)

        self.horizontalLayout_63 = QHBoxLayout()
        self.horizontalLayout_63.setObjectName(u"horizontalLayout_63")
        self.Sector7_17 = QPushButton(self.LastNewsPanel_7)
        self.Sector7_17.setObjectName(u"Sector7_17")
        self.Sector7_17.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_17.setCheckable(False)
        self.Sector7_17.setChecked(False)

        self.horizontalLayout_63.addWidget(self.Sector7_17)

        self.check7_5 = QLabel(self.LastNewsPanel_7)
        self.check7_5.setObjectName(u"check7_5")
        sizePolicy5.setHeightForWidth(self.check7_5.sizePolicy().hasHeightForWidth())
        self.check7_5.setSizePolicy(sizePolicy5)
        self.check7_5.setMinimumSize(QSize(40, 0))
        self.check7_5.setStyleSheet(u"background-color: transparent;")
        self.check7_5.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check7_5.setScaledContents(True)

        self.horizontalLayout_63.addWidget(self.check7_5)


        self.gridLayout_9.addLayout(self.horizontalLayout_63, 6, 7, 1, 1)

        self.horizontalSpacer_45 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.gridLayout_9.addItem(self.horizontalSpacer_45, 6, 6, 1, 1)

        self.verticalSpacer_82 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_82, 15, 3, 1, 1)

        self.verticalSpacer_93 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.gridLayout_9.addItem(self.verticalSpacer_93, 8, 1, 1, 1)

        self.horizontalLayout_60 = QHBoxLayout()
        self.horizontalLayout_60.setObjectName(u"horizontalLayout_60")
        self.Sector5_5 = QPushButton(self.LastNewsPanel_7)
        self.Sector5_5.setObjectName(u"Sector5_5")
        self.Sector5_5.setStyleSheet(u"QPushButton {\n"
"background-color: #4DBCEB; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 12pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector5_5.setCheckable(False)
        self.Sector5_5.setChecked(False)

        self.horizontalLayout_60.addWidget(self.Sector5_5)

        self.check5_5 = QLabel(self.LastNewsPanel_7)
        self.check5_5.setObjectName(u"check5_5")
        sizePolicy5.setHeightForWidth(self.check5_5.sizePolicy().hasHeightForWidth())
        self.check5_5.setSizePolicy(sizePolicy5)
        self.check5_5.setMinimumSize(QSize(40, 10))
        self.check5_5.setStyleSheet(u"background-color: transparent;")
        self.check5_5.setPixmap(QPixmap(u":/login/tick 1.png"))
        self.check5_5.setScaledContents(True)

        self.horizontalLayout_60.addWidget(self.check5_5)


        self.gridLayout_9.addLayout(self.horizontalLayout_60, 4, 5, 1, 1)


        self.horizontalLayout_59.addWidget(self.LastNewsPanel_7)


        self.horizontalLayout_69.addLayout(self.horizontalLayout_59)

        self.verticalLayout_14 = QVBoxLayout()
        self.verticalLayout_14.setSpacing(0)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.verticalLayout_14.setContentsMargins(-1, -1, 0, -1)
        self.frame_5 = QFrame(self.Sectors)
        self.frame_5.setObjectName(u"frame_5")
        self.frame_5.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_5.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_16 = QVBoxLayout(self.frame_5)
        self.verticalLayout_16.setSpacing(2)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.verticalLayout_16.setContentsMargins(0, 0, 0, 0)
        self.Sector1_7 = QPushButton(self.frame_5)
        self.Sector1_7.setObjectName(u"Sector1_7")
        self.Sector1_7.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 9pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector1_7.setCheckable(False)
        self.Sector1_7.setChecked(False)

        self.verticalLayout_16.addWidget(self.Sector1_7)

        self.verticalSpacer_3 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_16.addItem(self.verticalSpacer_3)

        self.horizontalLayout_70 = QHBoxLayout()
        self.horizontalLayout_70.setObjectName(u"horizontalLayout_70")
        self.horizontalSpacer_13 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_70.addItem(self.horizontalSpacer_13)

        self.TitleLastNews_7 = QLabel(self.frame_5)
        self.TitleLastNews_7.setObjectName(u"TitleLastNews_7")
        self.TitleLastNews_7.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.TitleLastNews_7.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_70.addWidget(self.TitleLastNews_7)

        self.horizontalSpacer_14 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_70.addItem(self.horizontalSpacer_14)


        self.verticalLayout_16.addLayout(self.horizontalLayout_70)

        self.line_12 = QFrame(self.frame_5)
        self.line_12.setObjectName(u"line_12")
        self.line_12.setAutoFillBackground(False)
        self.line_12.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"")
        self.line_12.setFrameShadow(QFrame.Shadow.Plain)
        self.line_12.setLineWidth(2)
        self.line_12.setMidLineWidth(2)
        self.line_12.setFrameShape(QFrame.Shape.HLine)

        self.verticalLayout_16.addWidget(self.line_12)

        self.verticalLayout_17 = QVBoxLayout()
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.scrollArea_9 = QScrollArea(self.frame_5)
        self.scrollArea_9.setObjectName(u"scrollArea_9")
        self.scrollArea_9.setWidgetResizable(True)
        self.scrollAreaWidgetContents_9 = QWidget()
        self.scrollAreaWidgetContents_9.setObjectName(u"scrollAreaWidgetContents_9")
        self.scrollAreaWidgetContents_9.setGeometry(QRect(0, 0, 119, 113))
        self.verticalLayout_27 = QVBoxLayout(self.scrollAreaWidgetContents_9)
        self.verticalLayout_27.setSpacing(0)
        self.verticalLayout_27.setObjectName(u"verticalLayout_27")
        self.verticalLayout_27.setContentsMargins(0, 0, 0, 0)
        self.TitleLastNews_9 = QLabel(self.scrollAreaWidgetContents_9)
        self.TitleLastNews_9.setObjectName(u"TitleLastNews_9")
        self.TitleLastNews_9.setStyleSheet(u"color: black;\n"
"font: bold 13px \"Segoe UI\";")
        self.TitleLastNews_9.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_27.addWidget(self.TitleLastNews_9)

        self.TextoLastNews_8 = QLabel(self.scrollAreaWidgetContents_9)
        self.TextoLastNews_8.setObjectName(u"TextoLastNews_8")
        self.TextoLastNews_8.setFont(font1)
        self.TextoLastNews_8.setStyleSheet(u"color: black;\n"
"text-align: center;\n"
"")
        self.TextoLastNews_8.setFrameShadow(QFrame.Shadow.Plain)
        self.TextoLastNews_8.setTextFormat(Qt.TextFormat.PlainText)
        self.TextoLastNews_8.setScaledContents(False)
        self.TextoLastNews_8.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)
        self.TextoLastNews_8.setWordWrap(True)

        self.verticalLayout_27.addWidget(self.TextoLastNews_8)

        self.TextoLastNews_6 = QLabel(self.scrollAreaWidgetContents_9)
        self.TextoLastNews_6.setObjectName(u"TextoLastNews_6")
        self.TextoLastNews_6.setFont(font1)
        self.TextoLastNews_6.setStyleSheet(u"color: black;\n"
"text-align: center;\n"
"")
        self.TextoLastNews_6.setFrameShadow(QFrame.Shadow.Plain)
        self.TextoLastNews_6.setTextFormat(Qt.TextFormat.PlainText)
        self.TextoLastNews_6.setScaledContents(False)
        self.TextoLastNews_6.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)
        self.TextoLastNews_6.setWordWrap(True)

        self.verticalLayout_27.addWidget(self.TextoLastNews_6)

        self.scrollArea_9.setWidget(self.scrollAreaWidgetContents_9)

        self.verticalLayout_17.addWidget(self.scrollArea_9)


        self.verticalLayout_16.addLayout(self.verticalLayout_17)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_16.addItem(self.verticalSpacer)

        self.horizontalLayout_71 = QHBoxLayout()
        self.horizontalLayout_71.setObjectName(u"horizontalLayout_71")
        self.horizontalSpacer_49 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_71.addItem(self.horizontalSpacer_49)

        self.TitleLastNews_8 = QLabel(self.frame_5)
        self.TitleLastNews_8.setObjectName(u"TitleLastNews_8")
        self.TitleLastNews_8.setStyleSheet(u"color: red;\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid red;")
        self.TitleLastNews_8.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_71.addWidget(self.TitleLastNews_8)

        self.horizontalSpacer_50 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_71.addItem(self.horizontalSpacer_50)


        self.verticalLayout_16.addLayout(self.horizontalLayout_71)

        self.line_13 = QFrame(self.frame_5)
        self.line_13.setObjectName(u"line_13")
        self.line_13.setAutoFillBackground(False)
        self.line_13.setStyleSheet(u"color: red;\n"
"")
        self.line_13.setFrameShadow(QFrame.Shadow.Plain)
        self.line_13.setLineWidth(2)
        self.line_13.setMidLineWidth(2)
        self.line_13.setFrameShape(QFrame.Shape.HLine)

        self.verticalLayout_16.addWidget(self.line_13)

        self.scrollArea_8 = QScrollArea(self.frame_5)
        self.scrollArea_8.setObjectName(u"scrollArea_8")
        self.scrollArea_8.setWidgetResizable(True)
        self.scrollAreaWidgetContents_8 = QWidget()
        self.scrollAreaWidgetContents_8.setObjectName(u"scrollAreaWidgetContents_8")
        self.scrollAreaWidgetContents_8.setGeometry(QRect(0, 0, 62, 928))
        self.verticalLayout_28 = QVBoxLayout(self.scrollAreaWidgetContents_8)
        self.verticalLayout_28.setObjectName(u"verticalLayout_28")
        self.verticalLayout_28.setContentsMargins(0, 0, 0, 0)
        self.TextoLastNews_7 = QLabel(self.scrollAreaWidgetContents_8)
        self.TextoLastNews_7.setObjectName(u"TextoLastNews_7")
        self.TextoLastNews_7.setFont(font1)
        self.TextoLastNews_7.setStyleSheet(u"color: black;\n"
"text-align: center;\n"
"")
        self.TextoLastNews_7.setFrameShadow(QFrame.Shadow.Plain)
        self.TextoLastNews_7.setTextFormat(Qt.TextFormat.PlainText)
        self.TextoLastNews_7.setScaledContents(False)
        self.TextoLastNews_7.setAlignment(Qt.AlignmentFlag.AlignHCenter|Qt.AlignmentFlag.AlignTop)
        self.TextoLastNews_7.setWordWrap(True)

        self.verticalLayout_28.addWidget(self.TextoLastNews_7)

        self.scrollArea_8.setWidget(self.scrollAreaWidgetContents_8)

        self.verticalLayout_16.addWidget(self.scrollArea_8)

        self.verticalLayout_16.setStretch(1, 1)
        self.verticalLayout_16.setStretch(4, 1)
        self.verticalLayout_16.setStretch(5, 1)
        self.verticalLayout_16.setStretch(8, 1)

        self.verticalLayout_14.addWidget(self.frame_5)


        self.horizontalLayout_69.addLayout(self.verticalLayout_14)

        self.horizontalLayout_69.setStretch(0, 5)
        self.stackedWidget.addWidget(self.Sectors)
        self.Profile = QWidget()
        self.Profile.setObjectName(u"Profile")
        self.horizontalLayout_67 = QHBoxLayout(self.Profile)
        self.horizontalLayout_67.setObjectName(u"horizontalLayout_67")
        self.LastNewsPanel_5 = QFrame(self.Profile)
        self.LastNewsPanel_5.setObjectName(u"LastNewsPanel_5")
        self.LastNewsPanel_5.setFrameShape(QFrame.Shape.NoFrame)
        self.LastNewsPanel_5.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_19 = QVBoxLayout(self.LastNewsPanel_5)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.horizontalLayout_8 = QHBoxLayout()
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.horizontalLayout_8.setContentsMargins(-1, 0, 0, -1)
        self.scrollArea_2 = QScrollArea(self.LastNewsPanel_5)
        self.scrollArea_2.setObjectName(u"scrollArea_2")
        self.scrollArea_2.setStyleSheet(u"")
        self.scrollArea_2.setFrameShape(QFrame.Shape.NoFrame)
        self.scrollArea_2.setFrameShadow(QFrame.Shadow.Plain)
        self.scrollArea_2.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scrollArea_2.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scrollArea_2.setWidgetResizable(True)
        self.scrollAreaWidgetContents_2 = QWidget()
        self.scrollAreaWidgetContents_2.setObjectName(u"scrollAreaWidgetContents_2")
        self.scrollAreaWidgetContents_2.setGeometry(QRect(0, 0, 100, 500))
        self.scrollAreaWidgetContents_2.setMinimumSize(QSize(100, 500))
        self.scrollAreaWidgetContents_2.setStyleSheet(u"")
        self.verticalLayout_24 = QVBoxLayout(self.scrollAreaWidgetContents_2)
        self.verticalLayout_24.setObjectName(u"verticalLayout_24")
        self.Title_4 = QLabel(self.scrollAreaWidgetContents_2)
        self.Title_4.setObjectName(u"Title_4")
        self.Title_4.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_4.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_24.addWidget(self.Title_4)

        self.Sector7_2 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_2.setObjectName(u"Sector7_2")
        self.Sector7_2.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_2.setCheckable(False)
        self.Sector7_2.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_2)

        self.verticalSpacer_5 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_24.addItem(self.verticalSpacer_5)

        self.Title_5 = QLabel(self.scrollAreaWidgetContents_2)
        self.Title_5.setObjectName(u"Title_5")
        self.Title_5.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_5.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_24.addWidget(self.Title_5)

        self.Sector7_4 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_4.setObjectName(u"Sector7_4")
        self.Sector7_4.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_4.setCheckable(False)
        self.Sector7_4.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_4)

        self.Sector7_3 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_3.setObjectName(u"Sector7_3")
        self.Sector7_3.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_3.setCheckable(False)
        self.Sector7_3.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_3)

        self.Sector7_5 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_5.setObjectName(u"Sector7_5")
        self.Sector7_5.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_5.setCheckable(False)
        self.Sector7_5.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_5)

        self.verticalSpacer_6 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_24.addItem(self.verticalSpacer_6)

        self.Title_6 = QLabel(self.scrollAreaWidgetContents_2)
        self.Title_6.setObjectName(u"Title_6")
        self.Title_6.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_6.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_24.addWidget(self.Title_6)

        self.Sector7_6 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_6.setObjectName(u"Sector7_6")
        self.Sector7_6.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_6.setCheckable(False)
        self.Sector7_6.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_6)

        self.Sector7_8 = QPushButton(self.scrollAreaWidgetContents_2)
        self.Sector7_8.setObjectName(u"Sector7_8")
        self.Sector7_8.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_8.setCheckable(False)
        self.Sector7_8.setChecked(False)

        self.verticalLayout_24.addWidget(self.Sector7_8)

        self.verticalLayout_24.setStretch(1, 1)
        self.verticalLayout_24.setStretch(4, 1)
        self.verticalLayout_24.setStretch(5, 1)
        self.verticalLayout_24.setStretch(6, 1)
        self.verticalLayout_24.setStretch(9, 1)
        self.verticalLayout_24.setStretch(10, 1)
        self.scrollArea_2.setWidget(self.scrollAreaWidgetContents_2)

        self.horizontalLayout_8.addWidget(self.scrollArea_2)

        self.verticalLayout_13 = QVBoxLayout()
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.verticalLayout_13.setSizeConstraint(QLayout.SizeConstraint.SetNoConstraint)
        self.verticalLayout_13.setContentsMargins(-1, -1, 25, -1)
        self.Title_8 = QLabel(self.LastNewsPanel_5)
        self.Title_8.setObjectName(u"Title_8")
        self.Title_8.setStyleSheet(u"color: grey;\n"
"font: bold 23px \"Segoe UI\";\n"
"border-bottom: 2px solid grey;")
        self.Title_8.setAlignment(Qt.AlignmentFlag.AlignLeading|Qt.AlignmentFlag.AlignLeft|Qt.AlignmentFlag.AlignVCenter)

        self.verticalLayout_13.addWidget(self.Title_8)

        self.lineEdit = QLineEdit(self.LastNewsPanel_5)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setStyleSheet(u"QLineEdit {\n"
"    /* Fondo gris claro, similar al de la imagen */\n"
"    background-color: #F0F0F0; \n"
"    \n"
"    /* Bordes redondeados */\n"
"    border-radius: 15px; /* Ajusta este valor para la curvatura deseada */\n"
"    \n"
"    /* Borde sutil (opcional, si el widget principal tiene otro color) */\n"
"    border: 1px solid #D0D0D0;\n"
"    \n"
"    /* Espaciado interno para que el texto no toque los bordes */\n"
"    padding: 5px 35px 5px 10px; /* Arriba Der. Abajo Izq. (Deja espacio a la derecha para el \u00edcono) */\n"
"\n"
"    /* Fuente y color del texto (opcional) */\n"
"    font-size: 12pt;\n"
"    color: #555555;\n"
"}")

        self.verticalLayout_13.addWidget(self.lineEdit)

        self.scrollArea_3 = QScrollArea(self.LastNewsPanel_5)
        self.scrollArea_3.setObjectName(u"scrollArea_3")
        sizePolicy.setHeightForWidth(self.scrollArea_3.sizePolicy().hasHeightForWidth())
        self.scrollArea_3.setSizePolicy(sizePolicy)
        self.scrollArea_3.setStyleSheet(u"")
        self.scrollArea_3.setFrameShape(QFrame.Shape.NoFrame)
        self.scrollArea_3.setFrameShadow(QFrame.Shadow.Plain)
        self.scrollArea_3.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scrollArea_3.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scrollArea_3.setSizeAdjustPolicy(QAbstractScrollArea.SizeAdjustPolicy.AdjustIgnored)
        self.scrollArea_3.setWidgetResizable(True)
        self.scrollAreaWidgetContents_3 = QWidget()
        self.scrollAreaWidgetContents_3.setObjectName(u"scrollAreaWidgetContents_3")
        self.scrollAreaWidgetContents_3.setGeometry(QRect(0, 0, 100, 1000))
        self.scrollAreaWidgetContents_3.setMinimumSize(QSize(100, 1000))
        self.scrollAreaWidgetContents_3.setStyleSheet(u"")
        self.verticalLayout_25 = QVBoxLayout(self.scrollAreaWidgetContents_3)
        self.verticalLayout_25.setObjectName(u"verticalLayout_25")
        self.verticalLayout_25.setSizeConstraint(QLayout.SizeConstraint.SetNoConstraint)
        self.scrollArea_3.setWidget(self.scrollAreaWidgetContents_3)

        self.verticalLayout_13.addWidget(self.scrollArea_3)


        self.horizontalLayout_8.addLayout(self.verticalLayout_13)

        self.horizontalLayout_8.setStretch(0, 1)
        self.horizontalLayout_8.setStretch(1, 5)

        self.verticalLayout_19.addLayout(self.horizontalLayout_8)


        self.horizontalLayout_67.addWidget(self.LastNewsPanel_5)

        self.horizontalLayout_67.setStretch(0, 1)
        self.stackedWidget.addWidget(self.Profile)
        self.Chat = QWidget()
        self.Chat.setObjectName(u"Chat")
        self.horizontalLayout_24 = QHBoxLayout(self.Chat)
        self.horizontalLayout_24.setObjectName(u"horizontalLayout_24")
        self.scrollArea_12 = QScrollArea(self.Chat)
        self.scrollArea_12.setObjectName(u"scrollArea_12")
        self.scrollArea_12.setStyleSheet(u"")
        self.scrollArea_12.setFrameShape(QFrame.Shape.NoFrame)
        self.scrollArea_12.setFrameShadow(QFrame.Shadow.Plain)
        self.scrollArea_12.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.scrollArea_12.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.scrollArea_12.setWidgetResizable(True)
        self.scrollAreaWidgetContents_12 = QWidget()
        self.scrollAreaWidgetContents_12.setObjectName(u"scrollAreaWidgetContents_12")
        self.scrollAreaWidgetContents_12.setGeometry(QRect(0, 0, 117, 500))
        self.scrollAreaWidgetContents_12.setMinimumSize(QSize(100, 500))
        self.scrollAreaWidgetContents_12.setStyleSheet(u"")
        self.verticalLayout_32 = QVBoxLayout(self.scrollAreaWidgetContents_12)
        self.verticalLayout_32.setObjectName(u"verticalLayout_32")
        self.Title_13 = QLabel(self.scrollAreaWidgetContents_12)
        self.Title_13.setObjectName(u"Title_13")
        self.Title_13.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_13.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_32.addWidget(self.Title_13)

        self.verticalSpacer_10 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_32.addItem(self.verticalSpacer_10)

        self.Sector7_15 = QPushButton(self.scrollAreaWidgetContents_12)
        self.Sector7_15.setObjectName(u"Sector7_15")
        self.Sector7_15.setStyleSheet(u"QPushButton {\n"
"background-color: #0094C9; \n"
"    color: white;            \n"
"    border-radius: 10px;     \n"
"    padding: 5px 10px;   \n"
"    font-size: 10pt;         \n"
"    font-weight: bold;  \n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    border-bottom: 2px solid rgb(0, 191, 255);\n"
"    color: white;\n"
"}")
        self.Sector7_15.setCheckable(False)
        self.Sector7_15.setChecked(False)

        self.verticalLayout_32.addWidget(self.Sector7_15)

        self.verticalLayout_32.setStretch(0, 1)
        self.verticalLayout_32.setStretch(1, 20)
        self.verticalLayout_32.setStretch(2, 1)
        self.scrollArea_12.setWidget(self.scrollAreaWidgetContents_12)

        self.horizontalLayout_24.addWidget(self.scrollArea_12)

        self.stackedWidget_2 = QStackedWidget(self.Chat)
        self.stackedWidget_2.setObjectName(u"stackedWidget_2")
        self.NOCHAT = QWidget()
        self.NOCHAT.setObjectName(u"NOCHAT")
        self.verticalLayout_33 = QVBoxLayout(self.NOCHAT)
        self.verticalLayout_33.setObjectName(u"verticalLayout_33")
        self.verticalLayout_33.setContentsMargins(0, 0, 0, 0)
        self.verticalSpacer_46 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_33.addItem(self.verticalSpacer_46)

        self.horizontalLayout_25 = QHBoxLayout()
        self.horizontalLayout_25.setObjectName(u"horizontalLayout_25")
        self.label_2 = QLabel(self.NOCHAT)
        self.label_2.setObjectName(u"label_2")
        sizePolicy1.setHeightForWidth(self.label_2.sizePolicy().hasHeightForWidth())
        self.label_2.setSizePolicy(sizePolicy1)
        self.label_2.setMinimumSize(QSize(80, 80))
        self.label_2.setMaximumSize(QSize(150, 150))
        self.label_2.setSizeIncrement(QSize(1, 1))
        self.label_2.setLayoutDirection(Qt.LayoutDirection.LeftToRight)
        self.label_2.setAutoFillBackground(False)
        self.label_2.setStyleSheet(u"QLabel{\n"
"background-color: transparent; \n"
"    border: none; /* A veces el borde a\u00f1ade color */\n"
"}")
        self.label_2.setPixmap(QPixmap(u":/login/Check-it 1.png"))
        self.label_2.setScaledContents(True)
        self.label_2.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_2.setIndent(0)

        self.horizontalLayout_25.addWidget(self.label_2)


        self.verticalLayout_33.addLayout(self.horizontalLayout_25)

        self.label_3 = QLabel(self.NOCHAT)
        self.label_3.setObjectName(u"label_3")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)
        sizePolicy6.setHorizontalStretch(0)
        sizePolicy6.setVerticalStretch(0)
        sizePolicy6.setHeightForWidth(self.label_3.sizePolicy().hasHeightForWidth())
        self.label_3.setSizePolicy(sizePolicy6)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet(u"    color: rgb(0, 191, 255);")
        self.label_3.setTextFormat(Qt.TextFormat.AutoText)
        self.label_3.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.verticalLayout_33.addWidget(self.label_3)

        self.verticalSpacer_47 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_33.addItem(self.verticalSpacer_47)

        self.stackedWidget_2.addWidget(self.NOCHAT)
        self.CHAT = QWidget()
        self.CHAT.setObjectName(u"CHAT")
        self.verticalLayout_29 = QVBoxLayout(self.CHAT)
        self.verticalLayout_29.setObjectName(u"verticalLayout_29")
        self.verticalLayout_29.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_26 = QHBoxLayout()
        self.horizontalLayout_26.setObjectName(u"horizontalLayout_26")
        self.label_5 = QLabel(self.CHAT)
        self.label_5.setObjectName(u"label_5")
        sizePolicy1.setHeightForWidth(self.label_5.sizePolicy().hasHeightForWidth())
        self.label_5.setSizePolicy(sizePolicy1)
        self.label_5.setMaximumSize(QSize(50, 50))
        self.label_5.setPixmap(QPixmap(u":/login/Check-it 1.png"))
        self.label_5.setScaledContents(True)

        self.horizontalLayout_26.addWidget(self.label_5)

        self.Title_14 = QLabel(self.CHAT)
        self.Title_14.setObjectName(u"Title_14")
        sizePolicy7 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy7.setHorizontalStretch(0)
        sizePolicy7.setVerticalStretch(0)
        sizePolicy7.setHeightForWidth(self.Title_14.sizePolicy().hasHeightForWidth())
        self.Title_14.setSizePolicy(sizePolicy7)
        self.Title_14.setStyleSheet(u"color: rgb(0, 191, 255);\n"
"font: bold 16px \"Segoe UI\";\n"
"border-bottom: 2px solid rgb(0, 191, 255);")
        self.Title_14.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.horizontalLayout_26.addWidget(self.Title_14)

        self.horizontalSpacer_10 = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.horizontalLayout_26.addItem(self.horizontalSpacer_10)

        self.horizontalLayout_26.setStretch(0, 1)
        self.horizontalLayout_26.setStretch(1, 5)
        self.horizontalLayout_26.setStretch(2, 100)

        self.verticalLayout_29.addLayout(self.horizontalLayout_26)

        self.verticalSpacer_8 = QSpacerItem(20, 351, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.verticalLayout_29.addItem(self.verticalSpacer_8)

        self.horizontalLayout_9 = QHBoxLayout()
        self.horizontalLayout_9.setSpacing(0)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.plainTextEdit = QPlainTextEdit(self.CHAT)
        self.plainTextEdit.setObjectName(u"plainTextEdit")
        sizePolicy8 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Ignored)
        sizePolicy8.setHorizontalStretch(0)
        sizePolicy8.setVerticalStretch(0)
        sizePolicy8.setHeightForWidth(self.plainTextEdit.sizePolicy().hasHeightForWidth())
        self.plainTextEdit.setSizePolicy(sizePolicy8)

        self.horizontalLayout_9.addWidget(self.plainTextEdit)

        self.label_4 = QLabel(self.CHAT)
        self.label_4.setObjectName(u"label_4")
        sizePolicy1.setHeightForWidth(self.label_4.sizePolicy().hasHeightForWidth())
        self.label_4.setSizePolicy(sizePolicy1)
        self.label_4.setMaximumSize(QSize(50, 50))
        self.label_4.setPixmap(QPixmap(u":/login/send.png"))
        self.label_4.setScaledContents(True)

        self.horizontalLayout_9.addWidget(self.label_4)

        self.horizontalLayout_9.setStretch(0, 10)
        self.horizontalLayout_9.setStretch(1, 1)

        self.verticalLayout_29.addLayout(self.horizontalLayout_9)

        self.verticalLayout_29.setStretch(0, 1)
        self.verticalLayout_29.setStretch(1, 100)
        self.verticalLayout_29.setStretch(2, 1)
        self.stackedWidget_2.addWidget(self.CHAT)

        self.horizontalLayout_24.addWidget(self.stackedWidget_2)

        self.horizontalLayout_24.setStretch(0, 1)
        self.horizontalLayout_24.setStretch(1, 5)
        self.stackedWidget.addWidget(self.Chat)

        self.verticalLayout.addWidget(self.stackedWidget)


        self.horizontalLayout.addLayout(self.verticalLayout)

        self.horizontalLayout.setStretch(0, 3)

        self.verticalLayout_3.addLayout(self.horizontalLayout)

        self.verticalLayout_3.setStretch(0, 1)
        self.verticalLayout_3.setStretch(1, 5)

        self.gridLayout.addLayout(self.verticalLayout_3, 0, 0, 1, 1)

        AdministratorWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(AdministratorWindow)

        self.pushButton.setDefault(False)
        self.pushButton_24.setDefault(False)
        self.pushButton_2.setDefault(False)
        self.pushButton_3.setDefault(False)
        self.pushButton_4.setDefault(False)
        self.pushButton_5.setDefault(False)
        self.stackedWidget.setCurrentIndex(0)
        self.pushButton_7.setDefault(False)
        self.pushButton_6.setDefault(False)
        self.pushButton_10.setDefault(False)
        self.pushButton_8.setDefault(False)
        self.pushButton_9.setDefault(False)
        self.pushButton_11.setDefault(False)
        self.pushButton_12.setDefault(False)
        self.pushButton_13.setDefault(False)
        self.pushButton_14.setDefault(False)
        self.pushButton_15.setDefault(False)
        self.pushButton_16.setDefault(False)
        self.pushButton_17.setDefault(False)
        self.pushButton_18.setDefault(False)
        self.pushButton_19.setDefault(False)
        self.pushButton_20.setDefault(False)
        self.pushButton_21.setDefault(False)
        self.pushButton_22.setDefault(False)
        self.pushButton_23.setDefault(False)
        self.stackedWidget_2.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(AdministratorWindow)
    # setupUi

    def retranslateUi(self, AdministratorWindow):
        AdministratorWindow.setWindowTitle(QCoreApplication.translate("AdministratorWindow", u"MainWindow", None))
        self.label.setText("")
        self.pushButton.setText(QCoreApplication.translate("AdministratorWindow", u"Home", None))
        self.pushButton_24.setText(QCoreApplication.translate("AdministratorWindow", u"Chat", None))
        self.pushButton_2.setText(QCoreApplication.translate("AdministratorWindow", u"Status", None))
        self.pushButton_3.setText(QCoreApplication.translate("AdministratorWindow", u"Sensors", None))
        self.pushButton_4.setText(QCoreApplication.translate("AdministratorWindow", u"Market", None))
        self.pushButton_5.setText(QCoreApplication.translate("AdministratorWindow", u"Configuration", None))
        self.Title.setText(QCoreApplication.translate("AdministratorWindow", u"Alerts", None))
        self.New_3.setText(QCoreApplication.translate("AdministratorWindow", u"Smoke detectors are detecting excessive smoke in sector 15. Check for a possible fire. \n"
"If a fire is developing, activate the fire sprinklers.", None))
        self.pushButton_7.setText(QCoreApplication.translate("AdministratorWindow", u"Activate", None))
        self.pushButton_6.setText(QCoreApplication.translate("AdministratorWindow", u"Cancel", None))
        self.Title_7.setText(QCoreApplication.translate("AdministratorWindow", u"Alerts", None))
        self.pushButton_10.setText(QCoreApplication.translate("AdministratorWindow", u"S1:", None))
        self.pushButton_8.setText(QCoreApplication.translate("AdministratorWindow", u"W", None))
        self.pushButton_9.setText(QCoreApplication.translate("AdministratorWindow", u"S2:", None))
        self.pushButton_11.setText(QCoreApplication.translate("AdministratorWindow", u"NW", None))
        self.pushButton_12.setText(QCoreApplication.translate("AdministratorWindow", u"S3:", None))
        self.pushButton_13.setText(QCoreApplication.translate("AdministratorWindow", u"W", None))
        self.pushButton_14.setText(QCoreApplication.translate("AdministratorWindow", u"S4:", None))
        self.pushButton_15.setText(QCoreApplication.translate("AdministratorWindow", u"NW", None))
        self.pushButton_16.setText(QCoreApplication.translate("AdministratorWindow", u"S5:", None))
        self.pushButton_17.setText(QCoreApplication.translate("AdministratorWindow", u"W", None))
        self.pushButton_18.setText(QCoreApplication.translate("AdministratorWindow", u"S6:", None))
        self.pushButton_19.setText(QCoreApplication.translate("AdministratorWindow", u"NW", None))
        self.pushButton_20.setText(QCoreApplication.translate("AdministratorWindow", u"S7:", None))
        self.pushButton_21.setText(QCoreApplication.translate("AdministratorWindow", u"W", None))
        self.pushButton_22.setText(QCoreApplication.translate("AdministratorWindow", u"S8:", None))
        self.pushButton_23.setText(QCoreApplication.translate("AdministratorWindow", u"NW", None))
        self.label_parking.setText(QCoreApplication.translate("AdministratorWindow", u"Plazas de parking disponibles:", None))
        self.Sector5_3.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 5:", None))
        self.check5_2.setText("")
        self.Sector4_3.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 4:", None))
        self.check4_2.setText("")
        self.Sector1_4.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 1:", None))
        self.check1_2.setText("")
        self.Sector7_9.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 7:", None))
        self.check7_2.setText("")
        self.Sector2_3.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 2:", None))
        self.check2_2.setText("")
        self.Sector6_3.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 6:", None))
        self.check6_2.setText("")
        self.Sector3_3.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 3:", None))
        self.check3_2.setText("")
        self.Sector8_3.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 8:", None))
        self.check8_2.setText("")
        self.TitleLastNews_3.setText(QCoreApplication.translate("AdministratorWindow", u"Information", None))
        self.TextoLastNews_2.setText(QCoreApplication.translate("AdministratorWindow", u"Lorem ipsum dolor sit amet consectetur adipiscing elit sagittis iaculis nascetur, vestibulum convallis arcu varius ullamcorper accumsan a urna sodales, rutrum odio magna consequat dapibus mauris leo proin posuere. Pharetra aptent luctus justo quam in fusce morbi ad himenaeos, hendrerit conubia fames ultrices nulla vitae suspendisse ante malesuada dis, enim cubilia molestie purus nisi mattis ut mi. Lacinia conubia urna penatibus ridiculus quisque et scelerisque, natoque condimentum dapibus fermentum montes fringilla facilisis, neque inceptos tempor euismod turpis nascetur.", None))
        self.TitleLastNews_4.setText(QCoreApplication.translate("AdministratorWindow", u"Alerts", None))
        self.TitleLastNews_5.setText(QCoreApplication.translate("AdministratorWindow", u"Failures:", None))
        self.TextoLastNews_4.setText(QCoreApplication.translate("AdministratorWindow", u"Lorem ipsum dolor sit amet consectetur adipiscing elit sagittis iaculis nascetur, vestibulum convallis arcu varius ullamcorper accumsan a urna sodales, rutrum odio magna consequat dapibus mauris leo proin posuere. Pharetra aptent luctus justo quam in fusce morbi ad himenaeos, hendrerit conubia fames ultrices nulla vitae suspendisse ante malesuada dis, enim cubilia molestie purus nisi mattis ut mi. Lacinia conubia urna penatibus ridiculus quisque et scelerisque, natoque condimentum dapibus fermentum montes fringilla facilisis, neque inceptos tempor euismod turpis nascetur.", None))
        self.TitleLastNews_6.setText(QCoreApplication.translate("AdministratorWindow", u"Warnings:", None))
        self.TextoLastNews_5.setText(QCoreApplication.translate("AdministratorWindow", u"Lorem ipsum dolor sit amet consectetur adipiscing elit sagittis iaculis nascetur, vestibulum convallis arcu varius ullamcorper accumsan a urna sodales, rutrum odio magna consequat dapibus mauris leo proin posuere. Pharetra aptent luctus justo quam in fusce morbi ad himenaeos, hendrerit conubia fames ultrices nulla vitae suspendisse ante malesuada dis, enim cubilia molestie purus nisi mattis ut mi. Lacinia conubia urna penatibus ridiculus quisque et scelerisque, natoque condimentum dapibus fermentum montes fringilla facilisis, neque inceptos tempor euismod turpis nascetur.", None))
        self.Sector5.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 5:", None))
        self.check5.setText("")
        self.Sector4.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 4:", None))
        self.check4.setText("")
        self.Sector1.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 1:", None))
        self.check1.setText("")
        self.Sector7.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 7:", None))
        self.check7.setText("")
        self.Sector2.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 2:", None))
        self.check2.setText("")
        self.Sector6.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 6:", None))
        self.check6.setText("")
        self.Sector3.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 3:", None))
        self.check3.setText("")
        self.Sector8.setText(QCoreApplication.translate("AdministratorWindow", u"Sector 8:", None))
        self.check8.setText("")
        self.Sector1_3.setText(QCoreApplication.translate("AdministratorWindow", u"CREATE NEW", None))
        self.TitleLastNews.setText(QCoreApplication.translate("AdministratorWindow", u"Information", None))
        self.TextoLastNews.setText(QCoreApplication.translate("AdministratorWindow", u"Lorem ipsum dolor sit amet consectetur adipiscing elit sagittis iaculis nascetur, vestibulum convallis arcu varius ullamcorper accumsan a urna sodales, rutrum odio magna consequat dapibus mauris leo proin posuere. Pharetra aptent luctus justo quam in fusce morbi ad himenaeos, hendrerit conubia fames ultrices nulla vitae suspendisse ante malesuada dis, enim cubilia molestie purus nisi mattis ut mi. Lacinia conubia urna penatibus ridiculus quisque et scelerisque, natoque condimentum dapibus fermentum montes fringilla facilisis, neque inceptos tempor euismod turpis nascetur.", None))
        self.TitleLastNews_2.setText(QCoreApplication.translate("AdministratorWindow", u"Alerts", None))
        self.TextoLastNews_3.setText(QCoreApplication.translate("AdministratorWindow", u"Lorem ipsum dolor sit amet consectetur adipiscing elit sagittis iaculis nascetur, vestibulum convallis arcu varius ullamcorper accumsan a urna sodales, rutrum odio magna consequat dapibus mauris leo proin posuere. Pharetra aptent luctus justo quam in fusce morbi ad himenaeos, hendrerit conubia fames ultrices nulla vitae suspendisse ante malesuada dis, enim cubilia molestie purus nisi mattis ut mi. Lacinia conubia urna penatibus ridiculus quisque et scelerisque, natoque condimentum dapibus fermentum montes fringilla facilisis, neque inceptos tempor euismod turpis nascetur.", None))
        self.Sector6_5.setText(QCoreApplication.translate("AdministratorWindow", u"Sensor 4:", None))
        self.check6_5.setText("")
        self.Sector2_5.setText(QCoreApplication.translate("AdministratorWindow", u"Sensor 2:", None))
        self.check2_5.setText("")
        self.Sector1_6.setText(QCoreApplication.translate("AdministratorWindow", u"Sensor 1:", None))
        self.check1_5.setText("")
        self.Sector3_5.setText(QCoreApplication.translate("AdministratorWindow", u"Sensor 3:", None))
        self.check3_5.setText("")
        self.Sector4_5.setText(QCoreApplication.translate("AdministratorWindow", u"Sensor 6:", None))
        self.check4_5.setText("")
        self.Sector7_17.setText(QCoreApplication.translate("AdministratorWindow", u"Sensor 7:", None))
        self.check7_5.setText("")
        self.Sector5_5.setText(QCoreApplication.translate("AdministratorWindow", u"Sensor 5:", None))
        self.check5_5.setText("")
        self.Sector1_7.setText(QCoreApplication.translate("AdministratorWindow", u"CREATE NEW", None))
        self.TitleLastNews_7.setText(QCoreApplication.translate("AdministratorWindow", u"Sensor 6", None))
        self.TitleLastNews_9.setText(QCoreApplication.translate("AdministratorWindow", u"Cold Storage Room", None))
        self.TextoLastNews_8.setText(QCoreApplication.translate("AdministratorWindow", u"Sensor operating correctly.", None))
        self.TextoLastNews_6.setText(QCoreApplication.translate("AdministratorWindow", u"Target temperature:\n"
" Current temperature: 3\u202f\u00b0\n"
"CIdeal temperature: ", None))
        self.TitleLastNews_8.setText(QCoreApplication.translate("AdministratorWindow", u"Alerts", None))
        self.TextoLastNews_7.setText(QCoreApplication.translate("AdministratorWindow", u"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam congue libero nibh. Proin convallis velit congue, bibendum mi eget, sagittis nulla. Sed feugiat nulla quis dictum auctor. Sed efficitur aliquet cursus. Nam iaculis eget lectus sed rhoncus. Etiam et nibh tempor, dictum arcu et, efficitur tellus. Aenean porttitor id lacus vel rutrum. Quisque in pulvinar ipsum. Phasellus finibus placerat dolor, aliquet ornare orci tincidunt non. Sed mollis metus eget blandit iaculis. Aenean egestas, mi id aliquet laoreet", None))
        self.Title_4.setText(QCoreApplication.translate("AdministratorWindow", u"Profile", None))
        self.Sector7_2.setText(QCoreApplication.translate("AdministratorWindow", u"Edit Profile", None))
        self.Title_5.setText(QCoreApplication.translate("AdministratorWindow", u"Control & Security", None))
        self.Sector7_4.setText(QCoreApplication.translate("AdministratorWindow", u"Privacy", None))
        self.Sector7_3.setText(QCoreApplication.translate("AdministratorWindow", u"Subscriptions", None))
        self.Sector7_5.setText(QCoreApplication.translate("AdministratorWindow", u"Accesibility", None))
        self.Title_6.setText(QCoreApplication.translate("AdministratorWindow", u"App Settings", None))
        self.Sector7_6.setText(QCoreApplication.translate("AdministratorWindow", u"Language", None))
        self.Sector7_8.setText(QCoreApplication.translate("AdministratorWindow", u"Notifications", None))
        self.Title_8.setText(QCoreApplication.translate("AdministratorWindow", u"Search Profile", None))
        self.lineEdit.setText(QCoreApplication.translate("AdministratorWindow", u"Enter the profile name here...", None))
        self.lineEdit.setPlaceholderText("")
        self.Title_13.setText(QCoreApplication.translate("AdministratorWindow", u"CHATS", None))
        self.Sector7_15.setText(QCoreApplication.translate("AdministratorWindow", u"New Chat", None))
        self.label_2.setText("")
        self.label_3.setText(QCoreApplication.translate("AdministratorWindow", u"Ningun chat ha sido seleccionado", None))
        self.label_5.setText("")
        self.Title_14.setText(QCoreApplication.translate("AdministratorWindow", u"Usuario", None))
        self.plainTextEdit.setPlainText(QCoreApplication.translate("AdministratorWindow", u"Text here", None))
        self.label_4.setText("")
    # retranslateUi

