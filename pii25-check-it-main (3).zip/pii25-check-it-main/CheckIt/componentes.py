from PySide6.QtCore import Qt, QRectF, Signal
from PySide6.QtGui import QPainter, QColor, QPen, QLinearGradient, QBrush, QFont, QPainterPath, QPixmap, QCursor, QMouseEvent
from PySide6.QtWidgets import QWidget, QLabel, QHBoxLayout, QMenu, QPushButton
import os

class UserWidget(QWidget):
    # Señales para comunicar acciones al padre
    delete_clicked = Signal(dict) # Enviamos el diccionario del usuario entero
    edit_clicked = Signal(dict)   # Enviamos el diccionario del usuario entero

    def __init__(self, user_data, parent=None):
        super().__init__(parent)
        self.user_data = user_data # Guardamos los datos crudos para usarlos luego

        # --- Lógica del Nombre ---
        nombre = user_data.get("nombre", "").strip()
        apellido = user_data.get("apellido", "").strip()

        if nombre and apellido:
            display_name = f"{nombre} {apellido}"
        elif nombre:
            display_name = nombre
        else:
            display_name = "Usuario Desconocido"

        # --- Lógica de la Imagen (opcional, si tienes campo imagen en el JSON) ---
        image_path = user_data.get("image", "")

        # --- Layout ---
        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(10, 5, 10, 5)
        self.layout.setSpacing(10)

        # --- Estilo ---
        self.setStyleSheet("""
            UserWidget {
                background-color: #E6E6E6;
                border-radius: 10px;
                border: 2px solid #0094C9;
            }
            UserWidget:hover {
                background-color: #D6D6D6;
                border: 2px solid #0077A3;
            }
        """)

        # 1. Avatar
        self.lbl_image = QLabel()
        self.lbl_image.setFixedSize(40, 40)
        self.lbl_image.setScaledContents(True)
        self.lbl_image.setStyleSheet("background-color: transparent; border: none;")

        if image_path and os.path.exists(image_path):
            self.lbl_image.setPixmap(QPixmap(image_path))
        else:
            # Inicial del nombre o 'U' si es desconocido
            inicial = display_name[0] if display_name else "?"
            self.lbl_image.setText(inicial)
            self.lbl_image.setStyleSheet("""
                QLabel {
                    background-color: #0094C9;
                    color: white;
                    font-weight: bold;
                    border-radius: 20px;
                    border: none;
                    qproperty-alignment: AlignCenter;
                }
            """)

        # 2. Etiqueta Nombre
        self.lbl_name = QLabel(display_name)
        self.lbl_name.setStyleSheet("""
            color: grey;
            font-size: 10pt;
            font-weight: bold;
            background-color: transparent;
            border: none;
        """)

        # 3. Etiqueta Tipo (Pequeña ayuda visual)
        tipo_str = user_data.get("tipo", "N/A")
        self.lbl_type = QLabel(f"({tipo_str})")
        self.lbl_type.setStyleSheet("color: #888; font-size: 8pt; border: none; background: transparent;")

        # 4. Botones
        self.btn_edit = QPushButton("Tipo")
        self.btn_edit.setCursor(Qt.PointingHandCursor)
        self.btn_edit.setFixedSize(60, 30)
        self.btn_edit.setStyleSheet("""
            QPushButton {
                background-color: #FFB74D;
                color: white; font-weight: bold; border: none; border-radius: 5px;
            }
            QPushButton:hover { background-color: #FFA726; }
        """)
        self.btn_edit.clicked.connect(lambda: self.edit_clicked.emit(self.user_data))

        self.btn_delete = QPushButton("Borrar")
        self.btn_delete.setCursor(Qt.PointingHandCursor)
        self.btn_delete.setFixedSize(60, 30)
        self.btn_delete.setStyleSheet("""
            QPushButton {
                background-color: #EF5350;
                color: white; font-weight: bold; border: none; border-radius: 5px;
            }
            QPushButton:hover { background-color: #E53935; }
        """)
        self.btn_delete.clicked.connect(lambda: self.delete_clicked.emit(self.user_data))

        # --- Montaje ---
        self.layout.addWidget(self.lbl_image)
        self.layout.addWidget(self.lbl_name)
        self.layout.addWidget(self.lbl_type)
        self.layout.addStretch()
        self.layout.addWidget(self.btn_edit)
        self.layout.addWidget(self.btn_delete)

        self.setFixedHeight(70)

class SensorRuidoWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(150, 200) # Formato vertical
        self.nivel_ruido = 70

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        rect = self.rect()

        # 1. Fondo Tarjeta (Borde gris redondeado)
        path_bg = QPainterPath()
        path_bg.addRoundedRect(QRectF(rect).adjusted(5,5,-5,-5), 15, 15)

        painter.setPen(QPen(QColor("#CCCCCC"), 2))
        painter.setBrush(QColor("white"))
        painter.drawPath(path_bg)

        # 2. Dibujar Auriculares (Icono vectorial manual)
        # Coordenadas relativas al centro superior
        cx = rect.center().x()
        cy = rect.top() + 60

        color_icon = QColor("#0000FF") # Azul eléctrico
        pen_icon = QPen(color_icon, 4)
        pen_icon.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen_icon)
        painter.setBrush(Qt.BrushStyle.NoBrush)

        # Diadema (Arco superior)
        rect_head = QRectF(cx - 25, cy - 25, 50, 50)
        painter.drawArc(rect_head, 0, 180 * 16) # Medio círculo arriba

        # Orejeras (Rectángulos redondeados)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        # Orejera Izquierda
        painter.drawRoundedRect(QRectF(cx - 30, cy, 15, 20), 5, 5)
        # Orejera Derecha
        painter.drawRoundedRect(QRectF(cx + 15, cy, 15, 20), 5, 5)

        # Onda de sonido (Zigzag pequeño en medio)
        path_wave = QPainterPath()
        path_wave.moveTo(cx - 10, cy + 10)
        path_wave.lineTo(cx - 5, cy + 5)
        path_wave.lineTo(cx + 5, cy + 15)
        path_wave.lineTo(cx + 10, cy + 10)
        painter.drawPath(path_wave)

        # 3. Textos
        painter.setPen(QColor("black"))

        # "Sound" (Negrita)
        painter.setFont(QFont("Arial", 12, QFont.Weight.Bold))
        r_title = QRectF(0, cy + 40, rect.width(), 30)
        painter.drawText(r_title, Qt.AlignmentFlag.AlignCenter, "Sound")

        # "Vol level 70" (Normal)
        painter.setFont(QFont("Arial", 10))
        r_val = QRectF(0, cy + 65, rect.width(), 30)
        painter.drawText(r_val, Qt.AlignmentFlag.AlignCenter, f"Vol level {self.nivel_ruido}")

        painter.end()
class CalidadAireWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(200, 200)
        self.calidad = 70  # 0 (Puro) a 100 (Tóxico)

    def setCalidad(self, valor):
        self.calidad = max(0, min(4096, valor))
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = self.rect()
        ancho = min(rect.width(), rect.height())
        rect_circulo = QRectF((rect.width()-ancho)/2 + 10, (rect.height()-ancho)/2 + 10, ancho-20, ancho-20)

        # 1. Fondo del anillo (Gris muy claro)
        pen_track = QPen(QColor("#EEEEEE"))
        pen_track.setWidth(15)
        pen_track.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen_track)
        # 270 grados de arco, apertura abajo
        start_angle = 225 * 16
        span_angle = -270 * 16
        painter.drawArc(rect_circulo, start_angle, span_angle)

        # 2. Arco de Valor (Gradiente Naranja a Rojo Peligro)
        gradiente = QLinearGradient(rect_circulo.topLeft(), rect_circulo.bottomRight())
        gradiente.setColorAt(0.0, QColor("#FFA726")) # Naranja
        gradiente.setColorAt(1.0, QColor("#EF5350")) # Rojo

        pen_val = QPen(QBrush(gradiente), 15)
        pen_val.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen_val)

        progreso = (4096 - self.calidad) / 4096
        painter.drawArc(rect_circulo, start_angle, int(span_angle * progreso))

        # 3. Dibujar Icono de Advertencia (Triángulo) en el centro
        # Definimos un cuadrado pequeño en el centro
        center_rect = QRectF(rect.width()/2 - 30, rect.height()/2 - 40, 60, 60)

        painter.setPen(Qt.PenStyle.NoPen)
        # Si la calidad es mala (>50), mostramos rojo, si no verde
        color_aviso = QColor("#FF453A") if self.calidad < 2100 else QColor("#32D74B")
        painter.setBrush(color_aviso)

        # Dibujar Triángulo
        path_triangulo = QPainterPath()
        # Punta arriba
        path_triangulo.moveTo(center_rect.center().x(), center_rect.top())
        # Esquina inf derecha
        path_triangulo.lineTo(center_rect.right(), center_rect.bottom())
        # Esquina inf izquierda
        path_triangulo.lineTo(center_rect.left(), center_rect.bottom())
        path_triangulo.closeSubpath()

        painter.drawPath(path_triangulo)

        # Signo de exclamación (texto blanco)
        painter.setPen(QColor("white"))
        painter.setFont(QFont("Arial", 24, QFont.Weight.Bold))
        painter.drawText(center_rect, Qt.AlignmentFlag.AlignCenter, "!")

        # Texto inferior
        painter.setPen(QColor("black"))
        painter.setFont(QFont("Arial", 10))
        estado = "Air Alert" if self.calidad > 50 else "Air Good"
        rect_lbl = QRectF(rect_circulo.left(), rect_circulo.bottom() - 40, rect_circulo.width(), 30)
        painter.drawText(rect_lbl, Qt.AlignmentFlag.AlignCenter, estado)

        painter.end()

class SensorLuzWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(300, 80)
        self.nivel_luz = 70  # Porcentaje 0-100

    def setLevel(self, nivel):
        self.nivel_luz = max(0, min(4096, nivel))
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = self.rect()
        # Radio para hacer la forma de cápsula (altura / 2)
        radio = rect.height() / 2

        # 1. Definir el área de recorte (la forma de cápsula completa)
        path_fondo = QPainterPath()
        path_fondo.addRoundedRect(QRectF(rect), radio, radio)

        # Guardamos el estado para aplicar el recorte
        painter.save()
        painter.setClipPath(path_fondo)

        # 2. Dibujar fondo (parte vacía, blanca o gris muy clara)
        painter.fillPath(path_fondo, QColor("#F0F0F0"))

        # 3. Dibujar la barra de progreso (Gradiente Naranja a Amarillo)
        ancho_progreso = (self.nivel_luz / 4096) * rect.width()
        rect_progreso = QRectF(0, 0, ancho_progreso, rect.height())

        gradiente = QLinearGradient(rect.topLeft(), rect.topRight())
        gradiente.setColorAt(0.0, QColor("#FF6B4A")) # Naranja intenso
        gradiente.setColorAt(1.0, QColor("#FFD200")) # Amarillo sol

        painter.fillRect(rect_progreso, gradiente)

        # Restauramos para poder dibujar texto encima sin recortes raros
        painter.restore()

        # 4. Texto
        painter.setPen(QColor("#FFFFFF"))
        font_grande = QFont("Arial", 20, QFont.Weight.Bold)
        painter.setFont(font_grande)

        # Centramos el texto visualmente en la parte llena si es grande,
        # o en el centro del widget. Aquí lo pondré centrado en el widget.
        texto = f"{int(self.nivel_luz/4096 * 100)}%"
        rect_texto = QRectF(rect)
        painter.drawText(rect_texto.adjusted(0, -10, 0, 0), Qt.AlignmentFlag.AlignCenter, texto)

        font_peq = QFont("Arial", 10)
        painter.setFont(font_peq)
        painter.drawText(rect_texto.adjusted(0, 20, 0, 0), Qt.AlignmentFlag.AlignCenter, "Brightness")

        painter.end()
class TermostatoWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(200, 200) # Tamaño mínimo
        self.temperatura = 40         # Valor inicial
        self.min_temp = -20             # Rango mínimo
        self.max_temp = 50            # Rango máximo

    def setTemperature(self, temp):
        """Actualiza la temperatura y redibuja el widget"""
        # Aseguramos que esté dentro del rango
        self.temperatura = max(self.min_temp, min(self.max_temp, temp))
        self.update() # IMPORTANTE: Esto fuerza a ejecutar paintEvent de nuevo

    def paintEvent(self, event):
        """Aquí ocurre la magia del dibujo"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing) # Para que no se vean dientes de sierra

        # 1. Configurar geometría
        rect = self.rect()
        ancho = min(rect.width(), rect.height())
        # Creamos un cuadrado centrado para dibujar el círculo
        rect_circulo = QRectF(
            (rect.width() - ancho) / 2 + 10,
            (rect.height() - ancho) / 2 + 10,
            ancho - 20,
            ancho - 20
        )

        # 2. Dibujar el Fondo con Gradiente (Azul a Rosa)
        gradiente = QLinearGradient(rect_circulo.topLeft(), rect_circulo.bottomRight())
        gradiente.setColorAt(0.0, QColor("#6B73FF")) # Azul morado
        gradiente.setColorAt(1.0, QColor("#FF5677")) # Rosa rojizo

        painter.setPen(Qt.NoPen)
        painter.setBrush(QBrush(gradiente))
        painter.drawEllipse(rect_circulo)

        # 3. Dibujar el carril negro fino (Track)
        pen_track = QPen(QColor(0, 0, 0, 150)) # Negro semi-transparente
        pen_track.setWidth(3)
        painter.setPen(pen_track)
        painter.setBrush(Qt.NoBrush)

        # Reducimos un poco el rect para que la línea esté dentro
        rect_track = rect_circulo.adjusted(15, 15, -15, -15)
        painter.drawEllipse(rect_track)

        # 4. Cálculos matemáticos para el arco de progreso
        # Qt trabaja con "span angle" en 1/16 de grado.
        # El 0 está a las 3 en punto. Nosotros queremos empezar abajo a la izquierda o arriba.
        # Vamos a simular que empieza a las 7 en punto y termina a las 5 (apertura abajo).

        start_angle = 225 * 16 # Ángulo inicial (en 16avos de grado)
        total_span = -270 * 16 # Cuánto recorre el círculo (negativo es sentido horario)

        # Calcular porcentaje actual (0.0 a 1.0)
        porcentaje = (self.temperatura - self.min_temp) / (self.max_temp - self.min_temp)
        span_actual = total_span * porcentaje

        # 5. Dibujar el Arco Blanco de Progreso
        pen_progreso = QPen(QColor("#FFFFFF"))
        pen_progreso.setWidth(6)
        pen_progreso.setCapStyle(Qt.RoundCap) # Bordes redondeados
        painter.setPen(pen_progreso)
        painter.drawArc(rect_track, start_angle, int(span_actual))

        # 6. Dibujar el Texto Central
        painter.setPen(QColor("#FFFFFF"))

        # Texto Grande (Temperatura)
        font_temp = QFont("Arial", 28, QFont.Bold)
        painter.setFont(font_temp)
        texto_temp = f"{int(self.temperatura)}°C"

        # Rectángulos para posicionar texto
        rect_texto_sup = QRectF(rect_circulo.left(), rect_circulo.top() + rect_circulo.height()/2 - 30, rect_circulo.width(), 40)
        painter.drawText(rect_texto_sup, Qt.AlignCenter, texto_temp)

        # Texto Pequeño (Estado)
        font_status = QFont("Arial", 12)
        painter.setFont(font_status)
        estado = "Cool" if self.temperatura < 20 else "Hot"

        rect_texto_inf = QRectF(rect_circulo.left(), rect_circulo.top() + rect_circulo.height()/2 + 10, rect_circulo.width(), 30)
        painter.drawText(rect_texto_inf, Qt.AlignCenter, estado)

        painter.end()

