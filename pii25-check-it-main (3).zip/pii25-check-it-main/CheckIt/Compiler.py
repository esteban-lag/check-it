import os
import subprocess
import time

def compile_project():
    # 1. Definir los comandos (asegúrate de tener el entorno virtual activo)
    UIC_COMMAND = "pyside6-uic"
    RCC_COMMAND = "pyside6-rcc"

    # Contadores
    ui_count = 0
    rc_count = 0

    print("🚀 Iniciando compilación de recursos UI y QRC...\n")

    # 2. Recorrer todas las carpetas del proyecto
    for root, dirs, files in os.walk("."):

        # Ignorar carpetas del entorno virtual o git para ir más rápido
        if "venv" in root or ".git" in root or "__pycache__" in root:
            continue

        for file in files:
            # --- CASO 1: ARCHIVOS .UI ---
            if file.endswith(".ui"):
                input_path = os.path.join(root, file)

                # Definir nombre de salida: User.ui -> ui_User.py
                output_name = f"ui_{file[:-3]}.py"
                output_path = os.path.join(root, output_name)

                # Verificar si es necesario compilar (si el .ui es más nuevo que el .py)
                if needs_compilation(input_path, output_path):
                    try:
                        # Ejecutar: pyside6-uic archivo.ui -o ui_archivo.py
                        subprocess.run([UIC_COMMAND, input_path, "-o", output_path], check=True)
                        print(f"✅ Compilado UI: {file} -> {output_name}")
                        ui_count += 1
                    except Exception as e:
                        print(f"❌ Error compilando {file}: {e}")

            # --- CASO 2: ARCHIVOS .QRC (Recursos) ---
            elif file.endswith(".qrc"):
                input_path = os.path.join(root, file)

                # Definir nombre de salida: Recursos.qrc -> rc_Recursos.py
                output_name = f"rc_{file[:-4]}.py"
                output_path = os.path.join(root, output_name)

                if needs_compilation(input_path, output_path):
                    try:
                        # Ejecutar: pyside6-rcc archivo.qrc -o rc_archivo.py
                        subprocess.run([RCC_COMMAND, input_path, "-o", output_path], check=True)
                        print(f"🎨 Compilado RES: {file} -> {output_name}")
                        rc_count += 1
                    except Exception as e:
                        print(f"❌ Error compilando {file}: {e}")

    print(f"\n✨ Finalizado. Se actualizaron {ui_count} interfaces y {rc_count} recursos.")

def needs_compilation(source, target):
    """Devuelve True si el archivo origen es más nuevo que el destino o si el destino no existe."""
    if not os.path.exists(target):
        return True
    return os.path.getmtime(source) > os.path.getmtime(target)

if __name__ == "__main__":
    compile_project()

