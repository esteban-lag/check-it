import sys
import os
from PySide6.QtWidgets import (QMainWindow, QVBoxLayout, QSpacerItem,
                               QSizePolicy, QMessageBox, QInputDialog)
from vistas.Administrator.ui_UserADMIN import Ui_AdministratorWindow
from componentes import UserWidget
import models
from PySide6.QtWidgets import QVBoxLayout
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure


class AdministratorWindow(QMainWindow):
    def __init__(self, parent=None):
        super().__init__()
        self.ui = Ui_AdministratorWindow()
        self.ui.setupUi(self)

        # --- Layouts y Navegación ---
        layout_principal = QVBoxLayout(self.ui.centralwidget)
        layout_principal.setContentsMargins(0, 0, 0, 0)
        layout_principal.addWidget(self.ui.frame)
        self.ui.stackedWidget.setCurrentIndex(0)

        self.ui.pushButton.clicked.connect(lambda: self.cambiar_pagina(0))
        self.ui.pushButton_2.clicked.connect(lambda: self.cambiar_pagina(1))
        self.ui.pushButton_3.clicked.connect(lambda: self.cambiar_pagina(2))
        self.ui.pushButton_4.clicked.connect(lambda: self.cambiar_pagina(3))
        self.ui.pushButton_5.clicked.connect(lambda: self.cambiar_pagina(4))
        # --- CARGAR USUARIOS DESDE BD ---
        self.lista_usuarios = []
        self.database = models.obtener_db()

        # --- Inicialización ---
        self.setup_user_list()
        self.datos_sensores = self.cargar_datos_bd()
        self.cargar_promedios_home()
        self.cargar_datos_y_pintar()
        self.cargar_datos_parking()
        self.cargar_grafica_historico()

    def setup_user_list(self):
        """Configura el layout de la lista de usuarios."""
        self.user_list_layout = self.ui.verticalLayout_25
        while self.user_list_layout.count():
            item = self.user_list_layout.takeAt(0)
            widget = item.widget()
            if widget: widget.deleteLater()

        self.spacer_item = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)
        self.user_list_layout.addItem(self.spacer_item)

    def mapear_tipo_sensor(self, tipo_id):
        """Mapea el ID del tipo de sensor en BD a su nombre legible."""
        # Asumimos que en BD los tipos están como IDs numéricos
        # Ajusta esto según tu esquema real
        tipo_map = {
            1: 'temperatura',
            2: 'humedad',
            3: 'distancia',
            4: 'aire',
            5: 'luz',
            7: 'ruido'
        }

        return tipo_map.get(tipo_id, 'desconocido')

    def cargar_promedios_home(self):
        """
        Calcula la media de todos los sensores y actualiza
        los widgets de la página HOME.
        """
        if not self.datos_sensores:
            return

        # Diccionarios para guardar sumas y contadores
        sumas = {'temperatura': 0, 'luz': 0, 'aire': 0, 'ruido': 0}
        contadores = {'temperatura': 0, 'luz': 0, 'aire': 0, 'ruido': 0}

        # 1. Recorrer todos los datos y sumar
        for sensor in self.datos_sensores:
            tipo = sensor.get('tipo')
            valor = sensor.get('valor', 0)

            if tipo in sumas:
                sumas[tipo] += valor
                contadores[tipo] += 1

        # 2. Calcular promedios
        promedios = {}
        for key in sumas:
            if contadores[key] > 0:
                promedios[key] = sumas[key] / contadores[key]
            else:
                promedios[key] = 0

        print(f"Promedios generales: {promedios}")

        # 3. Actualizar los Widgets de la HOME

        # Temperatura
        self.ui.widget_13.setTemperature(promedios['temperatura'])

        # Luz
        self.ui.widget_15.setLevel(promedios['luz'])

        # Aire
        self.ui.widget_16.setCalidad(promedios['aire'])

        # Ruido
        self.ui.widget_12.nivel_ruido = promedios['ruido']
        self.ui.widget_12.update()

    def setup_sectores(self):
        """Conecta los botones de la página 'Sectors' a la función de carga."""
        try:
            self.ui.Sector1_2.clicked.connect(lambda: self.mostrar_datos_sector(1))
            self.ui.Sector2_2.clicked.connect(lambda: self.mostrar_datos_sector(2))
            self.ui.Sector3_2.clicked.connect(lambda: self.mostrar_datos_sector(3))
            self.ui.Sector4_2.clicked.connect(lambda: self.mostrar_datos_sector(4))
            self.ui.Sector5_2.clicked.connect(lambda: self.mostrar_datos_sector(5))
            self.ui.Sector6_2.clicked.connect(lambda: self.mostrar_datos_sector(6))

            if hasattr(self.ui, 'Sector7_7'):
                self.ui.Sector7_7.clicked.connect(lambda: self.mostrar_datos_sector(7))
            elif hasattr(self.ui, 'Sector7_2'):
                self.ui.Sector7_2.clicked.connect(lambda: self.mostrar_datos_sector(7))

            self.ui.Sector8_2.clicked.connect(lambda: self.mostrar_datos_sector(8))
        except AttributeError as e:
            print(f"Error conectando botones de sectores: {e}")

    def mostrar_datos_sector(self, sector_id):
        """
        Filters data by sector and updates the widgets.
        """
        print(f"Loading data for Sector {sector_id}...")

        # 1. Filtrar datos del sector seleccionado
        datos_sector = [d for d in self.datos_sensores if d['sector'] == sector_id]

        if not datos_sector:
            print("No data for this sector.")
            return

        # 2. Iterar y actualizar cada widget según el nuevo mapeo de tipos
        for sensor in datos_sector:
            tipo = sensor['tipo']
            valor = sensor['valor']
            min_v = sensor.get('min_val', 0)
            max_v = sensor.get('max_val', 100)

            if tipo == "temperatura":
                self.ui.widget_11.min_temp = min_v
                self.ui.widget_11.max_temp = max_v
                self.ui.widget_11.setTemperature(valor)

            # elif tipo == "humedad":
            # 🛠️ ¡AÑADIDO! Aquí manejas la humedad (Tipo 2)
            # Revisa en Qt Designer si el widget de humedad es widget_12, widget_7... y cambia el número si hace falta
            # self.ui.widget_12.setHumidity(valor)

            elif tipo == "aire":
                self.ui.widget_9.setCalidad(valor)

            elif tipo == "luz":
                # Ahora la luz (Tipo 5) actualiza de forma correcta el widget_8
                self.ui.widget_8.setLevel(valor)

            # elif tipo == "distancia":
            # Aquí puedes añadir la lógica del parking/distancia si el sensor mide eso
            #    pass

    def cargar_datos_bd(self):
        """Lee los sensores desde la BD."""
        try:
            # Cargar sensores desde la BD usando models
            sensores_bd = models.cargar_sensores_bd()

            # Convertir formato de BD a formato esperado por la UI
            datos_sensores = []
            for sensor in sensores_bd:
                datos_sensores.append({
                    'id': sensor.get('id'),
                    'sector': sensor.get('zone'),  # zone en BD = sector
                    'valor': sensor.get('value'),
                    'tipo': self.mapear_tipo_sensor(sensor.get('type')),
                    'max_val': sensor.get('max'),
                    'min_val': sensor.get('minimum'),
                    'working': sensor.get('working')
                })

            print(f"Cargados {len(datos_sensores)} sensores desde BD")
            return datos_sensores
        except Exception as e:
            print(f"Error leyendo sensores de BD: {e}")
            return []
    def cargar_datos_y_pintar(self):
        """Carga los usuarios desde la BD y los pinta en la UI."""
        if not self.database:
            QMessageBox.critical(self, "Error", "No hay conexión a la base de datos")
            return

        try:
            # Obtener usuarios de la BD (models.py usa la BD ahora)
            usuarios_objetos = models.cargar_usuarios()
            
            # Convertir objetos a diccionarios para la UI
            self.lista_usuarios = [u.to_dict() for u in usuarios_objetos]
            
            print(f"--- DEBUG: Cargados {len(self.lista_usuarios)} usuarios desde BD ---")
            self.refrescar_lista_visual()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Error leyendo de la BD: {e}")

    def refrescar_lista_visual(self):
        """Actualiza la visualización de usuarios en la UI."""
        self.user_list_layout.removeItem(self.spacer_item)

        while self.user_list_layout.count():
            item = self.user_list_layout.takeAt(0)
            w = item.widget()
            if w: w.deleteLater()

        for user_data in self.lista_usuarios:
            widget = UserWidget(user_data)
            widget.delete_clicked.connect(self.eliminar_usuario)
            widget.edit_clicked.connect(self.cambiar_tipo_usuario)
            self.user_list_layout.addWidget(widget)

        self.user_list_layout.addItem(self.spacer_item)

    # --- LÓGICA DE NEGOCIO ---

    def eliminar_usuario(self, user_dict):
        """Elimina un usuario de la BD."""
        correo_objetivo = user_dict.get("correo")
        nombre_mostrar = user_dict.get("nombre", "este usuario")

        confirmacion = QMessageBox.question(
            self, "Confirmar Borrado",
            f"¿Seguro que deseas eliminar a {nombre_mostrar} ({correo_objetivo})?",
            QMessageBox.Yes | QMessageBox.No
        )

        if confirmacion == QMessageBox.Yes:
            try:
                # Obtener el usuario de la BD por correo para tener el ID
                usuario_db = self.database.get_usuario_by_correo(correo_objetivo)
                
                if usuario_db:
                    usuario_id = usuario_db.get("id")
                    self.database.eliminar_usuario(usuario_id)
                    
                    # Actualizar la lista en memoria
                    self.lista_usuarios = [u for u in self.lista_usuarios if u.get("correo") != correo_objetivo]
                    
                    self.refrescar_lista_visual()
                    QMessageBox.information(self, "Éxito", "Usuario eliminado correctamente.")
                else:
                    QMessageBox.warning(self, "Error", "No se encontró el usuario en la BD.")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Error al eliminar: {e}")

    def cambiar_tipo_usuario(self, user_dict):
        """Cambia el tipo/rol de un usuario en la BD."""
        correo_objetivo = user_dict.get("correo")

        tipos_disponibles = ["Usuario Promedio", "Trabajador", "Administrador"]
        tipo_actual = user_dict.get("tipo", "Usuario Promedio")
        idx_actual = tipos_disponibles.index(tipo_actual) if tipo_actual in tipos_disponibles else 0

        nuevo_tipo, ok = QInputDialog.getItem(
            self, "Cambiar Tipo"
            f"Selecciona rol para {user_dict.get('nombre', 'Usuario')}:",
            tipos_disponibles, current=idx_actual, editable=False
        )

        if ok and nuevo_tipo:
            try:
                # Obtener el usuario de la BD por correo
                usuario_db = self.database.get_usuario_by_correo(correo_objetivo)
                
                if usuario_db:
                    usuario_id = usuario_db.get("id")
                    # Actualizar en la BD
                    self.database.actualizar_usuario(usuario_id, {'type': nuevo_tipo})
                    
                    # Actualizar en la lista en memoria
                    for usuario in self.lista_usuarios:
                        if usuario.get("correo") == correo_objetivo:
                            usuario["tipo"] = nuevo_tipo
                            break
                    
                    self.refrescar_lista_visual()
                    QMessageBox.information(self, "Éxito", f"Tipo cambiado a {nuevo_tipo}.")
                else:
                    QMessageBox.warning(self, "Error", "No se encontró el usuario en la BD.")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Error al actualizar: {e}")

    def cambiar_pagina(self, indice):
        self.ui.stackedWidget.setCurrentIndex(indice)

    def cargar_datos_parking(self):
        """Lee el archivo parking.txt y muestra las plazas en la Home del Admin"""
        ruta_archivo = "parking.txt"
        try:
            with open(ruta_archivo, "r", encoding="utf-8") as file:
                datos_parking = file.read().strip()

            texto_mostrar = f"<b>Available Parking Spots:</b> {datos_parking}"
            self.ui.label_parking.setText(texto_mostrar)
            print(f" [Admin] Datos de parking cargados: {datos_parking}")
        except FileNotFoundError:
            print("[Admin] Aviso: No se encontró el archivo parking.txt")
            self.ui.label_parking.setText("Parking: Error de lectura")
        except Exception as e:
            print(f"[Admin] Error leyendo el parking: {e}")

    def cargar_grafica_historico(self):
        """Generates a 2x2 grid of historical graphs for each sensor type using visualizacion_sensores"""
        contenedor = self.ui.frame_grafica
        if not contenedor.layout():
            layout = QVBoxLayout(contenedor)
            layout.setContentsMargins(5, 5, 5, 5)
        else:
            layout = contenedor.layout()

        # 1. Crear la figura principal con fondo transparente
        # Aumentamos un pelín el figsize para que quepan bien las 4 gráficas
        fig = Figure(figsize=(10, 6), dpi=100)
        fig.patch.set_alpha(0.0)

        # Añadimos espacio vertical y horizontal entre las gráficas para que no se solapen los textos
        fig.subplots_adjust(hspace=0.5, wspace=0.3)

        # 2. Obtener los datos de la vista a través del modelo
        try:
            datos_vista = models.obtener_historico_vista()  # <--- AHORA LLAMA A LA FUNCIÓN NUEVA
        except Exception as e:
            print(f"❌ Error reading from visualizacion_sensores: {e}")
            datos_vista = []

        # 3. Agrupar y ordenar cronológicamente las lecturas por cada id_sensor
        from collections import defaultdict
        grup_sensores = defaultdict(list)

        for fila in datos_vista:
            id_s = int(fila['id_sensor'])
            # Guardamos la tupla (fecha, valor)
            grup_sensores[id_s].append((fila['date'], float(fila['dato'])))

        # 4. Configurar el mapeo de los 4 sensores en la cuadrícula 2x2
        # ⚠️ REVISA ESTOS NÚMEROS: Cambia el 1, 5, 4, 6 por los ID reales que tengan tus sensores en la BD
        sensor_mapping = {
            0: {"title": "Temperature History (°C)", "color": "#D81B60", "pos": 1},  # Top-Left
            4: {"title": "Light History (Brightness)", "color": "#FFA000", "pos": 2},  # Top-Right
            3: {"title": "Air Quality History", "color": "#2E7D32", "pos": 3},  # Bottom-Left
            6: {"title": "Sound Level History", "color": "#1565C0", "pos": 4}  # Bottom-Right (Ajusta si es otro ID)
        }

        # 5. Dibujar cada uno de los 4 subplots
        import matplotlib.dates as mdates

        for s_id, info in sensor_mapping.items():
            # add_subplot(filas, columnas, posición) -> malla 2x2
            ax = fig.add_subplot(2, 2, info["pos"])
            ax.set_facecolor('none')  # Fondo del subplot transparente

            # Si el sensor tiene datos en la BD, los dibujamos
            if s_id in grup_sensores and grup_sensores[s_id]:

                # ---------------------------------------------------------
                # 🛠️ CAMBIO 1: Coger solo las últimas 15 lecturas (las más recientes)
                # ---------------------------------------------------------
                fechas = [x[0] for x in grup_sensores[s_id]][-15:]
                valores = [x[1] for x in grup_sensores[s_id]][-15:]

                ax.plot(fechas, valores, color=info["color"], marker='o', linestyle='-', linewidth=1.5, markersize=3)

                # ---------------------------------------------------------
                # 🛠️ CAMBIO 2: Añadir los segundos (%S) para ver cambios en tiempo real
                # ---------------------------------------------------------
                ax.xaxis.set_major_formatter(mdates.DateFormatter('%H:%M:%S'))
            else:
                # Si este sensor específico no tiene datos, ponemos un aviso visual sutil
                ax.text(0.5, 0.5, "No Data Available", color='#777777', ha='center', va='center',
                        transform=ax.transAxes, fontsize=9)

            # Estilo estético e inglés nativo para cada sub-gráfica
            ax.set_title(info["title"], color='#333333', fontweight='bold', fontsize=10)
            ax.tick_params(axis='x', colors='#333333', labelsize=8, rotation=15)
            ax.tick_params(axis='y', colors='#333333', labelsize=8)
            ax.grid(True, linestyle='--', alpha=0.3, color='#666666')

            # Ocultar bordes innecesarios para diseño limpio
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.spines['bottom'].set_color('#333333')
            ax.spines['left'].set_color('#333333')

        # 6. Integrar el lienzo (Canvas) en tu interfaz de PySide6
        canvas = FigureCanvas(fig)

        # Limpiar cualquier contenido antiguo del layout antes de meter la nueva malla
        for i in reversed(range(layout.count())):
            widget = layout.itemAt(i).widget()
            if widget is not None:
                widget.setParent(None)

        layout.addWidget(canvas)