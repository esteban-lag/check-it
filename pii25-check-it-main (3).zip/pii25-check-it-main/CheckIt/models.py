# -*- coding: utf-8 -*-
import json
import hashlib
from dataclasses import dataclass, asdict
from typing import Optional, List, Dict
import sys
import os
import DatabaseManager
# Importar DatabaseManager
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
try:
    from DatabaseManager import DatabaseManager
except ImportError:
    print("Advertencia: No se pudo importar DatabaseManager")
    DatabaseManager = None

# Forzar codificación utf-8 para la consola
sys.stdout.reconfigure(encoding='utf-8')

# ============================================================================
# INSTANCIA GLOBAL DE LA BASE DE DATOS
# ============================================================================
db = None

def inicializar_bd(host: str = 'localhost', user: str = 'root', password: str = '', 
                   database: str = 'pii26-check-it'):
    """Inicializa la conexión a la base de datos."""
    global db
    if DatabaseManager:
        db = DatabaseManager(host, user, password, database)
        db.connect()
    return db

def obtener_db() -> DatabaseManager:
    """Obtiene la instancia global de la base de datos."""
    global db
    if db is None and DatabaseManager:
        inicializar_bd()
    return db

# === Funciones de encriptación ===

def encriptado(password):
    """Crea un hash SHA-256 de la contraseña"""
    if not password: return ""
    return hashlib.sha256(password.encode()).hexdigest()

def verificar_password(password_ingresada, hash_guardado):
    """Verifica si una contraseña coincide con el hash guardado"""
    return encriptado(password_ingresada) == hash_guardado


# ============================================================================
# FUNCIONES DE SESIÓN - Almacenamiento en memoria (sesión de aplicación)
# ============================================================================

_usuario_actual = None

def guardar_usuario_actual(usuario: dict):
    """Guarda el usuario que inició sesión en memoria (sesión de aplicación)."""
    global _usuario_actual
    _usuario_actual = usuario
    print("Usuario actual guardado en sesión.")

def leer_usuario_actual():
    """Lee y devuelve el diccionario del usuario actual."""
    global _usuario_actual
    return _usuario_actual if _usuario_actual else None

def eliminar_usuario_actual():
    """Elimina el usuario actual de la sesión."""
    global _usuario_actual
    _usuario_actual = None
    print("Sesión cerrada.")

def login(correo, password_ingresada):
    database = obtener_db()
    if not database:
        print("Error: No hay conexión a la BD")
        return False
    
    
    usuario_dict = database.get_usuario_by_correo(correo)
    print(usuario_dict)
    user = TipoUsuario(usuario_dict.get("mail", ""), usuario_dict.get("password_hash", ""), usuario_dict.get("type", ""),
                       usuario_dict.get("name", ""), usuario_dict.get("last_name", ""), usuario_dict.get("dni", ""),
                       usuario_dict.get("ssn", ""), usuario_dict.get("IBAN", ""), usuario_dict.get("id", ""))
    print(user)
    if usuario_dict:
        # La verificación de contraseña en Python es segura porque:
        # - El hash se devuelve desde BD
        # - Comparamos con SHA-256 en memoria
        if verificar_password(password_ingresada, usuario_dict.get("password_hash", "")):
            print("Login exitoso")
            return user
        else:
            print("Contraseña incorrecta")
            return False
    print("Usuario no encontrado")
    return False


# === Clase base ===

@dataclass
class TipoUsuario:
    """Clase base para todos los tipos de usuarios con campos opcionales."""
    correo: str
    contrasena: str
    tipo: str

    # Campos opcionales
    nombre: Optional[str] = None
    apellido: Optional[str] = None
    dni: Optional[str] = None
    ssn: Optional[str] = None
    IBAN: Optional[str] = None
    id: Optional[int] = None

    def __init__(self, correo, contrasena, tipo, nombre=None, apellido=None, dni=None, 
                 ssn=None, IBAN=None, id=None, **kwargs):
        self.correo = correo
        self.tipo = tipo
        self.id = id

        # Unificamos: siempre usaremos self.contrasena encriptada
        if len(contrasena) == 64:
            self.contrasena = contrasena
        else:
            self.contrasena = encriptado(contrasena)

        self.nombre = nombre
        self.apellido = apellido
        self.dni = dni
        self.ssn = ssn
        self.IBAN = IBAN

        # VALIDACIONES (Solo si se aportan datos)
        if dni:
            self.validar_dni(dni)

    def validar_dni(self, dni):
        if len(dni) != 9:
            print("Aviso: Longitud de DNI incorrecta")
        else:
            numeros = dni[:8]
            letra = dni[8].upper()
            if not numeros.isdigit() or not letra.isalpha():
                print("Aviso: Formato de DNI incorrecto")

    def validar_credenciales(self, correo, contraseña) -> bool:
        """Valida las credenciales del usuario y guarda el usuario actual si es exitoso."""
        if correo == self.correo and verificar_password(contraseña, self.contrasena):
            guardar_usuario_actual(self.to_dict())
            print(f"Sesión iniciada y usuario actual guardado: {self.correo}")
            return True
        return False

    def cerrar_sesion(self):
        eliminar_usuario_actual()

    def to_dict(self):
        """Convierte el usuario a diccionario."""
        return {
            "id": self.id,
            "correo": self.correo,
            "contrasena": self.contrasena,
            "tipo": self.tipo,
            "nombre": self.nombre,
            "apellido": self.apellido,
            "dni": self.dni,
            "ssn": self.ssn,
            "IBAN": self.IBAN
        }

    def guardar_usuario(self):
        """Guarda el usuario en la base de datos."""
        database = obtener_db()
        if not database:
            print("Error: No hay conexión a la BD")
            return

        # Verificar si el usuario ya existe
        usuario_existente = database.get_usuario_by_correo(self.correo)
        
        if usuario_existente:
            print(f"El usuario {self.correo} ya existe. No se duplicará.")
            return
        
        # Insertar nuevo usuario
        usuario_id = database.insertar_usuario(
            email=self.correo,
            contrasena=self.contrasena,
            tipo=self.tipo,
            nombre=self.nombre,
            last_name=self.apellido,
            dni=self.dni
        )
        self.id = usuario_id
        print(f"Usuario '{self.correo}' guardado exitosamente en la BD con ID {usuario_id}.")

    def actualizar_usuario(self):
        """Actualiza los datos del usuario en la base de datos."""
        if not self.id:
            print("Error: El usuario no tiene ID. No se puede actualizar.")
            return
        
        database = obtener_db()
        if not database:
            print("Error: No hay conexión a la BD")
            return
        
        data = {
            'name': self.nombre,
            'last_name': self.apellido,
            'password_hash': self.contrasena,
            'DNI': self.dni
        }
        database.actualizar_usuario(self.id, data)
        print(f"Usuario '{self.correo}' actualizado en la BD.")

    def eliminar_usuario(self):
        """Elimina el usuario de la base de datos."""
        if not self.id:
            print("Error: El usuario no tiene ID. No se puede eliminar.")
            return
        
        database = obtener_db()
        if not database:
            print("Error: No hay conexión a la BD")
            return
        
        database.eliminar_usuario(self.id)
        print(f"Usuario '{self.correo}' eliminado de la BD.")

    # Getters y Setters
    def getId(self): return self.id
    def getNombre(self): return self.nombre
    def getCorreo(self): return self.correo
    def getClave(self): return self.contrasena
    def getApellido(self): return self.apellido
    def getDni(self): return self.dni
    def getSsn(self): return self.ssn
    def getIBAN(self): return self.IBAN

    def setNombre(self, nombre):
        self.nombre = nombre

    def setApellido(self, apellido):
        self.apellido = apellido

    def setCorreo(self, correo):
        if "@" in correo:
            self.correo = correo
        else:
            print("Correo inválido, no se actualizó.")

    def setDni(self, dni):
        if len(dni) == 9 and dni[:8].isdigit() and dni[8].isalpha():
            self.dni = dni
        else:
            print("DNI inválido, no se actualizó.")

    def setSsn(self, ssn):
        self.ssn = ssn

    def setIBAN(self, IBAN):
        self.IBAN = IBAN

    def setClave(self, clave):
        """Encripta y actualiza la contraseña"""
        self.contrasena = encriptado(clave)


# === Clases hijas ===

class UsuarioPromedio(TipoUsuario):
    def __init__(self, correo: str, contrasena: str, **kwargs):
        super().__init__(correo, contrasena, tipo=1, **kwargs)


class Trabajador(TipoUsuario):
    def __init__(self, correo: str, contrasena: str, **kwargs):
        super().__init__(correo, contrasena, tipo=2, **kwargs)


class Administrador(TipoUsuario):
    def __init__(self, correo: str = "admin@checkit.com", contrasena: str = "admin123", **kwargs):
        super().__init__(correo, contrasena, tipo=3, **kwargs)


# ============================================================================
# FUNCIONES DE UTILIDAD PARA USUARIOS
# ============================================================================

def cargar_usuarios() -> List[TipoUsuario]:
    """Carga todos los usuarios desde la BD instanciando las clases correctas."""
    database = obtener_db()
    if not database:
        print("Error: No hay conexión a la BD")
        return []
    
    usuarios_bd = database.get_all_usuarios()
    usuarios_objetos = []

    for u in usuarios_bd:
        tipo = u.get("type", "Usuario Promedio")
        correo = u.get("mail")
        contrasena = u.get("password_hash")
        usuario_id = u.get("id")

        if correo and contrasena:
            kwargs = {
                'nombre': u.get("name"),
                'apellido': u.get("last_name"),
                'dni': u.get("DNI"),
                'id': usuario_id
            }
            
            if tipo == "Trabajador":
                usuarios_objetos.append(Trabajador(correo, contrasena, **kwargs))
            elif tipo == "Administrador":
                usuarios_objetos.append(Administrador(correo, contrasena, **kwargs))
            else:
                usuarios_objetos.append(UsuarioPromedio(correo, contrasena, **kwargs))

    return usuarios_objetos


def crear_usuario(correo: str, contrasena: str, tipo: str, **kwargs) -> TipoUsuario:
    """Crea un nuevo usuario de cualquier tipo con campos opcionales."""
    tipo_lower = tipo.lower()
    if tipo_lower == "trabajador":
        usuario = Trabajador(correo, contrasena, **kwargs)
    elif tipo_lower == "administrador":
        usuario = Administrador(correo, contrasena, **kwargs)
    else:
        usuario = UsuarioPromedio(correo, contrasena, **kwargs)

    # Guardamos explícitamente
    usuario.guardar_usuario()
    return usuario


# ============================================================================
# FUNCIONES DE SENSORES
# ============================================================================

def cargar_sensores_bd() -> List[Dict]:
    """Carga todos los sensores desde la base de datos."""
    database = obtener_db()
    if not database:
        return []
    return database.get_all_sensores()

def cargar_sensores_por_zona(zona: int) -> List[Dict]:
    """Carga todos los sensores de una zona específica desde la BD."""
    database = obtener_db()
    if not database:
        return []
    return database.get_sensores_by_zone(zona)

def guardar_sensor_bd(zone: int, value: float, max_val: float, min_val: float,
                     working: float, sensor_type: int) -> int:
    """Inserta un sensor en la base de datos."""
    database = obtener_db()
    if not database:
        return -1
    return database.insertar_sensor(zone, value, max_val, min_val, working, sensor_type)

def actualizar_sensor_bd(sensor_id: int, value: float):
    """Actualiza el valor de un sensor en la BD."""
    database = obtener_db()
    if database:
        database.actualizar_valor_sensor(sensor_id, value)

def eliminar_sensor_bd(sensor_id: int):
    """Elimina un sensor de la BD."""
    database = obtener_db()
    if database:
        database.eliminar_sensor(sensor_id)

def cargar_sensores_json():
    """Lee sensores desde Sensors_DATA.json (para migración inicial)."""
    ruta_archivo = "Sensors_DATA.json"
    if not os.path.exists(ruta_archivo):
        print(f"Error: No se encontró el archivo {ruta_archivo}")
        return []
    
    try:
        with open(ruta_archivo, 'r', encoding='utf-8') as file:
            return json.load(file)
    except Exception as e:
        print(f"Error leyendo JSON de sensores: {e}")
        return []

def migrar_sensores_json_a_bd():
    """Migra todos los sensores del JSON a la base de datos."""
    sensores_json = cargar_sensores_json()
    database = obtener_db()
    
    if not database:
        print("Error: No hay conexión a la BD")
        return
    
    for sensor in sensores_json:
        try:
            guardar_sensor_bd(
                zone=sensor.get('sector', 1),
                value=sensor.get('valor', 0),
                max_val=sensor.get('max', 100),
                min_val=sensor.get('minimum', 0),
                working=sensor.get('working', 1),
                sensor_type=sensor.get('tipo', 1)
            )
        except Exception as e:
            print(f"Error migrando sensor: {e}")
    
    print(f"Se migraron {len(sensores_json)} sensores a la BD.")


def obtener_historico_vista():
    """Consulta exclusiva para las gráficas leyendo de visualizacion_sensores con diagnóstico"""
    print("DEBUG: Entrando en la función obtener_historico_vista...")
    try:
        # 1. Comprobar si obtener_db() devuelve algo
        database = obtener_db()
        print(f"DEBUG: Instancia de la base de datos: {database}")

        if not database:
            print("⚠️ Error: No hay conexión a la BD para la gráfica.")
            return []

        # 2. Intentar lanzar la consulta
        query = "SELECT id_sensor, date, dato FROM visualizacion_sensor ORDER BY date ASC;"
        print("DEBUG: Lanzando la query a la vista...")
        registros = database.execute_query(query)

        print(f"✅ Se han cargado {len(registros)} datos del histórico.")
        return registros

    except Exception as e:
        # 🚨 ESTA LÍNEA ES CRÍTICA: Nos dirá el error real en la consola negra
        print(f"❌ ERROR CRÍTICO EN LA GRÁFICA: {e}")
        import traceback
        traceback.print_exc()  # Esto pintará la línea exacta del fallo
        return []
