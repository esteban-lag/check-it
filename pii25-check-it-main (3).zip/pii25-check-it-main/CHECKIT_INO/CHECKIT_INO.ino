#define USING_WIFI         true
#define WIFI_USE_ESP32     true 
#define MYSQL_USE_ESP32    true

#include <WiFi.h>
#include <MySQL_Generic.h>
#include <DHT.h>

// --- MAPEO DE IDs SEGÚN TU TABLA ---
#define ID_TEMP    0  // Tipo 1
#define ID_HUM     1  // Tipo 2
#define ID_DIST    2  // Tipo 3
#define ID_AIR     3  // Tipo 4
#define ID_LIGHT   4  // Tipo 5
#define ID_FAN     5  // Tipo 6

// --- PINES ---
#define PIN_DHT     4
#define PIN_TRIG    5
#define PIN_ECHO    18
#define PIN_MQ135   34
#define PIN_LDR     35
#define PIN_FAN     21

#define TEMP_ON    28.0
#define TEMP_OFF   25.0
#define SAMPLE_MS  5000UL
#define DHT_TYPE   DHT11

DHT dht(PIN_DHT, DHT_TYPE);
unsigned long lastSample = 0;
bool fanRunning = false;

// --- RED Y SQL ---
char ssid[] = "PORTATIL_PABLO 1682";
char pass[] = "2?4a7L67";
char user[] = "pablo_esp";
char password[] = "12345";
char db_name[] = "pii26-check-it"; 
IPAddress server_ip(192, 168, 137, 1);
uint16_t server_port = 3306;

WiFiClient client;
MySQL_Connection conn((Client *)&client);

float leerDistancia() {
  digitalWrite(PIN_TRIG, LOW);
  delayMicroseconds(2);
  digitalWrite(PIN_TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(PIN_TRIG, LOW);
  long dur = pulseIn(PIN_ECHO, HIGH, 30000UL);
  if (dur == 0) return -1.0;
  return dur * 0.034 / 2.0;
}

// Función que actualiza el presente y guarda en el histórico
void procesarDatoSensor(int id, float valor) {
  char query[256];
  MySQL_Query query_mem = MySQL_Query(&conn);

  // 1. Actualizar el valor actual (Tabla sensor)
  sprintf(query, "UPDATE `%s`.sensor SET value = %.1f, working = 1 WHERE id = %d", db_name, valor, id);
  query_mem.execute(query);

  // 2. Insertar en el histórico (Tabla visualizacion_sensor)
  // La columna 'dato' en tu imagen es INT, el motor SQL lo convertirá automáticamente
  sprintf(query, "INSERT INTO `%s`.visualizacion_sensor (id_sensor, dato) VALUES (%d, %.1f)", db_name, id, valor);
  query_mem.execute(query);
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_TRIG, OUTPUT);
  pinMode(PIN_ECHO, INPUT);
  pinMode(PIN_FAN,  OUTPUT);
  dht.begin();
  
  WiFi.begin(ssid, pass);
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.println("\nWiFi OK");
}

void loop() {
  unsigned long now = millis();
  if (now - lastSample < SAMPLE_MS) return;
  lastSample = now;

  float temp  = dht.readTemperature();
  float hum   = dht.readHumidity();
  float dist  = leerDistancia();
  int   air   = analogRead(PIN_MQ135);
  int   light = analogRead(PIN_LDR);

  // Lógica ventilador
  if (!isnan(temp)) {
    if (!fanRunning && temp >= TEMP_ON) { fanRunning = true; digitalWrite(PIN_FAN, HIGH); }
    else if (fanRunning && temp <= TEMP_OFF) { fanRunning = false; digitalWrite(PIN_FAN, LOW); }
  }

  // Envío a SQL
  if (WiFi.status() == WL_CONNECTED) {
    if (conn.connect(server_ip, server_port, user, password)) {
      Serial.println("Actualizando sensores...");
      
      if (!isnan(temp)) procesarDatoSensor(ID_TEMP, temp);
      if (!isnan(hum))  procesarDatoSensor(ID_HUM, hum);
      
      procesarDatoSensor(ID_DIST, dist);
      procesarDatoSensor(ID_AIR, (float)air);
      procesarDatoSensor(ID_LIGHT, (float)light);
      procesarDatoSensor(ID_FAN, fanRunning ? 1.0 : 0.0);

      conn.close();
      Serial.println("Hecho.");
      delay(30000);
    } else {
      Serial.println("Error conexión SQL");
    }
  }
}