-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.32-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.17.0.7270
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para pii26-check-it
CREATE DATABASE IF NOT EXISTS `pii26-check-it` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `pii26-check-it`;

-- Volcando estructura para tabla pii26-check-it.chat
CREATE TABLE IF NOT EXISTS `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario1` int(11) NOT NULL,
  `id_usuario2` int(11) NOT NULL,
  `id_mensaje` int(11) NOT NULL,
  `fecha_creacion` datetime NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `id_usuario1` (`id_usuario1`),
  KEY `id_usuario2` (`id_usuario2`),
  KEY `id_mensaje` (`id_mensaje`),
  CONSTRAINT `chat_ibfk_1` FOREIGN KEY (`id_usuario1`) REFERENCES `usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chat_ibfk_2` FOREIGN KEY (`id_usuario2`) REFERENCES `usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `chat_ibfk_3` FOREIGN KEY (`id_mensaje`) REFERENCES `mensaje` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla pii26-check-it.chat: ~5 rows (aproximadamente)
DELETE FROM `chat`;
INSERT INTO `chat` (`id`, `id_usuario1`, `id_usuario2`, `id_mensaje`, `fecha_creacion`, `activo`) VALUES
	(7, 1, 4, 1, '2024-09-01 08:12:00', 1),
	(8, 2, 4, 2, '2024-09-01 08:16:00', 1),
	(9, 3, 5, 3, '2024-09-01 09:02:00', 1),
	(10, 1, 6, 4, '2024-09-02 10:22:00', 1),
	(11, 2, 7, 5, '2024-09-02 11:35:00', 1);

-- Volcando estructura para tabla pii26-check-it.configuracion_sensor
CREATE TABLE IF NOT EXISTS `configuracion_sensor` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ID_Admin` int(11) NOT NULL DEFAULT 0,
  `ID_Sensor` int(11) NOT NULL DEFAULT 0,
  `RED_WiFi` text NOT NULL,
  `Contraseña` text NOT NULL,
  `fecha` datetime NOT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `Índice 2` (`ID_Admin`),
  KEY `Índice 3` (`ID_Sensor`),
  CONSTRAINT `FK_configuracion_sensor_sensor` FOREIGN KEY (`ID_Sensor`) REFERENCES `sensor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_configuracion_sensor_usuario` FOREIGN KEY (`ID_Admin`) REFERENCES `usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla pii26-check-it.configuracion_sensor: ~4 rows (aproximadamente)
DELETE FROM `configuracion_sensor`;
INSERT INTO `configuracion_sensor` (`ID`, `ID_Admin`, `ID_Sensor`, `RED_WiFi`, `Contraseña`, `fecha`, `activo`) VALUES
	(1, 1, 1, 'WiFi_Admin_1', 'Clave1234', '2024-09-01 08:00:00', 1),
	(2, 2, 2, 'WiFi_Admin_2', 'Clave5678', '2024-09-01 09:00:00', 1),
	(3, 3, 3, 'WiFi_Admin_3', 'Clave9012', '2024-09-01 10:00:00', 1),
	(4, 1, 4, 'WiFi_Admin_1', 'Clave3456', '2024-09-02 08:00:00', 1);

-- Volcando estructura para tabla pii26-check-it.mensaje
CREATE TABLE IF NOT EXISTS `mensaje` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla pii26-check-it.mensaje: ~6 rows (aproximadamente)
DELETE FROM `mensaje`;
INSERT INTO `mensaje` (`id`, `content`, `date`) VALUES
	(7, 'Hola, ¿cómo va el estado de los sensores?', '2024-09-01 08:10:00'),
	(8, 'El sensor de zona 1 muestra valores estables.', '2024-09-01 08:15:00'),
	(9, 'Necesitamos revisar la configuración del WiFi.', '2024-09-01 09:00:00'),
	(10, 'Nueva noticia publicada para el equipo.', '2024-09-02 10:20:00'),
	(11, 'Recordatorio: calibración programada mañana.', '2024-09-02 11:30:00'),
	(12, 'Esto va?', '2026-05-15 21:29:06');

-- Volcando estructura para tabla pii26-check-it.noticia
CREATE TABLE IF NOT EXISTS `noticia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_usuario_creador` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `using` tinyint(4) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `visible` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_noticia_usuario` (`id_usuario_creador`),
  CONSTRAINT `fk_noticia_usuario` FOREIGN KEY (`id_usuario_creador`) REFERENCES `usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla pii26-check-it.noticia: ~4 rows (aproximadamente)
DELETE FROM `noticia`;
INSERT INTO `noticia` (`id`, `id_usuario_creador`, `title`, `content`, `using`, `date`, `visible`) VALUES
	(4, 1, 'Mantenimiento programado', 'El mantenimiento de los sensores se realizará el próximo lunes a las 09:00.', 1, '2024-09-03 08:00:00', 1),
	(5, 2, 'Actualización de firmware', 'Se ha actualizado el firmware de los controles de zona 2.', 1, '2024-09-03 10:30:00', 1),
	(6, 3, 'Alerta de temperatura', 'Se ha detectado un pico de temperatura en la zona 1.', 1, '2024-09-04 12:00:00', 1),
	(7, 1, 'Nuevo acceso para empleados', 'Se ha añadido un nuevo permiso de acceso para trabajadores.', 1, '2024-09-05 14:20:00', 0);

-- Volcando estructura para tabla pii26-check-it.sensor
CREATE TABLE IF NOT EXISTS `sensor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zone` int(11) NOT NULL,
  `value` float NOT NULL,
  `max` float NOT NULL,
  `minimum` float NOT NULL,
  `working` float NOT NULL,
  `type` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla pii26-check-it.sensor: ~7 rows (aproximadamente)
DELETE FROM `sensor`;
INSERT INTO `sensor` (`id`, `zone`, `value`, `max`, `minimum`, `working`, `type`, `fecha`) VALUES
	(0, 1, 24.5, 40, 0, 1, 1, '2026-05-15 18:54:55'),
	(1, 1, 46, 60, 30, 1, 2, '2026-05-15 18:54:55'),
	(2, 1, 65.6, 100, 0, 1, 3, '2026-05-15 18:54:56'),
	(3, 1, 4095, 4096, 0, 1, 4, '2026-05-15 18:54:57'),
	(4, 1, 2093, 4096, 0, 1, 5, '2026-05-15 18:54:57'),
	(5, 1, 0, 1, 0, 1, 6, '2026-05-15 16:14:40'),
	(6, 1, 423, 4096, 0, 1, 7, '2026-05-17 19:22:49');

-- Volcando estructura para tabla pii26-check-it.trabajador
CREATE TABLE IF NOT EXISTS `trabajador` (
  `id_trabajador` int(11) NOT NULL,
  `IBAN` varchar(24) NOT NULL,
  `Social_Security_number` varchar(15) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  PRIMARY KEY (`id_trabajador`),
  UNIQUE KEY `IBAN` (`IBAN`),
  UNIQUE KEY `Social_Security_number` (`Social_Security_number`),
  UNIQUE KEY `id_usuario` (`id_usuario`),
  CONSTRAINT `fk_trabajador_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla pii26-check-it.trabajador: ~4 rows (aproximadamente)
DELETE FROM `trabajador`;
INSERT INTO `trabajador` (`id_trabajador`, `IBAN`, `Social_Security_number`, `id_usuario`) VALUES
	(1, 'ES7620770024003102575766', '12345678901', 4),
	(2, 'ES9820385778983000760236', '23456789012', 5),
	(3, 'ES9121000418450200051332', '34567890123', 6),
	(4, 'ES6621000418401234567891', '45678901234', 7);

-- Volcando estructura para tabla pii26-check-it.usuario
CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `DNI` varchar(9) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL DEFAULT '000000000',
  `picture` blob NOT NULL DEFAULT X'89504e470d0a1a0a0000000d49484452',
  `type` int(11) NOT NULL DEFAULT 3,
  `fecha_creación` timestamp NOT NULL DEFAULT current_timestamp(),
  `cuenta_activa` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mail` (`mail`),
  UNIQUE KEY `DNI` (`DNI`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla pii26-check-it.usuario: ~21 rows (aproximadamente)
DELETE FROM `usuario`;
INSERT INTO `usuario` (`id`, `name`, `last_name`, `DNI`, `password_hash`, `mail`, `phone`, `picture`, `type`, `fecha_creación`, `cuenta_activa`) VALUES
	(25, 'Pablo', 'Rodriguez', NULL, 'cb03c1406c50738d42fbaf7f33faf5eaf28714a0db8c814397bc028c919d56c4', 'pablorodriguezmarin123456789@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 2, '0000-00-00 00:00:00', 1),
	(26, 'Paula', 'Osuna', NULL, '7cf007c48cb8a888b6ded3383af1dab2670623ebbc6f2224b3b02cbe6ccc9de7', 'paulaosuna@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 3, '0000-00-00 00:00:00', 1),
	(27, 'Manuel', 'Perez', NULL, '4d151a0bd55c1dc160033d4daed0e16a3f15a89ba5c2337bdfe8c7464dc17244', 'manuelperez@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 3, '0000-00-00 00:00:00', 1),
	(28, 'Carmen', 'Ruiz', NULL, '5c7bf455b17dd02a1cf8227aa6f82e71125a0beb7feeb90f582d6a9b381137ac', 'carmenruiz@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 3, '0000-00-00 00:00:00', 1),
	(29, 'Jorge', 'Garcia', NULL, 'ed053e2bac819200a680f635b6c4c4b3c9b32dec920422b2c072e16758dfad83', 'jorgegarcia@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 3, '0000-00-00 00:00:00', 1),
	(30, 'Lucia', 'Lopez', NULL, '522df80039c805a3e244eee320ee644e11d05ea1650de493bcc93c913cad6454', 'lucialopez@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 3, '0000-00-00 00:00:00', 1),
	(31, 'Antonio', 'Diaz', NULL, '11a9f985dcc0c6808f0b1f37015ab58a1244cc328983ed6fb9d5be4da6035f2e', 'antoniodiaz@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 2, '0000-00-00 00:00:00', 1),
	(32, 'Maria', 'Gomez', NULL, '70ae44bcb247ac5c3c0f5258a5abd3ca896492dce06808593c6d39892c2ba688', 'mariagomez@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 2, '0000-00-00 00:00:00', 1),
	(33, 'David', 'Martin', NULL, '0845f2c3ad1a01ba70348625612230887e5131f9ba16819508cead7dd2876d67', 'davidmartin@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 2, '0000-00-00 00:00:00', 1),
	(34, 'Laura', 'Sanchez', NULL, '043442ef2c3800d70cb4d73bb3d467189621fec51150c11704c0233080b80494', 'laurasanchez@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 2, '0000-00-00 00:00:00', 1),
	(35, 'Carlos', 'Romero', NULL, '38e2b127c1085b487425d2070fdd70c92dc093afa2a161708a055ecce83239c5', 'carlosromero@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 2, '0000-00-00 00:00:00', 1),
	(36, 'Ana', 'Torres', NULL, '44aab0c701e0769d0ba136b3e59b78746197fdf397d133ddde0ae82c4eebce74', 'anatorres@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 1, '0000-00-00 00:00:00', 1),
	(37, 'Luis', 'Navarro', NULL, '0e4f7ba5530980726c7b29c12f189bce43cfcbf10283514ae51aa689ac1a54bc', 'luisnavarro@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 1, '0000-00-00 00:00:00', 1),
	(38, 'Marta', 'Castro', NULL, '24e152d33e12f2fcc97d948946fcbc6db6865e2a4b1d3eb230685bcf256aa3ba', 'martacastro@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 1, '0000-00-00 00:00:00', 1),
	(39, 'Jose', 'Ortiz', NULL, 'a419112e83abf8cf74903db6ab3447b6928626ddca9bcc6e4a4ee36427bf8164', 'joseortiz@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 1, '0000-00-00 00:00:00', 1),
	(40, 'Elena', 'Rubio', NULL, '4d56a53e7c05c5ddf3052f9020a8471255cb23781ede85ec105ac3ed28329a2b', 'elenarubio@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 1, '0000-00-00 00:00:00', 1),
	(41, 'Sergio', 'Molina', NULL, '39473bbe30b6d120172f8e0bbfd1bc420c878c32730e4e9fedfabc9963dece66', 'sergiomolina@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 1, '0000-00-00 00:00:00', 1),
	(42, 'Sara', 'Delgado', NULL, '0ea0374e91d30bc1615e788f8991f6fcc01a996b5ec74b77f3e18f923604ab53', 'saradelgado@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 1, '0000-00-00 00:00:00', 1),
	(43, 'Javier', 'Ramos', NULL, '2a495fe53f965f37ae436273642737810325b3b731f6dbd96d938936ac048a02', 'javierramos@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 1, '0000-00-00 00:00:00', 1),
	(44, 'Rosa', 'Gil', NULL, '74e40c1400cbbdd164724b32121e19562d85a93d69f3a598b28f2787bf5757cc', 'rosagil@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 1, '0000-00-00 00:00:00', 1),
	(45, 'Carmen', 'Cano', NULL, '6bfcc2f575ee7e7d531d4c96640e12b337bdc3050e08bda11f45276a50ab94a3', 'canobermell@gmail.com', '000000000', _binary 0x89504e470d0a1a0a0000000d49484452, 2, '2026-05-17 14:35:26', 1);

-- Volcando estructura para tabla pii26-check-it.visualizacion_noticia
CREATE TABLE IF NOT EXISTS `visualizacion_noticia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_lector` int(11) NOT NULL,
  `id_noticia` int(11) NOT NULL,
  `date` date NOT NULL,
  `edit_type` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_lector` (`id_lector`),
  KEY `id_noticia` (`id_noticia`),
  CONSTRAINT `visualizacion_noticia_ibfk_1` FOREIGN KEY (`id_lector`) REFERENCES `usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `visualizacion_noticia_ibfk_2` FOREIGN KEY (`id_noticia`) REFERENCES `noticia` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla pii26-check-it.visualizacion_noticia: ~6 rows (aproximadamente)
DELETE FROM `visualizacion_noticia`;
INSERT INTO `visualizacion_noticia` (`id`, `id_lector`, `id_noticia`, `date`, `edit_type`) VALUES
	(7, 6, 1, '2024-09-03', 1),
	(8, 7, 1, '2024-09-03', 2),
	(9, 8, 2, '2024-09-03', 1),
	(10, 9, 3, '2024-09-04', 1),
	(11, 10, 1, '2024-09-05', 1),
	(12, 6, 3, '2024-09-05', 2);

-- Volcando estructura para tabla pii26-check-it.visualizacion_sensor
CREATE TABLE IF NOT EXISTS `visualizacion_sensor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_sensor` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `dato` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_sensor` (`id_sensor`),
  CONSTRAINT `visualizacion_sensor_ibfk_2` FOREIGN KEY (`id_sensor`) REFERENCES `sensor` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=272 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla pii26-check-it.visualizacion_sensor: ~222 rows (aproximadamente)
DELETE FROM `visualizacion_sensor`;
INSERT INTO `visualizacion_sensor` (`id`, `id_sensor`, `date`, `dato`) VALUES
	(7, 1, '2024-08-31 22:00:00', 0),
	(8, 2, '2024-08-31 22:00:00', 0),
	(10, 4, '2024-09-01 22:00:00', 0),
	(11, 5, '2024-09-01 22:00:00', 0),
	(13, 0, '2026-05-17 19:51:40', 20),
	(14, 1, '2026-05-15 18:47:03', 0),
	(15, 2, '2026-05-15 18:47:04', -1),
	(16, 3, '2026-05-15 18:47:05', 4095),
	(17, 4, '2026-05-15 18:47:05', 2276),
	(18, 5, '2026-05-15 18:47:06', 0),
	(19, 0, '2026-05-15 18:47:08', 23),
	(20, 1, '2026-05-15 18:47:08', 48),
	(21, 2, '2026-05-15 18:47:09', -1),
	(22, 3, '2026-05-15 18:47:10', 4095),
	(23, 4, '2026-05-15 18:47:10', 2292),
	(24, 5, '2026-05-15 18:47:11', 0),
	(25, 0, '2026-05-15 18:47:13', 24),
	(26, 1, '2026-05-15 18:47:13', 48),
	(27, 2, '2026-05-15 18:47:14', -1),
	(28, 3, '2026-05-15 18:47:15', 4095),
	(29, 4, '2026-05-15 18:47:15', 2285),
	(30, 5, '2026-05-15 18:47:16', 0),
	(31, 0, '2026-05-15 18:47:18', 23),
	(32, 1, '2026-05-15 18:47:18', 48),
	(33, 2, '2026-05-15 18:47:19', -1),
	(34, 3, '2026-05-15 18:47:20', 4095),
	(35, 4, '2026-05-15 18:47:20', 2204),
	(36, 5, '2026-05-15 18:47:21', 0),
	(37, 0, '2026-05-15 18:47:23', 24),
	(38, 1, '2026-05-15 18:47:23', 48),
	(39, 2, '2026-05-15 18:47:24', -1),
	(40, 3, '2026-05-15 18:47:25', 4095),
	(41, 4, '2026-05-15 18:47:30', 2219),
	(42, 5, '2026-05-15 18:47:30', 0),
	(43, 0, '2026-05-15 18:47:32', 24),
	(44, 1, '2026-05-15 18:47:32', 48),
	(45, 2, '2026-05-15 18:47:33', -1),
	(46, 3, '2026-05-15 18:47:33', 4095),
	(47, 4, '2026-05-15 18:47:34', 2167),
	(48, 5, '2026-05-15 18:47:35', 0),
	(49, 0, '2026-05-15 18:47:37', 24),
	(50, 1, '2026-05-15 18:47:37', 48),
	(51, 2, '2026-05-15 18:47:38', -1),
	(52, 3, '2026-05-15 18:47:38', 4095),
	(53, 4, '2026-05-15 18:47:39', 2192),
	(54, 5, '2026-05-15 18:47:40', 0),
	(55, 0, '2026-05-15 18:47:42', 24),
	(56, 1, '2026-05-15 18:47:42', 48),
	(57, 2, '2026-05-15 18:47:43', -1),
	(58, 3, '2026-05-15 18:47:43', 4095),
	(59, 4, '2026-05-15 18:47:44', 2247),
	(60, 5, '2026-05-15 18:47:45', 0),
	(61, 0, '2026-05-15 18:47:47', 23),
	(62, 1, '2026-05-15 18:47:47', 48),
	(63, 2, '2026-05-15 18:47:48', -1),
	(64, 3, '2026-05-15 18:47:48', 4095),
	(65, 4, '2026-05-15 18:47:49', 2298),
	(66, 5, '2026-05-15 18:47:50', 0),
	(67, 0, '2026-05-15 18:47:52', 23),
	(68, 1, '2026-05-15 18:47:52', 48),
	(69, 2, '2026-05-15 18:47:53', -1),
	(70, 3, '2026-05-15 18:47:53', 4095),
	(71, 4, '2026-05-15 18:47:54', 2266),
	(72, 5, '2026-05-15 18:47:55', 0),
	(73, 0, '2026-05-15 18:47:57', 24),
	(74, 1, '2026-05-15 18:47:57', 48),
	(75, 2, '2026-05-15 18:47:58', -1),
	(76, 3, '2026-05-15 18:47:58', 4095),
	(77, 4, '2026-05-15 18:47:59', 2199),
	(78, 5, '2026-05-15 18:48:00', 0),
	(79, 0, '2026-05-15 18:48:02', 23),
	(80, 1, '2026-05-15 18:48:02', 48),
	(81, 2, '2026-05-15 18:48:03', -1),
	(82, 3, '2026-05-15 18:48:03', 4095),
	(83, 4, '2026-05-15 18:48:04', 2187),
	(84, 5, '2026-05-15 18:48:05', 0),
	(85, 0, '2026-05-15 18:48:07', 23),
	(86, 1, '2026-05-15 18:48:07', 47),
	(87, 2, '2026-05-15 18:48:08', -1),
	(88, 3, '2026-05-15 18:48:08', 4095),
	(89, 4, '2026-05-15 18:48:09', 1965),
	(90, 5, '2026-05-15 18:48:10', 0),
	(91, 0, '2026-05-17 19:51:43', 23),
	(92, 1, '2026-05-15 18:48:12', 0),
	(93, 2, '2026-05-15 18:48:13', -1),
	(94, 3, '2026-05-15 18:48:13', 4095),
	(95, 4, '2026-05-15 18:48:14', 1535),
	(96, 5, '2026-05-15 18:48:15', 0),
	(97, 0, '2026-05-15 18:48:17', 24),
	(98, 1, '2026-05-15 18:48:17', 48),
	(99, 2, '2026-05-15 18:48:18', 456),
	(100, 3, '2026-05-15 18:48:18', 4095),
	(101, 4, '2026-05-15 18:48:19', 1235),
	(102, 5, '2026-05-15 18:48:20', 0),
	(103, 0, '2026-05-15 18:48:22', 24),
	(104, 1, '2026-05-15 18:48:22', 48),
	(105, 2, '2026-05-15 18:48:23', -1),
	(106, 3, '2026-05-15 18:48:23', 4095),
	(107, 4, '2026-05-15 18:48:24', 2198),
	(108, 5, '2026-05-15 18:48:25', 0),
	(109, 0, '2026-05-15 18:48:26', 24),
	(110, 1, '2026-05-15 18:48:27', 49),
	(111, 2, '2026-05-15 18:48:28', 16),
	(112, 3, '2026-05-15 18:48:28', 4095),
	(113, 4, '2026-05-15 18:48:29', 2091),
	(114, 5, '2026-05-15 18:48:30', 0),
	(115, 0, '2026-05-15 18:48:32', 23),
	(116, 1, '2026-05-15 18:48:32', 49),
	(117, 2, '2026-05-15 18:48:33', -1),
	(118, 0, '2026-05-17 19:51:46', 22),
	(119, 1, '2026-05-15 18:51:21', 0),
	(120, 2, '2026-05-15 18:51:21', 8),
	(121, 3, '2026-05-17 19:57:59', 4095),
	(122, 4, '2026-05-15 18:51:22', 2186),
	(123, 5, '2026-05-15 18:51:23', 0),
	(124, 0, '2026-05-15 18:51:25', 24),
	(125, 1, '2026-05-15 18:51:26', 46),
	(126, 2, '2026-05-15 18:51:26', 8),
	(127, 3, '2026-05-17 19:59:57', 4095),
	(128, 4, '2026-05-15 18:51:27', 2220),
	(129, 5, '2026-05-15 18:51:28', 0),
	(130, 0, '2026-05-15 18:51:30', 25),
	(131, 1, '2026-05-15 18:51:31', 46),
	(132, 2, '2026-05-15 18:51:31', 8),
	(133, 3, '2026-05-15 18:51:32', 4095),
	(134, 4, '2026-05-15 18:51:32', 2170),
	(135, 5, '2026-05-15 18:51:33', 0),
	(136, 0, '2026-05-15 18:51:35', 24),
	(137, 1, '2026-05-15 18:51:36', 46),
	(138, 0, '2026-05-15 18:52:01', 24),
	(139, 1, '2026-05-15 18:52:02', 46),
	(140, 2, '2026-05-15 18:52:03', 9),
	(141, 3, '2026-05-15 18:52:03', 4095),
	(142, 4, '2026-05-15 18:52:04', 2102),
	(143, 5, '2026-05-15 18:52:04', 0),
	(144, 0, '2026-05-15 18:52:08', 25),
	(145, 1, '2026-05-15 18:52:08', 46),
	(146, 2, '2026-05-15 18:52:09', 9),
	(147, 3, '2026-05-15 18:52:09', 4095),
	(148, 4, '2026-05-15 18:52:10', 2160),
	(149, 5, '2026-05-15 18:52:11', 0),
	(150, 0, '2026-05-15 18:52:14', 25),
	(151, 1, '2026-05-15 18:52:15', 46),
	(152, 2, '2026-05-15 18:52:15', 9),
	(153, 3, '2026-05-15 18:52:16', 4095),
	(154, 4, '2026-05-15 18:52:16', 2202),
	(155, 5, '2026-05-15 18:52:17', 0),
	(156, 0, '2026-05-17 19:39:46', 20),
	(157, 1, '2026-05-15 18:52:21', 46),
	(158, 2, '2026-05-15 18:52:21', 9),
	(159, 3, '2026-05-15 18:52:22', 4095),
	(160, 4, '2026-05-15 18:52:23', 2090),
	(161, 5, '2026-05-15 18:52:23', 0),
	(162, 0, '2026-05-15 18:52:26', 25),
	(163, 1, '2026-05-15 18:52:27', 46),
	(164, 2, '2026-05-15 18:52:28', 9),
	(165, 3, '2026-05-15 18:52:28', 4095),
	(166, 4, '2026-05-15 18:52:29', 2103),
	(167, 5, '2026-05-15 18:52:29', 0),
	(168, 0, '2026-05-17 19:39:49', 23),
	(169, 1, '2026-05-15 18:52:33', 46),
	(170, 2, '2026-05-15 18:52:34', 9),
	(171, 3, '2026-05-15 18:52:35', 4095),
	(172, 4, '2026-05-15 18:52:35', 2064),
	(173, 5, '2026-05-15 18:52:36', 0),
	(174, 0, '2026-05-15 18:52:39', 25),
	(175, 1, '2026-05-15 18:52:40', 46),
	(176, 2, '2026-05-15 18:52:40', 9),
	(177, 3, '2026-05-15 18:52:41', 4095),
	(178, 4, '2026-05-15 18:52:41', 2055),
	(179, 5, '2026-05-15 18:52:42', 0),
	(180, 0, '2026-05-17 19:39:56', 24),
	(181, 1, '2026-05-15 18:52:46', 46),
	(182, 2, '2026-05-15 18:52:46', 9),
	(183, 0, '2026-05-17 19:40:00', 22),
	(184, 1, '2026-05-15 18:53:13', 46),
	(185, 2, '2026-05-15 18:53:14', 9),
	(186, 3, '2026-05-15 18:53:14', 4095),
	(187, 4, '2026-05-15 18:53:15', 2094),
	(188, 5, '2026-05-15 18:53:16', 0),
	(189, 0, '2026-05-17 19:40:05', 21),
	(190, 1, '2026-05-15 18:53:37', 46),
	(191, 2, '2026-05-15 18:53:38', 6),
	(192, 3, '2026-05-15 18:53:39', 4095),
	(193, 4, '2026-05-15 18:53:39', 2209),
	(194, 5, '2026-05-15 18:53:40', 0),
	(195, 0, '2026-05-17 19:18:15', 22),
	(196, 1, '2026-05-15 18:54:16', 0),
	(197, 2, '2026-05-15 18:54:17', 63),
	(198, 3, '2026-05-17 19:58:38', 4095),
	(199, 4, '2026-05-15 18:54:18', 2135),
	(200, 5, '2026-05-15 18:54:18', 0),
	(201, 0, '2026-05-17 19:40:09', 23),
	(202, 1, '2026-05-15 18:54:56', 46),
	(204, 3, '2026-05-15 18:54:57', 4095),
	(205, 4, '2026-05-15 18:54:57', 2093),
	(206, 6, '2026-05-17 19:28:09', 2300),
	(207, 6, '2026-05-17 19:29:10', 2200),
	(208, 6, '2026-05-17 19:29:10', 2500),
	(209, 6, '2026-05-17 19:29:10', 2980),
	(210, 6, '2026-05-17 19:30:37', 2870),
	(211, 6, '2026-05-17 19:29:10', 2800),
	(252, 6, '2026-05-17 19:30:10', 2815),
	(253, 6, '2026-05-17 19:31:10', 2830),
	(254, 6, '2026-05-17 19:32:10', 2790),
	(255, 6, '2026-05-17 19:33:10', 2785),
	(256, 6, '2026-05-17 19:34:10', 2805),
	(257, 6, '2026-05-17 19:35:10', 2840),
	(258, 6, '2026-05-17 19:36:10', 2860),
	(259, 6, '2026-05-17 19:37:10', 2825),
	(260, 6, '2026-05-17 19:38:10', 2795),
	(261, 6, '2026-05-17 19:39:10', 2800),
	(262, 6, '2026-05-17 19:40:10', 2810),
	(263, 6, '2026-05-17 19:41:10', 2850),
	(264, 6, '2026-05-17 19:42:10', 2875),
	(265, 6, '2026-05-17 19:43:10', 2845),
	(266, 6, '2026-05-17 19:44:10', 2820),
	(267, 6, '2026-05-17 19:45:10', 2780),
	(268, 6, '2026-05-17 19:46:10', 2765),
	(269, 6, '2026-05-17 19:47:10', 2799),
	(270, 6, '2026-05-17 19:48:10', 2820),
	(271, 6, '2026-05-17 19:49:10', 2835),
	(272, 0, '2026-05-17 19:30:10', 21),
	(273, 0, '2026-05-17 19:31:10', 21),
	(274, 0, '2026-05-17 19:32:10', 22),
	(275, 0, '2026-05-17 19:33:10', 23),
	(276, 0, '2026-05-17 19:34:10', 23),
	(277, 0, '2026-05-17 19:35:10', 24),
	(278, 0, '2026-05-17 19:36:10', 23),
	(279, 0, '2026-05-17 19:37:10', 22),
	(280, 0, '2026-05-17 19:38:10', 21),
	(281, 0, '2026-05-17 19:39:10', 20),
	(282, 0, '2026-05-17 19:40:10', 21),
	(283, 0, '2026-05-17 19:41:10', 21),
	(284, 0, '2026-05-17 19:42:10', 22),
	(285, 0, '2026-05-17 19:43:10', 22),
	(286, 0, '2026-05-17 19:44:10', 23),
	(287, 0, '2026-05-17 19:45:10', 23),
	(288, 0, '2026-05-17 19:46:10', 24),
	(289, 0, '2026-05-17 19:47:10', 23),
	(290, 0, '2026-05-17 19:48:10', 22),
	(291, 0, '2026-05-17 19:49:10', 22);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
