from datetime import datetime
from typing import List

from Sensor import Sensor, StatusSensor, TipoNotificacion


def intentar_reconexion(sensor: Sensor, minutos_inactivo: int = 15) -> bool:
    """Si el sensor está inactivo, lo marca como activo y guarda la reconexión."""
    if not sensor.esta_inactivo(minutos_inactivo):
        return False

    minutos = sensor.minutos_inactivo()
    status_anterior = sensor.status.value

    sensor.activo = True
    sensor.status = StatusSensor.WORKING
    sensor.actualizado_en = datetime.utcnow().isoformat()

    sensor.guardar_sensor()
    sensor.guardar_lectura("reconexion", {
        "minutos_inactivo": minutos,
        "status_anterior": status_anterior,
        "status_nuevo": sensor.status.value,
        "activo": sensor.activo
    })

    sensor.notificar(
        TipoNotificacion.INFO,
        f"Sensor {sensor.id} reconectado tras {minutos} minutos inactivo"
    )

    return True


def reconectar_sensores_inactivos(sensores: List[Sensor], minutos_inactivo: int = 15) -> int:
    """Revisa varios sensores y reconecta los que estén inactivos."""
    reconectados = 0
    for s in sensores:
        if intentar_reconexion(s, minutos_inactivo):
            reconectados += 1
    return reconectados
