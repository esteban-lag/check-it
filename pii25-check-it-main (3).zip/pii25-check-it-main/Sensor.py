from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
from typing import Optional, List
import json
import time  # para el loop de actualización


# enums
class TipoSensor(str, Enum):
    DISTANCIA = "distancia"
    HUMO = "humo"
    TEMPERATURA = "temperatura"
    MOVIMIENTO = "movimiento"
    CAMARA = "camara"
    LED_ESTADO = "led_estado"


class EstadoOcupacion(str, Enum):
    LIBRE = "libre"
    OCUPADA = "ocupada"


class NivelAlarma(str, Enum):
    NORMAL = "normal"
    AVISO = "aviso"
    ALARMA = "alarma"


class EstadoLED(str, Enum):
    VERDE = "verde"
    AMARILLO = "amarillo"
    ROJO = "rojo"


class EstadoConexion(str, Enum):
    ONLINE = "online"
    OFFLINE = "offline"


class StatusSensor(str, Enum):
    WORKING = "working"
    NOT_WORKING = "not_working"


class TipoNotificacion(str, Enum):
    INFO = "info"
    AVISO = "aviso"
    CRITICA = "critica"  # sería una notifiacion grave


# funciones para leer y escribir archivos JSON
def abrir_archivo_sensores():
    try:
        f = open("sensores.json", "r", encoding="utf-8")
        datos = json.load(f)
        f.close()
    except (FileNotFoundError, json.JSONDecodeError):
        datos = []
    return datos


def cerrar_archivo_sensores(datos):
    f = open("sensores.json", "w", encoding="utf-8")
        #again
    json.dump(datos, f, indent=4, ensure_ascii=False)
    f.close()

def abrir_archivo_sensores_fallos():
    try:
        f = open("estado_Sensores.json", "r", encoding="utf-8")
        datos = json.load(f)
        f.close()
    except (FileNotFoundError, json.JSONDecodeError):
        datos = []
    return datos


def cerrar_archivo_sensores_fallos(datos):
    f = open("sensores.json", "w", encoding="utf-8")
    json.dump(datos, f, indent=4, ensure_ascii=False)
    f.close()

def abrir_archivo_lecturas():
    try:
        f = open("lecturas_sensores.json", "r", encoding="utf-8")
        datos = json.load(f)
        f.close()
    except (FileNotFoundError, json.JSONDecodeError):
        datos = []
    return datos


def cerrar_archivo_lecturas(datos):
    f = open("lecturas_sensores.json", "w", encoding="utf-8")
    json.dump(datos, f, indent=4, ensure_ascii=False)
    f.close()


# funciones para histórico de estado
def abrir_historico_sensores():
    """Abre el histórico de estados de sensores"""
    try:
        with open("historico_sensores.json", "r", encoding="utf-8") as f:
            datos = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        datos = []
    return datos


def cerrar_historico_sensores(datos):
    """Guarda el histórico de estados"""
    with open("historico_sensores.json", "w", encoding="utf-8") as f:
        json.dump(datos, f, indent=4, ensure_ascii=False)


def registrar_cambio_sensor(sensor_id: str, tipo: str, zona: str, cambio: dict):
    """Registra un cambio de estado en el histórico"""
    historico = abrir_historico_sensores()
    
    registro = {
        "timestamp": datetime.utcnow().isoformat(),
        "sensor_id": sensor_id,
        "tipo": tipo,
        "zona": zona,
        "cambio": cambio
    }
    
    historico.append(registro)
    cerrar_historico_sensores(historico)


def obtener_historico_sensor(sensor_id: str, limite=None):
    """Obtiene el histórico de cambios de un sensor específico"""
    historico = abrir_historico_sensores()
    cambios = [r for r in historico if r["sensor_id"] == sensor_id]
    
    if limite:
        cambios = cambios[-limite:]
    
    return cambios


def obtener_historico_por_zona(zona: str, limite=None):
    """Obtiene el histórico de cambios en una zona específica"""
    historico = abrir_historico_sensores()
    cambios = [r for r in historico if r["zona"] == zona]
    
    if limite:
        cambios = cambios[-limite:]
    
    return cambios


# sistema de notificaciones
@dataclass
class Notificacion:
    tipo: TipoNotificacion
    mensaje: str
    sensor_id: str
    zona: str
    timestamp: str = field(default_factory=lambda: datetime.utcnow().isoformat())


class SistemaNotificaciones:
    # sistema centralizado para gestionar todas las notificaciones
    def __init__(self):
        self.notificaciones: List[Notificacion] = []

    def agregar(self, tipo: TipoNotificacion, mensaje: str, sensor_id: str, zona: str) -> None:
        notif = Notificacion(tipo, mensaje, sensor_id, zona)
        self.notificaciones.append(notif)
        print(f"[{tipo.value.upper()}] {zona} - {mensaje}")  # para debugging

    def obtener_criticas(self) -> List[Notificacion]:
        return [n for n in self.notificaciones if n.tipo == TipoNotificacion.CRITICA]

    def obtener_por_zona(self, zona: str) -> List[Notificacion]:
        return [n for n in self.notificaciones if n.zona == zona]

    def limpiar(self) -> None:
        self.notificaciones.clear()


# clase base
@dataclass
class Sensor:
    tipo: TipoSensor
    modelo: str
    precio: float
    id: str
    zona: str = ""
    activo: bool = True
    status: StatusSensor = StatusSensor.WORKING
    actualizado_en: str = field(default_factory=lambda: datetime.utcnow().isoformat())
    sistema_notif: Optional[SistemaNotificaciones] = field(default=None, repr=False)

    def notificar(self, tipo: TipoNotificacion, mensaje: str) -> None:
        # envía notificación al sistema si está configurado
        if self.sistema_notif:
            self.sistema_notif.agregar(tipo, mensaje, self.id, self.zona)


    def esta_inactivo(self, minutos=15) -> bool:
        """Verifica si el sensor está inactivo (sin actualización en X minutos)"""

    # ---- FUNCIONES DE INACTIVIDAD ----
    def esta_inactivo(self, minutos: int = 15) -> bool:
        """True si lleva al menos 'minutos' sin actualizarse."""

        try:
            ultima_act = datetime.fromisoformat(self.actualizado_en)
            tiempo_transcurrido = (datetime.utcnow() - ultima_act).total_seconds() / 60
            return tiempo_transcurrido >= minutos
        except:
            return False

    def minutos_inactivo(self) -> int:
        """Retorna cuántos minutos lleva sin actualizarse"""
        try:
            ultima_act = datetime.fromisoformat(self.actualizado_en)
            return int((datetime.utcnow() - ultima_act).total_seconds() / 60)
        except:
            return 0

    def registrar_cambio(self, cambio: dict) -> None:
        """Registra un cambio de estado en el histórico"""
        try:
            registrar_cambio_sensor(self.id, self.tipo.value, self.zona, cambio)
        except Exception:
            return False

    def minutos_inactivo(self) -> int:
        """Minutos desde la última actualización."""
        try:
            ultima_act = datetime.fromisoformat(self.actualizado_en)
            return int((datetime.utcnow() - ultima_act).total_seconds() / 60)
        except Exception:
            return 0
    # -----------------------------------

    def guardar_sensor(self) -> None:
        # guarda el sensor en el archivo JSON
        datos = abrir_archivo_sensores()

        # convierte el sensor a diccionario, excluyendo campos no serializables
        sensor_dict = {
            "tipo": self.tipo.value,
            "modelo": self.modelo,
            "precio": self.precio,
            "id": self.id,
            "zona": self.zona,
            "activo": self.activo,
            "status": self.status.value,
            "actualizado_en": self.actualizado_en
        }

        # añade campos específicos según tipo de sensor
        if hasattr(self, 'distancia_cm'):
            sensor_dict.update({
                "pin_trig": self.pin_trig,
                "pin_echo": self.pin_echo,
                "distancia_cm": self.distancia_cm,
                "umbral_ocupado_cm": self.umbral_ocupado_cm,
                "estado": self.estado.value
            })
        elif hasattr(self, 'densidad_ppm'):
            sensor_dict.update({
                "pin_analogico": self.pin_analogico,
                "pin_digital": self.pin_digital,
                "valor_adc": self.valor_adc,
                "densidad_ppm": self.densidad_ppm,
                "umbral_aviso_ppm": self.umbral_aviso_ppm,
                "umbral_alarma_ppm": self.umbral_alarma_ppm,
                "nivel": self.nivel.value
            })
        elif hasattr(self, 'temp_c'):
            sensor_dict.update({
                "pin_datos": self.pin_datos,
                "es_dht22": self.es_dht22,
                "temp_c": self.temp_c,
                "temp_ideal_c": self.temp_ideal_c,
                "min_c": self.min_c,
                "max_c": self.max_c,
                "humedad_porcentaje": self.humedad_porcentaje,
                "fuera_de_rango": self.fuera_de_rango,
                "alerta_activa": self.alerta_activa,
                "climatizacion_activa": self.climatizacion_activa
            })
        elif hasattr(self, 'movimiento'):
            sensor_dict.update({
                "pin_digital": self.pin_digital,
                "movimiento": self.movimiento,
                "ultima_actividad": self.ultima_actividad,
                "detecciones_totales": self.detecciones_totales,
                "detecciones_ultima_hora": self.detecciones_ultima_hora,
                "modo_seguridad_activo": self.modo_seguridad_activo,
                "alertas_generadas": self.alertas_generadas
            })
        elif hasattr(self, 'estado_conexion'):
            sensor_dict.update({
                "resolucion": self.resolucion,
                "estado_conexion": self.estado_conexion.value,
                "transmitiendo": self.transmitiendo,
                "url_stream": self.url_stream
            })
        elif hasattr(self, 'estado') and self.tipo == TipoSensor.LED_ESTADO:
            sensor_dict.update({
                "pin_pwm": self.pin_pwm,
                "estado": self.estado.value,
                "brillo": self.brillo,
                "sistema_asociado": self.sistema_asociado
            })

        # busca si ya existe el sensor
        encontrado = False
        for i, sensor in enumerate(datos):
            if sensor.get("id") == self.id:
                datos[i] = sensor_dict
                encontrado = True
                break

        # si no existe, lo añade
        if not encontrado:
            datos.append(sensor_dict)

        cerrar_archivo_sensores(datos)

    def guardar_lectura(self, tipo_lectura: str, valor: any) -> None:
        # guarda una lectura del sensor en el archivo de lecturas
        datos = abrir_archivo_lecturas()

        lectura = {
            "sensor_id": self.id,
            "zona": self.zona,
            "tipo_sensor": self.tipo.value,
            "tipo_lectura": tipo_lectura,
            "valor": valor,
            "timestamp": datetime.utcnow().isoformat()
        }

        datos.append(lectura)
        cerrar_archivo_lecturas(datos)
        
        # También registra en el histórico
        registrar_cambio_sensor(
            self.id,
            self.tipo.value,
            self.zona,
            {tipo_lectura: valor}
        )

    def error(self):
        datos = abrir_archivo_sensores_fallos()
        datos.append(self)
        cerrar_archivo_sensores_fallos()

    @staticmethod
    def buscar_sensor(sensor_id: str):
        # busca un sensor por su id en el archivo json
        datos = abrir_archivo_sensores()
        for sensor in datos:
            if sensor.get("id") == sensor_id:
                print(f"Sensor encontrado: {sensor}")
                return sensor
        print(f"Sensor {sensor_id} no encontrado")
        return None
    

    # añadido: metodo general
    def actualizar(self) -> None:
        pass


# subclases, adaptadas a los sensores que nos dió el profe

@dataclass
class SensorDistancia(Sensor):
    # sensor HC-SR04
    tipo: TipoSensor = TipoSensor.DISTANCIA

    # HC-SR04 necesita 2 pines
    pin_trig: int = 0  # pin que manda el pulso ultrasonico
    pin_echo: int = 0  # pin que recibe el eco de vuelta

    # mediciones
    distancia_cm: float = 0.0
    umbral_ocupado_cm: float = 30.0
    estado: EstadoOcupacion = EstadoOcupacion.LIBRE

    # actuador
    led_asociado: Optional['LEDIndicador'] = field(default=None, repr=False)

    def actualizar_distancia(self, nueva_distancia: float) -> None:
        # recibe la distancia ya calculada en cm
        self.distancia_cm = nueva_distancia
        self.actualizado_en = datetime.utcnow().isoformat()

        estado_anterior = self.estado

        if self.distancia_cm <= self.umbral_ocupado_cm:
            self.estado = EstadoOcupacion.OCUPADA
        else:
            self.estado = EstadoOcupacion.LIBRE

        # respuesta automática, prende led asociado
        if self.led_asociado:
            nuevo_color = self.get_color_led()
            self.led_asociado.actualizar_estado(nuevo_color)

        # notificación si cambió de estado
        if estado_anterior != self.estado:
            self.notificar(
                TipoNotificacion.INFO,
                f"Plaza {self.id}: {self.estado.value}"
            )

        # guarda la lectura en json
        self.guardar_lectura("distancia", {
            "distancia_cm": self.distancia_cm,
            "estado": self.estado.value
        })
        self.guardar_sensor()

    def get_color_led(self) -> EstadoLED:
        return EstadoLED.ROJO if self.estado == EstadoOcupacion.OCUPADA else EstadoLED.VERDE

    # añadido para el gestor: usa el valor actual (o lo que tú luego leas del hardware)
    def actualizar(self) -> None:
        self.actualizar_distancia(self.distancia_cm)


@dataclass
class SensorHumo(Sensor):
    """sensor MQ-2 para humo y gases"""
    tipo: TipoSensor = TipoSensor.HUMO

    # pines ESP32
    pin_analogico: int = 0  # lee valor 0-4095
    pin_digital: int = 0  # lee 0 o 1 si supera umbral

    # mediciones
    valor_adc: int = 0  # valor del pin analógico
    densidad_ppm: float = 0.0

    # umbrales
    umbral_aviso_ppm: float = 100.0
    umbral_alarma_ppm: float = 300.0
    nivel: NivelAlarma = NivelAlarma.NORMAL

    # actuadores
    camaras_zona: List['SensorCamara'] = field(default_factory=list, repr=False)
    leds_zona: List['LEDIndicador'] = field(default_factory=list, repr=False)

    def actualizar_desde_adc(self, valor_adc: int) -> None:
        # recibe valor directo del ADC (0-4095)
        self.valor_adc = valor_adc
        # conversión, cada 10 unidades aproximamos 1 ppm
        self.densidad_ppm = valor_adc / 10.0
        self.actualizar_densidad(self.densidad_ppm)

    def actualizar_densidad(self, nueva_densidad: float) -> None:
        self.densidad_ppm = nueva_densidad
        self.actualizado_en = datetime.utcnow().isoformat()

        nivel_anterior = self.nivel

        if self.densidad_ppm >= self.umbral_alarma_ppm:
            self.nivel = NivelAlarma.ALARMA
        elif self.densidad_ppm >= self.umbral_aviso_ppm:
            self.nivel = NivelAlarma.AVISO
        else:
            self.nivel = NivelAlarma.NORMAL

        # respuesta automática según nivel
        if self.nivel == NivelAlarma.ALARMA:
            # activa todas las cámaras de la zona
            for camara in self.camaras_zona:
                if not camara.transmitiendo:
                    camara.iniciar_transmision()

            # pone todos los LEDs en rojo
            for led in self.leds_zona:
                led.actualizar_estado(EstadoLED.ROJO)

            # notificación crítica
            self.notificar(
                TipoNotificacion.CRITICA,
                f"¡ALARMA DE HUMO! Densidad: {self.densidad_ppm:.1f} ppm (ADC: {self.valor_adc})"
            )

        elif self.nivel == NivelAlarma.AVISO:
            # pone leds en amarillo
            for led in self.leds_zona:
                led.actualizar_estado(EstadoLED.AMARILLO)

            self.notificar(
                TipoNotificacion.AVISO,
                f"Humo detectado. Densidad: {self.densidad_ppm:.1f} ppm (ADC: {self.valor_adc})"
            )

        elif nivel_anterior != NivelAlarma.NORMAL and self.nivel == NivelAlarma.NORMAL:
            # vuelve a la normalidad
            for led in self.leds_zona:
                led.actualizar_estado(EstadoLED.VERDE)

            self.notificar(
                TipoNotificacion.INFO,
                "Niveles de humo normalizados"
            )

        # guarda la lectura en json
        self.guardar_lectura("densidad_humo", {
            "densidad_ppm": self.densidad_ppm,
            "valor_adc": self.valor_adc,
            "nivel": self.nivel.value
        })
        self.guardar_sensor()

    # añadido para el gestor
    def actualizar(self) -> None:
        self.actualizar_desde_adc(self.valor_adc)


@dataclass
class SensorTemperatura(Sensor):
    """sensor temperatura y humedad"""
    tipo: TipoSensor = TipoSensor.TEMPERATURA

    # pines ESP32
    pin_datos: int = 0  # pin digital

    # tipo de sensor
    es_dht22: bool = False  # si es False, asumimos DHT11

    # mediciones temperatura
    temp_c: float = 20.0
    temp_ideal_c: float = 21.0
    min_c: float = 18.0
    max_c: float = 25.0

    # mediciones humedad
    humedad_porcentaje: float = 50.0  # 0-100%

    # estados
    fuera_de_rango: bool = False
    alerta_activa: bool = False
    climatizacion_activa: bool = False

    @property
    def cambio_necesario_c(self) -> float:
        return self.temp_ideal_c - self.temp_c

    def actualizar_desde_dht(self, temp_c: float, humedad: float) -> None:
        # recibe temperatura y humedad del DHT
        self.humedad_porcentaje = humedad
        self.actualizar_temperatura(temp_c)

    def actualizar_temperatura(self, nueva_temp: float) -> None:
        self.temp_c = nueva_temp
        self.actualizado_en = datetime.utcnow().isoformat()
        self.fuera_de_rango = not (self.min_c <= nueva_temp <= self.max_c)

        alerta_anterior = self.alerta_activa
        self.alerta_activa = self.fuera_de_rango

        # respuesta automática de activar o desactivar cambio de temperatura
        if self.temp_c < self.min_c:
            self.climatizacion_activa = True
            if not alerta_anterior:
                self.notificar(
                    TipoNotificacion.AVISO,
                    f"Temperatura baja ({self.temp_c}°C). Activando calefacción"
                )

        elif self.temp_c > self.max_c:
            self.climatizacion_activa = True
            if not alerta_anterior:
                self.notificar(
                    TipoNotificacion.AVISO,
                    f"Temperatura alta ({self.temp_c}°C). Activando refrigeración"
                )

        else:
            if self.climatizacion_activa:
                self.climatizacion_activa = False
                self.notificar(
                    TipoNotificacion.INFO,
                    f"Temperatura normalizada ({self.temp_c}°C)"
                )

        # guarda la lectura en JSON (se añade, no sobreescribe)
        self.guardar_lectura("temperatura", {
            "temp_c": self.temp_c,
            "humedad_porcentaje": self.humedad_porcentaje,
            "fuera_de_rango": self.fuera_de_rango,
            "climatizacion_activa": self.climatizacion_activa,
            "cambio_necesario_c": self.cambio_necesario_c
        })
        self.guardar_sensor()

    # añadido para el gestor
    def actualizar(self) -> None:
        self.actualizar_desde_dht(self.temp_c, self.humedad_porcentaje)


@dataclass
class SensorMovimiento(Sensor):
    # sensor PIR detecta movimiento
    tipo: TipoSensor = TipoSensor.MOVIMIENTO

    # pines ESP32
    pin_digital: int = 0  # lee 1 cuando hay movimiento

    # estado
    movimiento: bool = False
    ultima_actividad: str = field(default_factory=lambda: datetime.utcnow().isoformat())

    # monitorización de flujo
    detecciones_totales: int = 0
    detecciones_ultima_hora: int = 0

    # seguridad
    modo_seguridad_activo: bool = False
    alertas_generadas: int = 0
    camaras_zona: List['SensorCamara'] = field(default_factory=list, repr=False)
    leds_zona: List['LEDIndicador'] = field(default_factory=list, repr=False)

    def actualizar_desde_pin(self, estado_pin: bool) -> None:
        # recibe el estado del pin digital
        if estado_pin and not self.movimiento:  # paso de no movimiento a movimiento
            self.registrar_deteccion()
        elif not estado_pin:
            self.movimiento = False

    def registrar_deteccion(self) -> None:
        # este metodo registra movimiento y actualiza contadores
        self.movimiento = True
        self.ultima_actividad = datetime.utcnow().isoformat()
        self.actualizado_en = datetime.utcnow().isoformat()
        self.detecciones_totales += 1
        self.detecciones_ultima_hora += 1

        # genera alerta si está en modo seguridad
        if self.modo_seguridad_activo:
            self.alertas_generadas += 1

            # respuesta automática de activar cámaras y leds
            for camara in self.camaras_zona:
                if not camara.transmitiendo:
                    camara.iniciar_transmision()

            for led in self.leds_zona:
                led.actualizar_estado(EstadoLED.AMARILLO)

            self.notificar(
                TipoNotificacion.CRITICA,
                f"Movimiento detectado en modo seguridad"
            )

        # guarda la lectura en json
        self.guardar_lectura("movimiento", {
            "deteccion": True,
            "detecciones_totales": self.detecciones_totales,
            "detecciones_ultima_hora": self.detecciones_ultima_hora,
            "modo_seguridad": self.modo_seguridad_activo
        })
        self.guardar_sensor()

    # añadido para el gestor
    def actualizar(self) -> None:
        self.actualizar_desde_pin(self.movimiento)


@dataclass
class SensorCamara(Sensor):
    # camara ESP32-CAM
    tipo: TipoSensor = TipoSensor.CAMARA

    # configuración
    resolucion: str = "VGA"  # VGA = 640x480, SVGA = 800x600, etc

    # estado
    estado_conexion: EstadoConexion = EstadoConexion.ONLINE
    transmitiendo: bool = False
    url_stream: str = ""  # ej: "http://192.168.1.100:81/stream"

    def iniciar_transmision(self) -> None:
        # inicia stream de video
        if self.estado_conexion == EstadoConexion.ONLINE:
            self.transmitiendo = True
            self.actualizado_en = datetime.utcnow().isoformat()
            self.notificar(
                TipoNotificacion.INFO,
                f"Cámara {self.id} iniciando transmisión"
            )

            # guarda la lectura en json
            self.guardar_lectura("transmision", {
                "accion": "iniciar",
                "transmitiendo": self.transmitiendo,
                "estado_conexion": self.estado_conexion.value
            })
            self.guardar_sensor()
        else:
            self.notificar(
                TipoNotificacion.CRITICA,
                f"No se puede iniciar cámara {self.id}: OFFLINE"
            )

    def detener_transmision(self) -> None:
        self.transmitiendo = False
        self.actualizado_en = datetime.utcnow().isoformat()

        # guarda la lectura en json
        self.guardar_lectura("transmision", {
            "accion": "detener",
            "transmitiendo": self.transmitiendo,
            "estado_conexion": self.estado_conexion.value
        })
        self.guardar_sensor()

    # añadido para el gestor (por ahora no hace nada periódico)
    def actualizar(self) -> None:
        pass


@dataclass  # este no es en si un sensor pero lo usamos en la maqueta para mostrar el estado del sensor
class LEDIndicador(Sensor):
    # led simple
    tipo: TipoSensor = TipoSensor.LED_ESTADO

    # pines ESP32
    pin_pwm: int = 0  # pin que controla el led

    # estado
    estado: EstadoLED = EstadoLED.VERDE
    brillo: int = 255  # 0 = apagado, 255 = máximo
    sistema_asociado: str = ""  # qué tipo de sensor monitoriza

    def actualizar_estado(self, nuevo_estado: EstadoLED, nuevo_brillo: int = 255) -> None:
        # cambia el color del led
        estado_anterior = self.estado
        self.estado = nuevo_estado
        self.brillo = nuevo_brillo
        self.actualizado_en = datetime.utcnow().isoformat()

        # notifica solo si es un cambio crítico
        if estado_anterior != EstadoLED.ROJO and nuevo_estado == EstadoLED.ROJO:
            self.notificar(
                TipoNotificacion.CRITICA,
                f"LED {self.id} cambió a ROJO"
            )

        # guarda la lectura en json
        self.guardar_lectura("cambio_estado", {
            "estado_anterior": estado_anterior.value,
            "estado_nuevo": nuevo_estado.value,
            "brillo": self.brillo
        })
        self.guardar_sensor()

    # añadido para el gestor
    def actualizar(self) -> None:
        pass


# gestor de sensores para actualizar todos en un loop
class GestorSensores:
    def __init__(self, sensores: List[Sensor]) -> None:
        self.sensores = sensores

    def actualizar_todos(self) -> None:
        for sensor in self.sensores:
            sensor.actualizar()


# loop automático
if __name__ == "__main__":
    # aca creamos los sensores reales despues, así:
    sensores: List[Sensor] = []

    gestor = GestorSensores(sensores)

    while True:
        gestor.actualizar_todos()
        time.sleep(30)
