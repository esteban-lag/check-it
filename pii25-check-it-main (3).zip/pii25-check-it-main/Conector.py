import mysql.connector

class DBConnection:

    def __init__(self):
        self.connection = None

    def connect(self, user, password):
        try:
            self.connection = mysql.connector.connect(
                host="localhost",
                user= user,
                password=password,
                database="pii26_check_it"
            )
            print("Conectado a la base de datos")

        except mysql.connector.Error as err:
            print("Error de conexión:", err)

    def get_connection(self):
        return self.connection

    def close(self):
        if self.connection:
            self.connection.close()
            print("Conexión cerrada")